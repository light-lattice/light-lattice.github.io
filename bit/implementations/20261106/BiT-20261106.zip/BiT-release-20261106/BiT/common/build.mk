# Copyright (c) 2026 Hang Zhang.

.DEFAULT_GOAL := all
CC = gcc
ifeq ($(IMPLEMENTATION),ref)
# Reference benchmark flags from the specification, section 6.2.1.
CFLAGS ?= -std=c99 -Wpedantic -Wall -Wextra -O2
else
CFLAGS ?= -std=c99 -Wpedantic -Wall -Wextra -O3 -fomit-frame-pointer
endif
CPPFLAGS ?=
LDLIBS ?= -lm
BACKEND ?= shake
NTESTS ?= 1000
RUNNER ?=

ifneq ($(BACKEND),shake)
$(error Only the SHAKE backend is supported)
endif
override CPPFLAGS += -I. -Itest -I../../common
ifeq ($(IMPLEMENTATION),avx)
override CPPFLAGS += -DBIT_IMPL_AVX=1
else
override CPPFLAGS += -DBIT_IMPL_AVX=0
endif

# Common sources are compiled separately for each parameter set and backend.
COMMON_DIR := ../../common
COMMON_MODULES := sample sign spectral symmetric signature_api
COMMON_SRCS := $(addprefix $(COMMON_DIR)/,$(addsuffix .c,$(COMMON_MODULES)))
LOCAL_SRCS := $(filter-out KAT_SIG.c,$(wildcard *.c))
OBJS := $(LOCAL_SRCS:.c=.o) $(addsuffix .o,$(COMMON_MODULES))

ifeq ($(IMPLEMENTATION),ref)
ifneq ($(PARAMETER_SET),512)
COMMON_SRCS += $(COMMON_DIR)/polyvec_ref.c
OBJS += polyvec_ref.o
endif
else ifeq ($(IMPLEMENTATION),avx)
override CFLAGS += -mavx2
ASM_SRCS := $(wildcard *.S)
OBJS += $(ASM_SRCS:.S=_avx.o) keccakx4_lanes.o
else
$(error IMPLEMENTATION must be ref or avx)
endif

ifneq ($(filter $(PARAMETER_SET),128 256),)
COMMON_SRCS += $(COMMON_DIR)/signature_codec_$(PARAMETER_SET).c
OBJS += signature_codec_$(PARAMETER_SET).o
else ifneq ($(PARAMETER_SET),512)
$(error PARAMETER_SET must be 128, 256 or 512)
endif

SRCS := $(LOCAL_SRCS) $(COMMON_SRCS)
ifeq ($(IMPLEMENTATION),ref)
# Keep the API first and the signature codec next to key packing.
CODEC_OBJS := $(filter signature_codec_%.o,$(OBJS))
LINK_OBJS := signature_api.o $(filter-out signature_api.o $(CODEC_OBJS),$(sort $(OBJS)))
OBJS := $(foreach object,$(LINK_OBJS),$(object) $(if $(filter packing.o,$(object)),$(CODEC_OBJS)))
else
OBJS := $(sort $(OBJS))
endif

TEST_HEADERS := $(wildcard test/*.h)
-include $(OBJS:.o=.d) test_gaussian_exp.d

.PHONY: all check correctness speed clean message-binding
all: KAT_SIG
check: correctness
ifneq ($(wildcard test/test_message_binding.c),)
check: message-binding

message-binding: test/test_message_binding.c $(TEST_HEADERS) $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $< $(OBJS) -Wl,--wrap=bit_hash_message $(LDLIBS) -o $@
	$(RUNNER) ./$@
endif

ifeq ($(IMPLEMENTATION)-$(PARAMETER_SET)-$(BACKEND),avx-512-shake)
.PHONY: gaussian-exp
check: gaussian-exp

gaussian-exp: test_gaussian_exp
	$(RUNNER) ./test_gaussian_exp

test_gaussian_exp: test/test_gaussian_exp.c samplerx4.c
	$(CC) $(CFLAGS) $(CPPFLAGS) -ffunction-sections -fdata-sections -MMD -MP \
	  -DGAUSSIAN_TEST_SOURCE=\"samplerx4.c\" $< -Wl,--gc-sections -o $@
endif

KAT_SIG: KAT_SIG.c $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $^ $(LDLIBS) -o $@

correctness: test/test_correctness.c $(TEST_HEADERS) $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $< $(OBJS) $(LDLIBS) -o $@
	$(RUNNER) ./$@

speed: test/test_speed.c test/cpucycles.c test/speed_print.c $(TEST_HEADERS) $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) -DNTESTS=$(NTESTS) \
	  test/test_speed.c test/cpucycles.c test/speed_print.c $(OBJS) $(LDLIBS) -o $@
	$(RUNNER) ./$@

# Common and local modules both write objects into this build directory.
$(addsuffix .o,$(COMMON_MODULES)) polyvec_ref.o signature_codec_128.o signature_codec_256.o: %.o: $(COMMON_DIR)/%.c
	$(CC) $(CFLAGS) $(CPPFLAGS) -MMD -MP -c $< -o $@

.PHONY: print-sources print-objects
print-sources:
	@printf '%s\n' $(SRCS) $(ASM_SRCS) $(if $(filter avx,$(IMPLEMENTATION)),../common/keccakx4_lanes.c)
print-objects:
	@printf '%s\n' $(OBJS)

%.o: %.c
	$(CC) $(CFLAGS) $(CPPFLAGS) -MMD -MP -c $< -o $@

ifeq ($(IMPLEMENTATION),avx)
%_avx.o: %.S
	$(CC) $(CFLAGS) $(CPPFLAGS) -MMD -MP -c $< -o $@

keccakx4_lanes.o: ../common/keccakx4_lanes.c ../common/keccakx4_lanes.h
	$(CC) $(CFLAGS) $(CPPFLAGS) -MMD -MP -c $< -o $@
endif

clean:
	rm -f KAT_SIG correctness speed message-binding test_gaussian_exp *.o *.d *.su
