/* Copyright (c) 2026 Hang Zhang. */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "sign.h"
#include "precomp.h"
#include "test_common.h"

static int rng_fail;
int __real_get_random_number(DRNG_ctx *, unsigned char *, unsigned long long);
int __wrap_get_random_number(DRNG_ctx *ctx, unsigned char *out, unsigned long long bits)
{
    if (rng_fail) return -1;
    return __real_get_random_number(ctx, out, bits);
}
static int cleared(const bit_sign_precomp *p)
{
    const unsigned char *bytes = (const unsigned char *)p;
    unsigned value = 0;
    for (size_t i = 0; i < sizeof(*p); i++) value |= bytes[i];
    return value == 0;
}
#define REQUIRE(c) do { if (!(c)) { fprintf(stderr, "precomp failure at line %d\n", __LINE__); return 1; } } while (0)
int main(void)
{
    static unsigned char pk[2][BIT_PUBLICKEYBYTES], sk[2][BIT_SECRETKEYBYTES];
    static unsigned char sig[BIT_SIGNBYTES], message[64];
    static bit_sign_precomp candidate;
    unsigned char seed[55];
    unsigned long long pn, sn, length;
    unsigned accepted = 0, rejected = 0;
    test_fill_seed(seed, sizeof(seed), 1029, 0);
    REQUIRE(init_random_number(&drng_algorithm, seed, sizeof(seed)) == 0);
    for (unsigned i = 0; i < 2; i++)
        REQUIRE(bit_sig_keygen(pk[i], &pn, sk[i], &sn) == 0);
    REQUIRE(sizeof(candidate) < 9000);
    for (unsigned i = 0; i < 256; i++) {
        test_fill_message(message, sizeof(message), 1029, i);
        REQUIRE(bit_sig_sign_precompute(sk[i & 1], sn, &candidate) == 0);
        int status = bit_sig_sign_online(sk[i & 1], sn, message, sizeof(message), &candidate, sig, &length);
        REQUIRE(cleared(&candidate));
        REQUIRE(status == 0 || status == BIT_SIGN_PRECOMP_REJECT);
        if (status == 0) {
            accepted++;
            REQUIRE(length == BIT_SIGNBYTES);
            REQUIRE(bit_sig_verify(sig, length, message, sizeof(message), pk[i & 1], pn) == 0);
            message[0] ^= 1;
            REQUIRE(bit_sig_verify(sig, length, message, sizeof(message), pk[i & 1], pn) != 0);
        } else { rejected++; REQUIRE(length == 0); }
        REQUIRE(bit_sig_sign_online(sk[i & 1], sn, message, sizeof(message), &candidate, sig, &length) == -1);
        REQUIRE(length == 0 && cleared(&candidate));
    }
    for (unsigned i = 0; i < 64; i++) {
        REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
        int status = bit_sig_sign_online(sk[0], sn, NULL, 0, &candidate, sig, &length);
        REQUIRE(cleared(&candidate));
        REQUIRE(status == 0 || status == BIT_SIGN_PRECOMP_REJECT);
        if (status == 0) {
            REQUIRE(bit_sig_verify(sig, length, NULL, 0, pk[0], pn) == 0);
            break;
        }
        REQUIRE(i != 63);
    }
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
    REQUIRE(bit_sig_sign_online(sk[0], sn, message, 64, &candidate, NULL, &length) == -1);
    REQUIRE(cleared(&candidate) && length == 0);
    REQUIRE(accepted > 0 && rejected > 0);
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
    REQUIRE(bit_sig_sign_online(sk[1], sn, message, 64, &candidate, sig, &length) == -1);
    REQUIRE(length == 0 && cleared(&candidate));
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
    REQUIRE(bit_sig_sign_online(sk[0], sn, NULL, 1, &candidate, sig, &length) == -1);
    REQUIRE(cleared(&candidate));
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
    REQUIRE(bit_sig_sign_online(sk[0], sn, message, SIZE_MAX, &candidate, sig, &length) == -1);
    REQUIRE(cleared(&candidate));
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
    REQUIRE(bit_sig_sign_online(sk[0], sn, message, 64, &candidate, sig, NULL) == -1);
    REQUIRE(cleared(&candidate));
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
    candidate.b = 2;
    REQUIRE(bit_sig_sign_online(sk[0], sn, message, 64, &candidate, sig, &length) == -1);
    REQUIRE(cleared(&candidate));
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == 0);
    candidate.nonce = UINT16_MAX;
    REQUIRE(bit_sig_sign_online(sk[0], sn, message, 64, &candidate, sig, &length) == -1);
    REQUIRE(cleared(&candidate));
    rng_fail = 1;
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, &candidate) == -1);
    REQUIRE(cleared(&candidate));
    rng_fail = 0;
    REQUIRE(bit_sig_sign_precompute(sk[0], sn - 1, &candidate) == -1);
    REQUIRE(cleared(&candidate));
    REQUIRE(bit_sig_sign_precompute(NULL, sn, &candidate) == -1);
    REQUIRE(bit_sig_sign_precompute(sk[0], sn, NULL) == -1);
    REQUIRE(bit_sig_sign_online(sk[0], sn, message, 64, NULL, sig, &length) == -1);
    bit_sig_sign_precomp_clear(NULL);
    printf("PASS precomp: accepted=%u rejected=%u bytes=%zu; one-use, binding and errors\n", accepted, rejected, sizeof(candidate));
    return 0;
}
