/* Copyright (c) 2026 Hang Zhang. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include GAUSSIAN_TEST_SOURCE

__extension__ typedef __int128 test_wide_t;

static uint64_t exp_reference(uint64_t x)
{
    static const int64_t coefficients[8] = {
        -INT64_C(0x0000B6C6340925AE), INT64_C(0x0000B4BD4DF85227),
        -INT64_C(0x0000887F727491E2), INT64_C(0x0000AAAA643C7E8D),
        -INT64_C(0x0000AAAAA98179E6), INT64_C(0x0000FFFFFFFB2E7A),
        -INT64_C(0x0000FFFFFFFFF85F), INT64_C(0x0000FFFFFFFFFFFC)
    };
    static const unsigned shifts[7] = {3, 3, 2, 2, 1, 1, 0};
    static const int64_t rounds[7] = {4, 4, 2, 2, 1, 1, 0};
    int64_t value = coefficients[0];

    for (unsigned i = 0; i < 7; i++) {
        test_wide_t product = (test_wide_t)value * x + ((test_wide_t)1 << 47);
        value = (int64_t)(product >> 48);
        value = ((value + rounds[i]) >> shifts[i]) + coefficients[i + 1];
    }
    return (uint64_t)value;
}

static uint64_t test_next(uint64_t *state)
{
    *state ^= *state << 13;
    *state ^= *state >> 7;
    *state ^= *state << 17;
    return *state;
}

int main(void)
{
    static const size_t counts[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 31, 32, 63, 64, 65, 520, 1048};
    static uint64_t input[4 * 1048 + 8] __attribute__((aligned(32)));
    static uint64_t actual[4 * 1048 + 8] __attribute__((aligned(32)));
    uint64_t state = UINT64_C(0x51a7836de28b0924);
    const uint64_t mask = UINT64_C(0xffffffffffff);
    const uint64_t guard = UINT64_C(0xab764bc01238e519);

    for (unsigned trial = 0; trial < 128; trial++) {
        for (unsigned k = 0; k < sizeof(counts) / sizeof(counts[0]); k++) {
            size_t count = counts[k];
            for (size_t i = 0; i < sizeof(input) / sizeof(input[0]); i++)
                input[i] = guard;
            for (size_t i = 0; i < 4 * count; i++) {
                uint64_t x;
                if (trial < 48) {
                    uint64_t power = UINT64_C(1) << trial;
                    x = i % 4 == 0 ? power - 1 :
                        i % 4 == 1 ? power :
                        i % 4 == 2 ? power + 1 : mask - power;
                } else {
                    x = test_next(&state);
                }
                input[4 + i] = x & mask;
            }
            for (unsigned dense = 0; dense < (BIT_N == 1024 ? 2U : 1U); dense++) {
                memcpy(actual, input, sizeof(input));
#if BIT_N == 1024
                if (dense)
                    approx_exp_3x((__m256i *)(actual + 4), count);
                else
#endif
                    approx_exp_4x((__m256i *)(actual + 4), count);
                for (size_t i = 0; i < 4; i++)
                    if (actual[i] != guard) return 1;
                for (size_t i = 4 + 4 * count; i < sizeof(actual) / sizeof(actual[0]); i++)
                    if (actual[i] != guard) return 2;
                for (size_t i = 0; i < 4 * count; i++) {
                    if (dense && i < 16 * (count / 4) && i % 4 == 3)
                        continue;
                    if (actual[4 + i] != exp_reference(input[4 + i])) {
                        fprintf(stderr, "exp mismatch: trial=%u count=%zu lane=%zu\n",
                                trial, count, i);
                        return 3;
                    }
                }
            }
        }
    }
    puts("PASS: Q48 exponential oracle, lane layout and guarded boundaries");
    return 0;
}
