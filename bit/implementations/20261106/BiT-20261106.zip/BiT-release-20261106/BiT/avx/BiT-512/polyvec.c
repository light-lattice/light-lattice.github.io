/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */
#include "polyvec.h"
#include "../common/highbits.h"
#include "align.h"
#include "params.h"
#include "ntt_avx.h"
#include "symmetric.h"
#include "fips202x4.h"
#include "endian.h"
#include <stddef.h>
#include <string.h>

static inline __m256i reduce_barrett_i32x8(__m256i x);

static inline __m256i decompose_hint_bounded_i32x8(__m256i x)
{
    return bit_highbits_i32x8(reduce_barrett_i32x8(x));
}

static inline __m256i srai_epi64_32(__m256i x)
{
    __m256i sign = _mm256_cmpgt_epi64(_mm256_setzero_si256(), x);
    return _mm256_or_si256(_mm256_srli_epi64(x, 32), _mm256_slli_epi64(sign, 32));
}

/* Exact eight-lane equivalent of reduce_barrett() for signed int32 input. */
static inline __m256i reduce_barrett_i32x8(__m256i x)
{
    const __m256i multiplier = _mm256_set1_epi32((int32_t)BIT_BARRETT_MULT);
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    __m256i even = srai_epi64_32(_mm256_mul_epi32(x, multiplier));
    __m256i odd_input = _mm256_srli_epi64(x, 32);
    __m256i odd = srai_epi64_32(_mm256_mul_epi32(odd_input, multiplier));
    __m256i quotient = _mm256_blend_epi32(even, _mm256_slli_epi64(odd, 32), 0xAA);

    x = _mm256_sub_epi32(x, _mm256_mullo_epi32(quotient, q));
    x = _mm256_add_epi32(x, _mm256_and_si256(_mm256_srai_epi32(x, 31), q));
    x = _mm256_sub_epi32(x, q);
    return _mm256_add_epi32(x, _mm256_and_si256(_mm256_srai_epi32(x, 31), q));
}

static inline __m256i reduce_signed_barrett_i32x8(__m256i x)
{
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    const __m256i half = _mm256_set1_epi32(BIT_Q_HALF);

    x = reduce_barrett_i32x8(x);
    return _mm256_sub_epi32(x, _mm256_and_si256(_mm256_cmpgt_epi32(x, half), q));
}

static inline __m256i reduce_signed_modq_i32x8(__m256i x)
{
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    const __m256i half = _mm256_set1_epi32(BIT_Q_HALF);
    const __m256i neg_half = _mm256_set1_epi32(-BIT_Q_HALF);

    for (int pass = 0; pass < 2; pass++) {
        x = _mm256_sub_epi32(x, _mm256_and_si256(_mm256_cmpgt_epi32(x, half), q));
        x = _mm256_add_epi32(x, _mm256_and_si256(_mm256_cmpgt_epi32(neg_half, x), q));
    }
    return x;
}

int polyvecl_sample_S1(polyvecl *v, const uint8_t *seed, uint16_t *nonce)
{
    uint16_t n = *nonce;

    if (poly_sample_S1_4x(&v->vec[0], &v->vec[1], &v->vec[2], NULL, seed, n, (uint16_t)(n + 1U),
                          (uint16_t)(n + 2U), (uint16_t)(n + 2U)) != 0) {
        return -1;
    }
    *nonce = (uint16_t)(n + BIT_L);
    return 0;
}

int polyveck_sample_S1(polyveck *v, const uint8_t *seed, uint16_t *nonce)
{
    uint16_t n = *nonce;

    if (poly_sample_S1_4x(&v->vec[0], &v->vec[1], &v->vec[2], NULL, seed, n, (uint16_t)(n + 1U),
                          (uint16_t)(n + 2U), (uint16_t)(n + 2U)) != 0) {
        return -1;
    }
    *nonce = (uint16_t)(n + BIT_K);
    return 0;
}

#define MATRIX_XOF_BUFFER_SIZE (4 * BIT_XOF128_RATE)

/* Decode eight consecutive 15-bit little-endian candidates from 15 bytes. */
static inline __m256i unpack_uniform15x8(const uint8_t *buf)
{
    const __m256i gather = _mm256_setr_epi8(0, 1, 2, 3, 1, 2, 3, 4, 3, 4, 5, 6, 5, 6, 7, 8, 7, 8, 9,
                                            10, 9, 10, 11, 12, 11, 12, 13, 14, 13, 14, -1, -1);
    const __m256i shifts = _mm256_setr_epi32(0, 7, 6, 5, 4, 3, 2, 1);
    const __m256i mask = _mm256_set1_epi32((1U << 15) - 1U);
    __m128i input = _mm_loadu_si128((const __m128i *)buf);
    __m256i windows = _mm256_shuffle_epi8(_mm256_broadcastsi128_si256(input), gather);

    return _mm256_and_si256(_mm256_srlv_epi32(windows, shifts), mask);
}

static size_t reject_uniform15_avx(int32_t *out, size_t len, const uint8_t *buf, size_t buflen,
                                   uint64_t *acc, unsigned int *acc_bits)
{
    size_t ctr = 0;
    size_t pos = 0;

    /* Finish a 15-byte group split across two SHAKE squeeze buffers. */
    while (*acc_bits != 0 && ctr < len && pos < buflen) {
        while (*acc_bits < 15 && pos < buflen) {
            *acc |= (uint64_t)buf[pos++] << *acc_bits;
            *acc_bits += 8;
        }
        if (*acc_bits < 15)
            return ctr;
        {
            uint32_t value = (uint32_t)*acc & ((1U << 15) - 1U);
            *acc >>= 15;
            *acc_bits -= 15;
            if (value < BIT_Q)
                out[ctr++] = reduce_to_signed(value);
        }
    }

    while (ctr + 8 <= len && pos + 16 <= buflen) {
        BIT_ALIGN uint32_t value[8];

        _mm256_store_si256((__m256i *)value, unpack_uniform15x8(buf + pos));
        for (size_t i = 0; i < 8; i++)
            if (value[i] < BIT_Q)
                out[ctr++] = reduce_to_signed(value[i]);
        pos += 15;
    }

    while (ctr < len) {
        while (*acc_bits < 15 && pos < buflen) {
            *acc |= (uint64_t)buf[pos++] << *acc_bits;
            *acc_bits += 8;
        }
        if (*acc_bits < 15)
            break;
        {
            uint32_t value = (uint32_t)*acc & ((1U << 15) - 1U);
            *acc >>= 15;
            *acc_bits -= 15;
            if (value < BIT_Q)
                out[ctr++] = reduce_to_signed(value);
        }
    }
    return ctr;
}

BIT_ALIGN_64
static int poly_uniform_ntt_scalar(poly_ntt *a, const unsigned char *seed, size_t row, size_t col)
{
    unsigned char buf[MATRIX_XOF_BUFFER_SIZE];
    unsigned char msg[BIT_SEEDBYTES + 2];
    bit_xof128_state st;
    size_t ctr = 0;
    uint64_t acc = 0;
    unsigned int acc_bits = 0;

    memcpy(msg, seed, BIT_SEEDBYTES);
    msg[BIT_SEEDBYTES] = (unsigned char)col;
    msg[BIT_SEEDBYTES + 1] = (unsigned char)row;

    bit_xof128_init(&st, msg, sizeof(msg));
    while (ctr < BIT_N) {
        size_t pos = 0;
        if (bit_xof128_squeeze(&st, buf, sizeof(buf)) != 0) {
            bit_xof128_zeroize(&st);
            return -1;
        }
        while (ctr < BIT_N) {
            while (acc_bits < 15 && pos < sizeof(buf)) {
                acc |= (uint64_t)buf[pos++] << acc_bits;
                acc_bits += 8;
            }
            if (acc_bits < 15)
                break;

            uint32_t val = (uint32_t)acc & ((1U << 15) - 1U);
            acc >>= 15;
            acc_bits -= 15;
            if (val < BIT_Q) {
                a->coeffs[ctr++] = reduce_to_signed(val);
            }
        }
    }
    bit_xof128_zeroize(&st);
    /* Uniform samples are in the NTT domain; assembly consumes packed
     * 64-coefficient blocks. */
    ntt_pack_asm(a->coeffs);
    return 0;
}

static void poly_uniform_ntt_x4(poly_ntt *a[4], const unsigned char *seed, const uint8_t row[4],
                                const uint8_t col[4], size_t active)
{
    ALIGNED_UINT8(BIT_SEEDBYTES + 2) msg[4];
    ALIGNED_UINT8(MATRIX_XOF_BUFFER_SIZE) buf[4];
    keccakx4_state st;
    size_t ctr[4] = {0, 0, 0, 0};
    uint64_t acc[4] = {0, 0, 0, 0};
    unsigned int acc_bits[4] = {0, 0, 0, 0};

    for (size_t lane = 0; lane < 4; lane++) {
        memcpy(msg[lane].coeffs, seed, BIT_SEEDBYTES);
        msg[lane].coeffs[BIT_SEEDBYTES] = col[lane];
        msg[lane].coeffs[BIT_SEEDBYTES + 1] = row[lane];
    }
    shake128x4_absorb_once(&st, msg[0].coeffs, msg[1].coeffs, msg[2].coeffs, msg[3].coeffs,
                           BIT_SEEDBYTES + 2);

    do {
        shake128x4_squeezeblocks(buf[0].coeffs, buf[1].coeffs, buf[2].coeffs, buf[3].coeffs,
                                 MATRIX_XOF_BUFFER_SIZE / BIT_XOF128_RATE, &st);
        for (size_t lane = 0; lane < active; lane++) {
            ctr[lane] += reject_uniform15_avx(a[lane]->coeffs + ctr[lane], BIT_N - ctr[lane],
                                              buf[lane].coeffs, MATRIX_XOF_BUFFER_SIZE, &acc[lane],
                                              &acc_bits[lane]);
        }
    } while ((active > 0 && ctr[0] < BIT_N) || (active > 1 && ctr[1] < BIT_N) ||
             (active > 2 && ctr[2] < BIT_N) || (active > 3 && ctr[3] < BIT_N));

    for (size_t lane = 0; lane < active; lane++)
        ntt_pack_asm(a[lane]->coeffs);
}

int poly_matrix_expand_ntt(poly_matrix_ntt *A_ntt, const unsigned char *seed)
{
    for (size_t base = 0; base < BIT_K * BIT_L; base += 4) {
        poly_ntt *a[4];
        uint8_t row[4];
        uint8_t col[4];
        size_t active = BIT_K * BIT_L - base;

        if (active > 4)
            active = 4;
        if (active == 1) {
            size_t r = base / BIT_L;
            size_t c = base % BIT_L;
            if (poly_uniform_ntt_scalar(&A_ntt->vec[r].vec[c], seed, r, c) != 0) {
                return -1;
            }
            break;
        }

        for (size_t lane = 0; lane < 4; lane++) {
            size_t index = base + (lane < active ? lane : active - 1);
            row[lane] = (uint8_t)(index / BIT_L);
            col[lane] = (uint8_t)(index % BIT_L);
            a[lane] = &A_ntt->vec[row[lane]].vec[col[lane]];
        }
        poly_uniform_ntt_x4(a, seed, row, col, active);
    }
    return 0;
}

void polyvecl_to_ntt(polyvecl_ntt *result, const polyvecl *v)
{
    for (int i = 0; i < BIT_L; i++) {
        poly_to_ntt(&result->vec[i], &v->vec[i]);
    }
}

void polyvecy_y1_to_ntt(polyvecl_ntt *result, const polyvecy *y)
{
    for (int i = 0; i < BIT_L; i++) {
        poly_to_ntt(&result->vec[i], &y->vec[1 + i]);
    }
}

void polyveck_from_ntt_raw(polyveck *result, const polyveck_ntt *v_ntt)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_from_ntt_raw(&result->vec[i], &v_ntt->vec[i]);
    }
}

void poly_matrix_mul_vector_ntt(polyveck *result, const poly_matrix_ntt *A_ntt,
                                const polyvecl_ntt *v_ntt)
{
    polyveck_ntt acc;

    for (int i = 0; i < BIT_K; i++) {
        poly_ntt_dot3_raw(&acc.vec[i], A_ntt->vec[i].vec, v_ntt->vec);
    }

    polyveck_from_ntt_raw(result, &acc);
}

void polyveck_add_small(polyveck *result, const polyveck *a, const polyveck *small)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_add_small(&result->vec[i], &a->vec[i], &small->vec[i]);
    }
}

void polyveck_canonicalize(polyveck *b)
{
    for (int i = 0; i < BIT_K; i++)
        poly_canonicalize(&b->vec[i]);
}

void polyveck_public_to_ntt(polyveck_ntt *b_ntt, const polyveck *b)
{
    poly tmp;
    for (int i = 0; i < BIT_K; i++) {
        for (int j = 0; j < BIT_N; j++) {
            int32_t value = b->vec[i].coeffs[j];
            tmp.coeffs[j] = value - (BIT_Q & ((BIT_Q_HALF - value) >> 31));
        }
        poly_to_ntt(&b_ntt->vec[i], &tmp);
    }
}

void polyveck_compute_w_ntt(polyveck *w, const poly_matrix_ntt *A_0_ntt, const polyveck_ntt *b_ntt,
                            const polyvecl_ntt *y1_ntt, const poly_ntt *y0_ntt, const polyvecy *y)
{
    polyveck_ntt w_ntt;
    poly_ntt tmp_ntt;

    for (int i = 0; i < BIT_K; i++) {
        poly_ntt_dot3_raw(&w_ntt.vec[i], A_0_ntt->vec[i].vec, y1_ntt->vec);
        poly_ntt_basemul_raw(&tmp_ntt, &b_ntt->vec[i], y0_ntt);
        for (int j = 0; j < BIT_N; j += 8)
            _mm256_store_si256((__m256i *)&w_ntt.vec[i].coeffs[j],
                               reduce_signed_modq_i32x8(_mm256_sub_epi32(
                                   _mm256_load_si256((const __m256i *)&w_ntt.vec[i].coeffs[j]),
                                   _mm256_load_si256((const __m256i *)&tmp_ntt.coeffs[j]))));
    }
    polyveck_from_ntt_raw(w, &w_ntt);

    for (int j = 0; j < BIT_N; j += 8) {
        __m256i val = _mm256_load_si256((const __m256i *)&w->vec[0].coeffs[j]);
        __m256i y0 = _mm256_load_si256((const __m256i *)&y->vec[0].coeffs[j]);
        val = _mm256_add_epi32(val, _mm256_mullo_epi32(y0, _mm256_set1_epi32(BIT_Q_HAT_MINUS)));
        _mm256_store_si256((__m256i *)&w->vec[0].coeffs[j], reduce_signed_barrett_i32x8(val));
    }

    for (int i = 0; i < BIT_K; i++) {
        poly_add(&w->vec[i], &w->vec[i], &y->vec[1 + BIT_L + i]);
    }
}

void polyveck_highbits(polyveck *w1, const polyveck *w)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_highbits(&w1->vec[i], &w->vec[i]);
    }
}

void polyveck_pack_w1(unsigned char *r, const polyveck *w1)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_pack_w1(r + i * BIT_POLY_W1_BYTES, &w1->vec[i]);
    }
}

/* Six base-2^8 digits pack the s_0 || e products into one word. */
#if BIT_L != 3 || BIT_K != 3 || BIT_TAU != 115
#error "the packed s/e challenge multiplier is specialized for BiT-512"
#endif

#define PSPM_SE_SHIFT 8
#define PSPM_SE_MASK ((UINT64_C(1) << PSPM_SE_SHIFT) - 1)
#define PSPM_SE_U 1
#define PSPM_SE_BIAS (BIT_TAU * PSPM_SE_U)

_Static_assert(2 * BIT_TAU * PSPM_SE_U < (1 << PSPM_SE_SHIFT),
               "PSPM digit must not carry into its neighbor");
_Static_assert(PSPM_SE_SHIFT *(BIT_L + BIT_K) <= 64, "all PSPM digits must fit in uint64_t");

void polyvec_prepare_challenge_mul_se(bit_pspm_se_precomp *table, const polyvecl *s,
                                      const polyveck *e)
{
    const poly *src[BIT_L + BIT_K] = {&s->vec[0], &s->vec[1], &s->vec[2],
                                      &e->vec[0], &e->vec[1], &e->vec[2]};

    for (int i = 0; i < BIT_N; i++) {
        uint64_t plus = 0;
        uint64_t minus = 0;
        for (int j = 0; j < BIT_L + BIT_K; j++) {
            int32_t value = src[j]->coeffs[i];
            plus |= (uint64_t)(PSPM_SE_U + value) << (PSPM_SE_SHIFT * j);
            minus |= (uint64_t)(PSPM_SE_U - value) << (PSPM_SE_SHIFT * j);
        }
        table->words[BIT_N + i] = plus;
        table->words[i] = minus;
    }
}

static void pspm_add_neg_words(uint64_t *dst, const uint64_t *src, uint64_t twice_bias)
{
    const __m256i bias = _mm256_set1_epi64x((int64_t)twice_bias);

    for (size_t i = 0; i < BIT_N; i += 4) {
        __m256i d = _mm256_loadu_si256((const __m256i *)(dst + i));
        __m256i x = _mm256_loadu_si256((const __m256i *)(src + i));
        _mm256_storeu_si256((__m256i *)(dst + i), _mm256_add_epi64(d, _mm256_sub_epi64(bias, x)));
    }
}

static void pspm_add_words(uint64_t *dst, const uint64_t *src, size_t count)
{
    size_t i = 0;
    for (; i + 4 <= count; i += 4) {
        __m256i d = _mm256_loadu_si256((const __m256i *)(dst + i));
        __m256i x = _mm256_loadu_si256((const __m256i *)(src + i));
        _mm256_storeu_si256((__m256i *)(dst + i), _mm256_add_epi64(d, x));
    }
    for (; i < count; i++)
        dst[i] += src[i];
}

void polyvec_mul_challenge_no_reduce_se_pspm(polyvecl *c_s, polyveck *c_e,
                                             const bit_pspm_se_precomp *table,
                                             const sparse_challenge *c)
{
    BIT_ALIGN uint64_t acc[BIT_N] = {0};
    poly *dst[BIT_L + BIT_K] = {&c_s->vec[0], &c_s->vec[1], &c_s->vec[2],
                                &c_e->vec[0], &c_e->vec[1], &c_e->vec[2]};
    const int32_t sign_mask = -(int32_t)c->bflip;
    uint64_t twice_bias = 0;

    for (int j = 0; j < BIT_L + BIT_K; j++)
        twice_bias |= (uint64_t)(2 * PSPM_SE_U) << (PSPM_SE_SHIFT * j);

    for (int t = 0; t < BIT_TAU; t++) {
        size_t rotation = c->pos[t];
        const uint64_t *window = table->words + BIT_N - rotation;
        if (c->sign[t] > 0)
            pspm_add_words(acc, window, BIT_N);
        else
            pspm_add_neg_words(acc, window, twice_bias);
    }
    for (int i = 0; i < BIT_N; i++) {
        uint64_t word = acc[i];
        for (int j = 0; j < BIT_L + BIT_K; j++) {
            int32_t value = (int32_t)(word & PSPM_SE_MASK) - PSPM_SE_BIAS;
            dst[j]->coeffs[i] = (value ^ sign_mask) - sign_mask;
            word >>= PSPM_SE_SHIFT;
        }
    }
}

#undef PSPM_SE_SHIFT
#undef PSPM_SE_MASK
#undef PSPM_SE_U
#undef PSPM_SE_BIAS

void polyveck_make_hint(polyveck *h, const polyveck *w1, const polyveck *w,
                          const polyveck *z2, const poly *c, uint8_t b)
{
    const __m256i add_c_mask = _mm256_set1_epi32(-(int32_t)(1U - b));
    const __m256i modulus = _mm256_set1_epi32(BIT_HINT_MODULUS);
    const __m256i half = _mm256_set1_epi32(BIT_HINT_MODULUS / 2);

    for (int i = 0; i < BIT_K; i++) {
        for (int j = 0; j < BIT_N; j += 8) {
            __m256i w_hat = _mm256_sub_epi32(_mm256_load_si256((const __m256i *)&w->vec[i].coeffs[j]),
                                 _mm256_load_si256((const __m256i *)&z2->vec[i].coeffs[j]));
            __m256i h_val;

            if (i == 0)
                w_hat = _mm256_add_epi32(
                    w_hat, _mm256_and_si256(_mm256_load_si256((const __m256i *)&c->coeffs[j]),
                                            add_c_mask));
            h_val = _mm256_sub_epi32(_mm256_load_si256((const __m256i *)&w1->vec[i].coeffs[j]),
                                     decompose_hint_bounded_i32x8(w_hat));
            h_val =
                _mm256_add_epi32(h_val, _mm256_and_si256(_mm256_srai_epi32(h_val, 31), modulus));
            h_val =
                _mm256_sub_epi32(h_val, _mm256_and_si256(_mm256_cmpgt_epi32(h_val, half), modulus));
            _mm256_store_si256((__m256i *)&h->vec[i].coeffs[j], h_val);
        }
    }
}

void polyveck_compute_w_hat_prime_ntt(polyveck *w_hat_prime, const poly_matrix_ntt *A_0_ntt,
                                      const polyveck_ntt *public_ntt, const polyvecl_ntt *z1_tail_ntt,
                                      const poly_ntt *z0_ntt, const poly *z0, const poly *c_poly)
{
    polyveck_ntt acc;
    poly_ntt tmp_ntt;

    for (int i = 0; i < BIT_K; i++) {
        poly_ntt_dot3_raw(&acc.vec[i], A_0_ntt->vec[i].vec, z1_tail_ntt->vec);
        poly_ntt_basemul_raw(&tmp_ntt, &public_ntt->vec[i], z0_ntt);
        for (int j = 0; j < BIT_N; j += 8)
            _mm256_store_si256((__m256i *)&acc.vec[i].coeffs[j],
                               reduce_signed_modq_i32x8(_mm256_sub_epi32(
                                   _mm256_load_si256((const __m256i *)&acc.vec[i].coeffs[j]),
                                   _mm256_load_si256((const __m256i *)&tmp_ntt.coeffs[j]))));
    }

    polyveck_from_ntt_raw(w_hat_prime, &acc);

    for (int j = 0; j < BIT_N; j += 8) {
        __m256i val = _mm256_load_si256((const __m256i *)&w_hat_prime->vec[0].coeffs[j]);
        __m256i z0c = _mm256_add_epi32(_mm256_load_si256((const __m256i *)&z0->coeffs[j]),
                                       _mm256_load_si256((const __m256i *)&c_poly->coeffs[j]));
        val = _mm256_add_epi32(val, _mm256_mullo_epi32(z0c, _mm256_set1_epi32(BIT_Q_HAT)));
        _mm256_store_si256((__m256i *)&w_hat_prime->vec[0].coeffs[j],
                           reduce_signed_barrett_i32x8(val));
    }
}

void polyveck_compute_w_prime(polyveck *w_prime, const polyveck *w_hat_prime, const polyveck *h)
{
    const __m256i modulus = _mm256_set1_epi32(BIT_HINT_MODULUS);

    for (int i = 0; i < BIT_K; i++) {
        for (int j = 0; j < BIT_N; j += 8) {
            __m256i val =
                _mm256_add_epi32(decompose_hint_bounded_i32x8(_mm256_load_si256(
                                     (const __m256i *)&w_hat_prime->vec[i].coeffs[j])),
                                 _mm256_load_si256((const __m256i *)&h->vec[i].coeffs[j]));
            val = _mm256_add_epi32(val, _mm256_and_si256(_mm256_srai_epi32(val, 31), modulus));
            val = _mm256_sub_epi32(val, modulus);
            val = _mm256_add_epi32(val, _mm256_and_si256(_mm256_srai_epi32(val, 31), modulus));
            _mm256_store_si256((__m256i *)&w_prime->vec[i].coeffs[j], val);
        }
    }
}
