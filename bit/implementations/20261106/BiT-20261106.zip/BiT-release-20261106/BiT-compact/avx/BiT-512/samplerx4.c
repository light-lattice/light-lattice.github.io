/*
 * Derived from HAETAE v2.0, Copyright (c) 2023 Team HAETAE.
 * Modifications Copyright (c) 2026 Hang Zhang.
 * SPDX-License-Identifier: MIT
 */
#include "../../common/ct_audit.h"
#include "align.h"
#include "fips202x4.h"
#include "../common/keccakx4_lanes.h"
#include "parabola_internal.h"
#include "params.h"
#include "symmetric.h"
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <immintrin.h>


#define N BIT_N
#define CRHBYTES BIT_SEEDBYTES
#define STREAM256_BLOCKBYTES SHAKE256_RATE

#define GAUSS_RAND (72 + 16 + 48)
#define GAUSS_RAND_BYTES ((GAUSS_RAND + 7) / 8)
/* 128 sign bytes and 1048 candidates use 132 SHAKE256 blocks,
 * with eight unused bytes. */
#ifndef BIT_GAUSS_X4_BATCH_CANDIDATES
#define BIT_GAUSS_X4_BATCH_CANDIDATES 1048
#endif
#define NUM_GAUSSIANS BIT_GAUSS_X4_BATCH_CANDIDATES
#if NUM_GAUSSIANS % 2 != 0
#error "The AVX2 Gaussian batch size must be even"
#endif
#if BIT_N != 1024
#error "This Gaussian x4 schedule is tuned for BiT-512 N=1024"
#endif
#define POLY_HYPERBALL_BUFLEN_4X (GAUSS_RAND_BYTES * NUM_GAUSSIANS + N / 8)
#define POLY_HYPERBALL_NBLOCKS_4X                                                                  \
    ((POLY_HYPERBALL_BUFLEN_4X + STREAM256_BLOCKBYTES - 1) / STREAM256_BLOCKBYTES)

#define CDTLEN 64
static const union {
    __m256i vec[(CDTLEN + 7) / 8 * 4];
    uint32_t arr[CDTLEN * 4];
} CDT_avx = {
    .arr = {
        3266,  6520,  3266,  6520,  3266,  6520,  3266,  6520,  9748,  12938, 9748,  12938, 9748,
        12938, 9748,  12938, 16079, 19159, 16079, 19159, 16079, 19159, 16079, 19159, 22168, 25096,
        22168, 25096, 22168, 25096, 22168, 25096, 27934, 30674, 27934, 30674, 27934, 30674, 27934,
        30674, 33309, 35833, 33309, 35833, 33309, 35833, 33309, 35833, 38241, 40531, 38241, 40531,
        38241, 40531, 38241, 40531, 42698, 44742, 42698, 44742, 42698, 44742, 42698, 44742, 46663,
        48460, 46663, 48460, 46663, 48460, 46663, 48460, 50135, 51690, 50135, 51690, 50135, 51690,
        50135, 51690, 53128, 54454, 53128, 54454, 53128, 54454, 53128, 54454, 55670, 56781, 55670,
        56781, 55670, 56781, 55670, 56781, 57794, 58712, 57794, 58712, 57794, 58712, 57794, 58712,
        59541, 60287, 59541, 60287, 59541, 60287, 59541, 60287, 60956, 61554, 60956, 61554, 60956,
        61554, 60956, 61554, 62085, 62556, 62085, 62556, 62085, 62556, 62085, 62556, 62972, 63337,
        62972, 63337, 62972, 63337, 62972, 63337, 63657, 63936, 63657, 63936, 63657, 63936, 63657,
        63936, 64178, 64388, 64178, 64388, 64178, 64388, 64178, 64388, 64569, 64724, 64569, 64724,
        64569, 64724, 64569, 64724, 64857, 64970, 64857, 64970, 64857, 64970, 64857, 64970, 65066,
        65148, 65066, 65148, 65066, 65148, 65066, 65148, 65216, 65273, 65216, 65273, 65216, 65273,
        65216, 65273, 65321, 65361, 65321, 65361, 65321, 65361, 65321, 65361, 65394, 65422, 65394,
        65422, 65394, 65422, 65394, 65422, 65444, 65463, 65444, 65463, 65444, 65463, 65444, 65463,
        65478, 65490, 65478, 65490, 65478, 65490, 65478, 65490, 65500, 65508, 65500, 65508, 65500,
        65508, 65500, 65508, 65514, 65519, 65514, 65519, 65514, 65519, 65514, 65519, 65523, 65527,
        65523, 65527, 65523, 65527, 65523, 65527, 65529, 65531, 65529, 65531, 65529, 65531, 65529,
        65531, 65533, 65534, 65533, 65534, 65533, 65534, 65533, 65534}};

static const union {
    __m256i vec;
    uint32_t arr[8];
} zero_avx = {.arr = {0}};

static const union {
    __m256i vec[2];
    uint16_t arr[32];
} mask_avx = {.arr = {0xffff, 0, 0, 0, 0xffff, 0, 0, 0, 0xffff, 0, 0, 0, 0xffff, 0, 0, 0, 0, 0,
                      0xffff, 0, 0, 0, 0xffff, 0, 0, 0, 0xffff, 0, 0, 0, 0xffff, 0}};

static const union {
    __m256i vec[3];
    uint64_t arr[12];
} mask72_avx = {.arr = {(1ULL << 48) - 1, (1ULL << 48) - 1, (1ULL << 48) - 1, (1ULL << 48) - 1,
                        (1ULL << 24) - 1, (1ULL << 24) - 1, (1ULL << 24) - 1, (1ULL << 24) - 1,
                        (1ULL << 16) - 1, (1ULL << 16) - 1, (1ULL << 16) - 1, (1ULL << 16) - 1}};

static const union {
    __m256i vec[3];
    uint64_t arr[12];
} consts_avx = {
    .arr = {1 << 14, 1 << 14, 1 << 14, 1 << 14, 1 << 11, 1 << 11, 1 << 11, 1 << 11, 1, 1, 1, 1}};

/* Split packed records into CDT, rejection, and candidate fields. */
static void preprocessing_x4(__m256i *sc, __m256i *sqr, __m256i *rej, const __m256i *buf,
                             size_t count)
{
    size_t i, j;
    __m256i reg[16];

    reg[7] = _mm256_load_si256(&mask72_avx.vec[0]);
    reg[8] = _mm256_load_si256(&mask72_avx.vec[1]);
    reg[9] = _mm256_load_si256(&mask72_avx.vec[2]);

    j = 0;
    for (i = 0; i < count; i++) {
        reg[0] = _mm256_load_si256(&buf[j++]);
        reg[1] = _mm256_load_si256(&buf[j++]);
        reg[2] = _mm256_load_si256(&buf[j]);

        switch (i % 8) {
        case 0:
            reg[3] = _mm256_and_si256(reg[0], reg[9]);
            reg[4] = _mm256_srli_epi64(reg[0], 16);
            reg[5] = _mm256_and_si256(reg[1], reg[7]);
            reg[6] = _mm256_srli_epi64(reg[1], 48);
            reg[10] = _mm256_slli_epi64(reg[2], 16);
            reg[6] = _mm256_or_si256(reg[6], reg[10]);
            reg[6] = _mm256_and_si256(reg[6], reg[8]);
            break;

        case 1:
            reg[3] = _mm256_srli_epi64(reg[0], 8);
            reg[3] = _mm256_and_si256(reg[3], reg[9]);
            reg[4] = _mm256_srli_epi64(reg[0], 24);
            reg[10] = _mm256_slli_epi64(reg[1], 40);
            reg[4] = _mm256_or_si256(reg[4], reg[10]);
            reg[4] = _mm256_and_si256(reg[4], reg[7]);
            reg[5] = _mm256_srli_epi64(reg[1], 8);
            reg[5] = _mm256_and_si256(reg[5], reg[7]);
            reg[6] = _mm256_srli_epi64(reg[1], 56);
            reg[10] = _mm256_slli_epi64(reg[2], 8);
            reg[6] = _mm256_or_si256(reg[6], reg[10]);
            reg[6] = _mm256_and_si256(reg[6], reg[8]);
            break;

        case 2:
            reg[3] = _mm256_srli_epi64(reg[0], 16);
            reg[3] = _mm256_and_si256(reg[3], reg[9]);
            reg[4] = _mm256_srli_epi64(reg[0], 32);
            reg[10] = _mm256_slli_epi64(reg[1], 32);
            reg[4] = _mm256_or_si256(reg[4], reg[10]);
            reg[4] = _mm256_and_si256(reg[4], reg[7]);
            reg[5] = _mm256_srli_epi64(reg[1], 16);
            reg[6] = _mm256_and_si256(reg[2], reg[8]);
            break;

        case 3:
            reg[3] = _mm256_srli_epi64(reg[0], 24);
            reg[3] = _mm256_and_si256(reg[3], reg[9]);
            reg[4] = _mm256_srli_epi64(reg[0], 40);
            reg[10] = _mm256_slli_epi64(reg[1], 24);
            reg[4] = _mm256_or_si256(reg[4], reg[10]);
            reg[4] = _mm256_and_si256(reg[4], reg[7]);
            reg[5] = _mm256_srli_epi64(reg[1], 24);
            reg[10] = _mm256_slli_epi64(reg[2], 40);
            reg[5] = _mm256_or_si256(reg[5], reg[10]);
            reg[5] = _mm256_and_si256(reg[5], reg[7]);
            reg[6] = _mm256_srli_epi64(reg[2], 8);
            reg[6] = _mm256_and_si256(reg[6], reg[8]);
            break;

        case 4:
            reg[3] = _mm256_srli_epi64(reg[0], 32);
            reg[3] = _mm256_and_si256(reg[3], reg[9]);
            reg[4] = _mm256_srli_epi64(reg[0], 48);
            reg[10] = _mm256_slli_epi64(reg[1], 16);
            reg[4] = _mm256_or_si256(reg[4], reg[10]);
            reg[4] = _mm256_and_si256(reg[4], reg[7]);
            reg[5] = _mm256_srli_epi64(reg[1], 32);
            reg[10] = _mm256_slli_epi64(reg[2], 32);
            reg[5] = _mm256_or_si256(reg[5], reg[10]);
            reg[5] = _mm256_and_si256(reg[5], reg[7]);
            reg[6] = _mm256_srli_epi64(reg[2], 16);
            reg[6] = _mm256_and_si256(reg[6], reg[8]);
            break;

        case 5:
            reg[3] = _mm256_srli_epi64(reg[0], 40);
            reg[3] = _mm256_and_si256(reg[3], reg[9]);
            reg[4] = _mm256_srli_epi64(reg[0], 56);
            reg[10] = _mm256_slli_epi64(reg[1], 8);
            reg[4] = _mm256_or_si256(reg[4], reg[10]);
            reg[4] = _mm256_and_si256(reg[4], reg[7]);
            reg[5] = _mm256_srli_epi64(reg[1], 40);
            reg[10] = _mm256_slli_epi64(reg[2], 24);
            reg[5] = _mm256_or_si256(reg[5], reg[10]);
            reg[5] = _mm256_and_si256(reg[5], reg[7]);
            reg[6] = _mm256_srli_epi64(reg[2], 24);
            reg[6] = _mm256_and_si256(reg[6], reg[8]);
            break;

        case 6:
            reg[3] = _mm256_srli_epi64(reg[0], 48);
            reg[3] = _mm256_and_si256(reg[3], reg[9]);
            reg[4] = _mm256_and_si256(reg[1], reg[7]);
            reg[5] = _mm256_srli_epi64(reg[1], 48);
            reg[10] = _mm256_slli_epi64(reg[2], 16);
            reg[5] = _mm256_or_si256(reg[5], reg[10]);
            reg[5] = _mm256_and_si256(reg[5], reg[7]);
            reg[6] = _mm256_srli_epi64(reg[2], 32);
            reg[6] = _mm256_and_si256(reg[6], reg[8]);
            break;

        default:
        case 7:
            reg[3] = _mm256_srli_epi64(reg[0], 56);
            reg[10] = _mm256_slli_epi64(reg[1], 8);
            reg[3] = _mm256_or_si256(reg[3], reg[10]);
            reg[3] = _mm256_and_si256(reg[3], reg[9]);
            reg[4] = _mm256_srli_epi64(reg[1], 8);
            reg[4] = _mm256_and_si256(reg[4], reg[7]);
            reg[5] = _mm256_srli_epi64(reg[1], 56);
            reg[10] = _mm256_slli_epi64(reg[2], 8);
            reg[5] = _mm256_or_si256(reg[5], reg[10]);
            reg[5] = _mm256_and_si256(reg[5], reg[7]);
            reg[6] = _mm256_srli_epi64(reg[2], 40);
            reg[6] = _mm256_and_si256(reg[6], reg[8]);
            j += 1;
            break;
        }
        reg[10] = _mm256_slli_epi64(reg[3], 32);
        reg[3] = _mm256_or_si256(reg[3], reg[10]);

        _mm256_store_si256(&sc[i], reg[3]);
        _mm256_store_si256(&rej[i], reg[4]);
        _mm256_store_si256(&sqr[2 * i + 0], reg[5]);
        _mm256_store_si256(&sqr[2 * i + 1], reg[6]);
    }
}

/* Sample four lanes from the CDT distribution. */
static void sample_gauss16_x4(__m256i *r, size_t count)
{
    size_t i, j;
    __m256i sum[NUM_GAUSSIANS] __attribute__((aligned(32)));
    __m256i reg[16];

    reg[0] = _mm256_load_si256(&mask_avx.vec[0]);
    reg[1] = _mm256_load_si256(&mask_avx.vec[1]);
    reg[15] = _mm256_load_si256(&zero_avx.vec);

    /* Process the redundant CDT in three register-sized groups. */
    for (i = 0; i < 11; i++)
        reg[i] = _mm256_load_si256(&CDT_avx.vec[i]);
    reg[11] = _mm256_load_si256(&zero_avx.vec);
    for (i = 0; i < count; i++) {
        reg[12] = _mm256_load_si256(&r[i]);
        reg[13] = _mm256_cmpgt_epi32(reg[12], reg[0]);
        for (j = 1; j < 11; j++) {
            reg[14] = _mm256_cmpgt_epi32(reg[12], reg[j]);
            reg[13] = _mm256_add_epi32(reg[14], reg[13]);
        }
        _mm256_store_si256(&sum[i], reg[13]);
    }

    for (i = 0; i < 11; i++)
        reg[i] = _mm256_load_si256(&CDT_avx.vec[i + 11]);
    for (i = 0; i < count; i++) {
        reg[12] = _mm256_load_si256(&r[i]);
        reg[13] = _mm256_load_si256(&sum[i]);
        for (j = 0; j < 11; j++) {
            reg[14] = _mm256_cmpgt_epi32(reg[12], reg[j]);
            reg[13] = _mm256_add_epi32(reg[14], reg[13]);
        }
        _mm256_store_si256(&sum[i], reg[13]);
    }

    for (i = 0; i < 10; i++)
        reg[i] = _mm256_load_si256(&CDT_avx.vec[i + 22]);
    for (i = 0; i < count; i++) {
        reg[12] = _mm256_load_si256(&r[i]);
        reg[13] = _mm256_load_si256(&sum[i]);
        for (j = 0; j < 10; j++) {
            reg[14] = _mm256_cmpgt_epi32(reg[12], reg[j]);
            reg[13] = _mm256_add_epi32(reg[14], reg[13]);
        }
        reg[14] = _mm256_srli_epi64(reg[13], 32);
        reg[13] = _mm256_add_epi32(reg[13], reg[14]);
        reg[13] = _mm256_sub_epi32(reg[15], reg[13]);
        reg[13] = _mm256_blend_epi32(reg[13], reg[11], 0xaa);
        _mm256_store_si256(&r[i], reg[13]);
    }
}

/* Form precise candidates, their squares, and exponential inputs. */
static void sample_candidates_x4(__m256i *sc, __m256i *sqr, __m256i *rej, size_t count)
{
    size_t i;
    __m256i reg[16];

    reg[7] = _mm256_load_si256(&mask72_avx.vec[0]);
    reg[8] = _mm256_load_si256(&mask72_avx.vec[1]);
    reg[13] = _mm256_load_si256(&consts_avx.vec[0]);
    reg[14] = _mm256_load_si256(&consts_avx.vec[1]);
    reg[15] = _mm256_load_si256(&consts_avx.vec[2]);

    for (i = 0; i < count; i++) {
        reg[0] = _mm256_load_si256(&sc[i]);

        reg[1] = _mm256_load_si256(&sqr[2 * i + 0]);
        reg[2] = _mm256_load_si256(&sqr[2 * i + 1]);
        reg[6] = _mm256_slli_epi64(reg[0], 24);
        reg[2] = _mm256_or_si256(reg[2], reg[6]);

        /* Square the 72-bit candidate as 32-, 16-, and 24-bit limbs. */
        reg[6] = _mm256_srli_epi64(reg[1], 32);
        reg[3] = _mm256_mul_epu32(reg[1], reg[1]);
        reg[4] = _mm256_mul_epu32(reg[1], reg[6]);
        reg[9] = _mm256_mul_epu32(reg[1], reg[2]);
        reg[10] = _mm256_mul_epu32(reg[6], reg[6]);
        reg[11] = _mm256_mul_epu32(reg[6], reg[2]);
        reg[12] = _mm256_mul_epu32(reg[2], reg[2]);

        reg[3] = _mm256_srli_epi64(reg[3], 33);
        reg[3] = _mm256_add_epi64(reg[3], reg[4]);
        reg[3] = _mm256_srli_epi64(reg[3], 16);
        reg[3] = _mm256_add_epi64(reg[3], reg[9]);
        reg[3] = _mm256_srli_epi64(reg[3], 15);
        reg[3] = _mm256_add_epi64(reg[3], reg[10]);
        reg[3] = _mm256_srli_epi64(reg[3], 12);
        reg[6] = _mm256_slli_epi64(reg[11], 5);
        reg[9] = _mm256_slli_epi64(reg[12], 20);
        reg[4] = _mm256_srli_epi64(reg[12], 28);
        reg[9] = _mm256_and_si256(reg[9], reg[7]);

        reg[3] = _mm256_add_epi64(reg[6], reg[3]);
        reg[3] = _mm256_add_epi64(reg[9], reg[3]);
        reg[6] = _mm256_srli_epi64(reg[3], 48);
        reg[4] = _mm256_add_epi64(reg[4], reg[6]);
        reg[3] = _mm256_and_si256(reg[3], reg[7]);

        reg[1] = _mm256_srli_epi64(reg[1], 15);
        reg[2] = _mm256_slli_epi64(reg[2], 33);
        reg[1] = _mm256_or_si256(reg[1], reg[2]);
        reg[1] = _mm256_add_epi64(reg[1], reg[15]);
        reg[1] = _mm256_srli_epi64(reg[1], 1);

        reg[0] = _mm256_mullo_epi16(reg[0], reg[0]);
        reg[6] = _mm256_slli_epi64(reg[0], 68 - 48);
        reg[5] = _mm256_sub_epi64(reg[4], reg[6]);
        reg[5] = _mm256_slli_epi64(reg[5], 20);
        reg[9] = _mm256_srli_epi64(reg[3], 28);
        reg[5] = _mm256_or_si256(reg[5], reg[9]);
        reg[5] = _mm256_add_epi64(reg[5], reg[15]);
        reg[5] = _mm256_srli_epi64(reg[5], 1);

        _mm256_store_si256(&sqr[2 * i + 0], reg[3]);
        _mm256_store_si256(&sqr[2 * i + 1], reg[4]);

        _mm256_store_si256(&rej[i], reg[5]);

        _mm256_store_si256(&sc[i], reg[1]);
    }
}

/* Return the rounded high 48 bits of four signed 48-bit products. */
static inline void smulh48_avx(__m256i *a, const __m256i *b, __m256i *ah, __m256i *bh, __m256i *al,
                               __m256i *bl, __m256i *tmp, __m256i *tmp2, const __m256i *mask24,
                               const __m256i *one23)
{
    /* a is signed Q48 while b is an unsigned 48-bit value.  Splitting both
     * operands at 24 bits keeps every partial product inside signed 32x32
     * multiplication.  AVX2 has no arithmetic 64-bit shift, so restore only
     * the high dword of each negative qword after the logical shift. */
    *tmp2 = _mm256_srai_epi32(*a, 31);
    *ah = _mm256_srli_epi64(*a, 24);
    *ah = _mm256_blend_epi32(*ah, *tmp2, 0xAA);
    *al = _mm256_and_si256(*a, *mask24);
    *bl = _mm256_and_si256(*b, *mask24);
    *bh = _mm256_srli_epi64(*b, 24);

    *a = _mm256_mul_epi32(*al, *bl);
    *tmp = _mm256_mul_epi32(*al, *bh);
    *tmp2 = _mm256_mul_epi32(*ah, *bl);
    *tmp = _mm256_add_epi64(*tmp, *tmp2);
    *a = _mm256_srli_epi64(*a, 24);
    *tmp = _mm256_add_epi64(*tmp, *a);
    *tmp = _mm256_add_epi64(*tmp, *one23);

    *tmp2 = _mm256_srai_epi32(*tmp, 31);
    *tmp = _mm256_srli_epi64(*tmp, 24);
    *tmp = _mm256_blend_epi32(*tmp, *tmp2, 0xAA);
    *tmp2 = _mm256_mul_epi32(*ah, *bh);
    *a = _mm256_add_epi64(*tmp, *tmp2);
}

static const union {
    __m256i vec[9];
    int64_t arr[9 * 4];
} exp_avx = {.arr = {-0x0000B6C6340925AELL,
                     -0x0000B6C6340925AELL,
                     -0x0000B6C6340925AELL,
                     -0x0000B6C6340925AELL,
                     0x0000B4BD4DF85227LL,
                     0x0000B4BD4DF85227LL,
                     0x0000B4BD4DF85227LL,
                     0x0000B4BD4DF85227LL,
                     -0x0000887F727491E2LL,
                     -0x0000887F727491E2LL,
                     -0x0000887F727491E2LL,
                     -0x0000887F727491E2LL,
                     0x0000AAAA643C7E8DLL,
                     0x0000AAAA643C7E8DLL,
                     0x0000AAAA643C7E8DLL,
                     0x0000AAAA643C7E8DLL,
                     -0x0000AAAAA98179E6LL,
                     -0x0000AAAAA98179E6LL,
                     -0x0000AAAAA98179E6LL,
                     -0x0000AAAAA98179E6LL,
                     0x0000FFFFFFFB2E7ALL,
                     0x0000FFFFFFFB2E7ALL,
                     0x0000FFFFFFFB2E7ALL,
                     0x0000FFFFFFFB2E7ALL,
                     -0x0000FFFFFFFFF85FLL,
                     -0x0000FFFFFFFFF85FLL,
                     -0x0000FFFFFFFFF85FLL,
                     -0x0000FFFFFFFFF85FLL,
                     0x0000FFFFFFFFFFFCLL,
                     0x0000FFFFFFFFFFFCLL,
                     0x0000FFFFFFFFFFFCLL,
                     0x0000FFFFFFFFFFFCLL,
                     1 << 23,
                     1 << 23,
                     1 << 23,
                     1 << 23}};

/* Evaluate the fixed-point exponential approximation in four lanes. */
static void approx_exp_4x(__m256i *rej, size_t count)
{
    __m256i reg[16];
    size_t i;
    reg[1] = _mm256_load_si256(&consts_avx.vec[2]);
    reg[2] = _mm256_load_si256(&mask72_avx.vec[1]);
    reg[3] = _mm256_load_si256(&exp_avx.vec[8]);

    reg[11] = _mm256_load_si256(&exp_avx.vec[1]);

    for (i = 0; i < count; i++) {
        reg[0] = _mm256_load_si256(&exp_avx.vec[0]);
        reg[4] = _mm256_load_si256(&rej[i]);

        reg[12] = _mm256_load_si256(&exp_avx.vec[2]);
        reg[13] = _mm256_load_si256(&exp_avx.vec[3]);
        reg[14] = _mm256_load_si256(&exp_avx.vec[4]);

        reg[1] = _mm256_slli_epi64(reg[1], 2);

        smulh48_avx(&reg[0], &reg[4], &reg[5], &reg[6], &reg[7], &reg[8], &reg[9], &reg[10],
                    &reg[2], &reg[3]);
        reg[0] = _mm256_add_epi64(reg[0], reg[1]);
        reg[0] = _mm256_srli_epi64(reg[0], 3);
        reg[0] = _mm256_add_epi64(reg[0], reg[11]);

        smulh48_avx(&reg[0], &reg[4], &reg[5], &reg[6], &reg[7], &reg[8], &reg[9], &reg[10],
                    &reg[2], &reg[3]);
        reg[0] = _mm256_add_epi64(reg[0], reg[1]);
        reg[0] = _mm256_srli_epi64(reg[0], 3);
        reg[0] = _mm256_add_epi64(reg[0], reg[12]);

        reg[1] = _mm256_srli_epi64(reg[1], 1);

        smulh48_avx(&reg[0], &reg[4], &reg[5], &reg[6], &reg[7], &reg[8], &reg[9], &reg[10],
                    &reg[2], &reg[3]);
        reg[0] = _mm256_add_epi64(reg[0], reg[1]);
        reg[0] = _mm256_srli_epi64(reg[0], 2);
        reg[0] = _mm256_add_epi64(reg[0], reg[13]);

        smulh48_avx(&reg[0], &reg[4], &reg[5], &reg[6], &reg[7], &reg[8], &reg[9], &reg[10],
                    &reg[2], &reg[3]);
        reg[0] = _mm256_add_epi64(reg[0], reg[1]);
        reg[0] = _mm256_srli_epi64(reg[0], 2);
        reg[0] = _mm256_add_epi64(reg[0], reg[14]);

        reg[12] = _mm256_load_si256(&exp_avx.vec[5]);
        reg[13] = _mm256_load_si256(&exp_avx.vec[6]);
        reg[14] = _mm256_load_si256(&exp_avx.vec[7]);

        reg[1] = _mm256_srli_epi64(reg[1], 1);

        smulh48_avx(&reg[0], &reg[4], &reg[5], &reg[6], &reg[7], &reg[8], &reg[9], &reg[10],
                    &reg[2], &reg[3]);
        reg[0] = _mm256_add_epi64(reg[0], reg[1]);
        reg[0] = _mm256_srli_epi64(reg[0], 1);
        reg[0] = _mm256_add_epi64(reg[0], reg[12]);

        smulh48_avx(&reg[0], &reg[4], &reg[5], &reg[6], &reg[7], &reg[8], &reg[9], &reg[10],
                    &reg[2], &reg[3]);
        reg[0] = _mm256_add_epi64(reg[0], reg[1]);
        reg[0] = _mm256_srli_epi64(reg[0], 1);
        reg[0] = _mm256_add_epi64(reg[0], reg[13]);

        smulh48_avx(&reg[0], &reg[4], &reg[5], &reg[6], &reg[7], &reg[8], &reg[9], &reg[10],
                    &reg[2], &reg[3]);
        reg[0] = _mm256_add_epi64(reg[0], reg[14]);

        _mm256_store_si256(&rej[i], reg[0]);
    }
}

/* Pack only the first three lanes of each public four-record group. */
static void approx_exp_3x(__m256i *data, size_t count)
{
    const __m256i zero = _mm256_setzero_si256();
    const size_t groups = count / 4;
    for (size_t i = 0; i < groups; i++) {
        __m256i a = data[4 * i], b = data[4 * i + 1];
        __m256i c = data[4 * i + 2], d = data[4 * i + 3];
        data[3 * i] = _mm256_blend_epi32(a, _mm256_permute4x64_epi64(b, 0), 0xc0);
        data[3 * i + 1] = _mm256_permute2x128_si256(
            _mm256_permute4x64_epi64(b, _MM_SHUFFLE(0, 0, 2, 1)), c, 0x20);
        data[3 * i + 2] = _mm256_blend_epi32(
            _mm256_permute4x64_epi64(d, _MM_SHUFFLE(2, 1, 0, 0)),
            _mm256_permute4x64_epi64(c, _MM_SHUFFLE(2, 2, 2, 2)), 0x03);
    }
    approx_exp_4x(data, 3 * groups);
    approx_exp_4x(data + 4 * groups, count - 4 * groups);
    for (size_t i = groups; i-- > 0;) {
        __m256i p = data[3 * i], q = data[3 * i + 1], r = data[3 * i + 2];
        data[4 * i] = _mm256_blend_epi32(p, zero, 0xc0);
        data[4 * i + 1] = _mm256_blend_epi32(_mm256_blend_epi32(
            _mm256_permute4x64_epi64(q, _MM_SHUFFLE(0, 1, 0, 0)),
            _mm256_permute4x64_epi64(p, _MM_SHUFFLE(3, 3, 3, 3)), 0x03), zero, 0xc0);
        data[4 * i + 2] = _mm256_blend_epi32(
            _mm256_permute2x128_si256(q, r, 0x21), zero, 0xc0);
        data[4 * i + 3] = _mm256_blend_epi32(
            _mm256_permute4x64_epi64(r, _MM_SHUFFLE(0, 3, 2, 1)), zero, 0xc0);
    }
}


static const union {
    __m256i vec;
    uint64_t arr[4];
} nolsb_avx = {.arr = {~((uint64_t)1), ~((uint64_t)1), ~((uint64_t)1), ~((uint64_t)1)}};

/* Convert four Bernoulli comparisons to all-zero or all-one masks. */
static inline void _rejcond(__m256i ioreg[3], __m256i reg[5], const __m256i *nolsb,
                            const __m256i *one, const __m256i *zero)
{
    reg[0] = _mm256_and_si256(ioreg[0], *nolsb);

    reg[2] = _mm256_cmpgt_epi64(ioreg[1], reg[0]);
    reg[3] = _mm256_cmpeq_epi64(ioreg[2], *zero);
    reg[3] = _mm256_add_epi64(reg[3], *one);
    reg[4] = _mm256_or_si256(reg[3], ioreg[0]);
    reg[2] = _mm256_and_si256(reg[2], reg[4]);
    reg[2] = _mm256_and_si256(reg[2], *one);
    ioreg[0] = _mm256_sub_epi64(*zero, reg[2]);
}

/* Compute rejection masks for pairs of four-lane batches. */
static void rej_msk_4x(__m256i *rej, const __m256i *exp, const __m256i *sc, size_t count)
{
    __m256i reg[16];
    size_t i;

    reg[15] = _mm256_load_si256(&nolsb_avx.vec);
    reg[14] = _mm256_load_si256(&consts_avx.vec[2]);
    reg[13] = _mm256_load_si256(&zero_avx.vec);

    for (i = 0; i < count; i += 2) {
        reg[0] = _mm256_load_si256(&rej[i]);
        reg[1] = _mm256_load_si256(&exp[i]);
        reg[2] = _mm256_load_si256(&sc[i]);
        reg[8] = _mm256_load_si256(&rej[i + 1]);
        reg[9] = _mm256_load_si256(&exp[i + 1]);
        reg[10] = _mm256_load_si256(&sc[i + 1]);

        _rejcond(&reg[0], &reg[3], &reg[15], &reg[14], &reg[13]);
        _rejcond(&reg[8], &reg[3], &reg[15], &reg[14], &reg[13]);

        _mm256_store_si256(&rej[i], reg[0]);
        _mm256_store_si256(&rej[i + 1], reg[8]);
    }
}

static const union {
    __m256i vec;
    uint64_t arr[4];
} minusone_avx = {.arr = {-1, -1, -1, -1}};

/* Accumulate accepted squared norms and remaining lane lengths. */
static void sum_sqr_4x(uint64_t sqsum[2], const __m256i *sqr, const __m256i *rej, __m256i *len,
                       size_t count)
{
    size_t i, j;
    __m256i reg[16];
    union {
        __m256i vec[2];
        uint64_t arr[8];
    } tmp = {.arr = {0}};

    reg[0] = _mm256_load_si256(&zero_avx.vec);
    reg[1] = _mm256_load_si256(&zero_avx.vec);
    reg[14] = _mm256_load_si256(&minusone_avx.vec);
    reg[15] = _mm256_load_si256(len);

    for (i = 0; i < count; i += 2) {
        reg[2] = _mm256_load_si256(&rej[i + 0]);
        reg[3] = _mm256_load_si256(&rej[i + 1]);

        reg[6] = _mm256_load_si256(&sqr[2 * i + 0]);
        reg[7] = _mm256_load_si256(&sqr[2 * i + 1]);
        reg[8] = _mm256_load_si256(&sqr[2 * i + 2]);
        reg[9] = _mm256_load_si256(&sqr[2 * i + 3]);

        for (j = 0; j < 2; j++) {
            reg[15] = _mm256_add_epi64(reg[15], reg[j + 2]);
            reg[13] = _mm256_cmpgt_epi64(reg[15], reg[14]);
            reg[j + 2] = _mm256_and_si256(reg[j + 2], reg[13]);

            reg[2 * j + 6] = _mm256_and_si256(reg[2 * j + 6], reg[j + 2]);
            reg[2 * j + 7] = _mm256_and_si256(reg[2 * j + 7], reg[j + 2]);

            reg[0] = _mm256_add_epi64(reg[0], reg[2 * j + 6]);
            reg[1] = _mm256_add_epi64(reg[1], reg[2 * j + 7]);
        }
    }

    _mm256_store_si256(&tmp.vec[0], reg[0]);
    _mm256_store_si256(&tmp.vec[1], reg[1]);
    _mm256_store_si256(len, reg[15]);

    sqsum[0] += tmp.arr[0];
    sqsum[0] += tmp.arr[1];
    sqsum[0] += tmp.arr[2];
    sqsum[0] += tmp.arr[3];
    sqsum[1] += tmp.arr[4];
    sqsum[1] += tmp.arr[5];
    sqsum[1] += tmp.arr[6];
    sqsum[1] += tmp.arr[7];

    sqsum[1] += sqsum[0] >> 48;
    sqsum[0] &= (1ULL << 48) - 1;
}

/* Compact accepted lane values into their output arrays. */
static void move_to_mem_4x(uint64_t *r0, uint64_t *r1, uint64_t *r2, uint64_t *r3,
                           const size_t len0, const size_t len1, const size_t len2,
                           const size_t len3, const __m256i *sc, const __m256i *rej, size_t count)
{
    size_t i;
    uint64_t accepted[4];
    size_t ctr[4] = {0};
    __m128d t;

    for (i = 0; i < count; i++) {
        t = _mm_castsi128_pd(_mm256_castsi256_si128(rej[i]));
        _mm_storel_pd((__attribute__((__may_alias__)) double *)&accepted[0], t);
        _mm_storeh_pd((__attribute__((__may_alias__)) double *)&accepted[1], t);
        t = _mm_castsi128_pd(_mm256_extracti128_si256(rej[i], 1));
        _mm_storel_pd((__attribute__((__may_alias__)) double *)&accepted[2], t);
        _mm_storeh_pd((__attribute__((__may_alias__)) double *)&accepted[3], t);

        t = _mm_castsi128_pd(_mm256_castsi256_si128(sc[i]));
        if (ctr[0] < len0) {
            _mm_storel_pd((__attribute__((__may_alias__)) double *)&r0[ctr[0]], t);
            ctr[0] += accepted[0] & 1;
        }
        if (ctr[1] < len1) {
            _mm_storeh_pd((__attribute__((__may_alias__)) double *)&r1[ctr[1]], t);
            ctr[1] += accepted[1] & 1;
        }
        t = _mm_castsi128_pd(_mm256_extracti128_si256(sc[i], 1));
        if (ctr[2] < len2) {
            _mm_storel_pd((__attribute__((__may_alias__)) double *)&r2[ctr[2]], t);
            ctr[2] += accepted[2] & 1;
        }
        if (ctr[3] < len3) {
            _mm_storeh_pd((__attribute__((__may_alias__)) double *)&r3[ctr[3]], t);
            ctr[3] += accepted[3] & 1;
        }
    }
}

void bit_gauss_sample_x4(uint64_t *r0, uint64_t *r1, uint64_t *r2, uint64_t *r3, uint8_t *signs0,
                         uint8_t *signs1, uint8_t *signs2, uint8_t *signs3, fp96_76 *sqsum,
                         const uint8_t seed[BIT_SEEDBYTES], uint16_t nonce0, uint16_t nonce1,
                         uint16_t nonce2, uint16_t nonce3, size_t len0, size_t len1, size_t len2,
                         size_t len3)
{
    size_t ctr0, ctr1, ctr2, ctr3;
    size_t bytecnt, i;
    ALIGNED_UINT8(CRHBYTES + 2) buf[4];
    ALIGNED_UINT8(POLY_HYPERBALL_NBLOCKS_4X * STREAM256_BLOCKBYTES * 4) outbuf;
    ALIGNED_UINT8(SHAKE256_RATE * 2) outbuf2[4];
    ALIGNED_INT64(NUM_GAUSSIANS * 4) sample_candidates;
    ALIGNED_INT64(NUM_GAUSSIANS * 4) exp;
    ALIGNED_INT64(NUM_GAUSSIANS * 4) rejection;
    ALIGNED_INT64(NUM_GAUSSIANS * 8) sqr;
    keccakx4_state state;
    union {
        __m256i vec;
        int64_t arr[4];
    } len = {.arr = {len0, len1, len2, len3}};

    for (i = 0; i < 4; i++) {
        memset(&buf[i], 0, sizeof(buf[i]));
        memcpy(buf[i].coeffs, seed, BIT_SEEDBYTES);
    }

    buf[0].coeffs[CRHBYTES + 0] = nonce0;
    buf[0].coeffs[CRHBYTES + 1] = nonce0 >> 8;
    buf[1].coeffs[CRHBYTES + 0] = nonce1;
    buf[1].coeffs[CRHBYTES + 1] = nonce1 >> 8;
    buf[2].coeffs[CRHBYTES + 0] = nonce2;
    buf[2].coeffs[CRHBYTES + 1] = nonce2 >> 8;
    buf[3].coeffs[CRHBYTES + 0] = nonce3;
    buf[3].coeffs[CRHBYTES + 1] = nonce3 >> 8;

    shake256x4_absorb_once(&state, buf[0].coeffs, buf[1].coeffs, buf[2].coeffs, buf[3].coeffs,
                           CRHBYTES + 2);
    shake256x4_squeezeblocks_vec(&outbuf.vec[0], POLY_HYPERBALL_NBLOCKS_4X, &state);

    for (i = 0; i < len0 / 8; i++)
        signs0[i] = outbuf.coeffs[(i % 8) + (i / 8) * 32];
    for (i = 0; i < len1 / 8; i++)
        signs1[i] = outbuf.coeffs[(i % 8) + (i / 8) * 32 + 8];
    for (i = 0; i < len2 / 8; i++)
        signs2[i] = outbuf.coeffs[(i % 8) + (i / 8) * 32 + 16];
    for (i = 0; i < len3 / 8; i++)
        signs3[i] = outbuf.coeffs[(i % 8) + (i / 8) * 32 + 24];

    /* Vectorized Gaussian rejection pipeline. */
    preprocessing_x4(sample_candidates.vec, sqr.vec, rejection.vec, &outbuf.vec[N / 64],
                     NUM_GAUSSIANS);

    sample_gauss16_x4(sample_candidates.vec, NUM_GAUSSIANS);

    sample_candidates_x4(sample_candidates.vec, sqr.vec, exp.vec, NUM_GAUSSIANS);

    if (len3 == 0)
        approx_exp_3x(exp.vec, NUM_GAUSSIANS);
    else
        approx_exp_4x(exp.vec, NUM_GAUSSIANS);

    rej_msk_4x(rejection.vec, exp.vec, sample_candidates.vec, NUM_GAUSSIANS);
    BIT_CT_DECLASSIFY(rejection.vec, NUM_GAUSSIANS * sizeof *rejection.vec);

    sum_sqr_4x(&sqsum->limb48[0], sqr.vec, rejection.vec, &len.vec, NUM_GAUSSIANS);

    move_to_mem_4x(r0, r1, r2, r3, len0 - len0 % N, len1 - len1 % N, len2 - len2 % N,
                   len3 - len3 % N, sample_candidates.vec, rejection.vec, NUM_GAUSSIANS);

    ctr0 = len.arr[0] > 0 ? len0 - len.arr[0] : len0;
    ctr1 = len.arr[1] > 0 ? len1 - len.arr[1] : len1;
    ctr2 = len.arr[2] > 0 ? len2 - len.arr[2] : len2;
    ctr3 = len.arr[3] > 0 ? len3 - len.arr[3] : len3;

    {
        const size_t consumed = N / 8 + NUM_GAUSSIANS * GAUSS_RAND_BYTES;
        uint8_t *tail[4] = {outbuf2[0].coeffs, outbuf2[1].coeffs, outbuf2[2].coeffs,
                            outbuf2[3].coeffs};

        bytecnt = POLY_HYPERBALL_NBLOCKS_4X * STREAM256_BLOCKBYTES - consumed;
        for (size_t lane = 0; lane < 4; lane++) {
            for (i = 0; i < bytecnt; i++) {
                size_t pos = consumed + i;
                tail[lane][i] = outbuf.coeffs[(pos / 8) * 32 + lane * 8 + pos % 8];
            }
        }
    }

    while (ctr0 < len0 || ctr1 < len1 || ctr2 < len2 || ctr3 < len3) {
        size_t available;

        shake256x4_squeezeblocks(&outbuf2[0].coeffs[bytecnt], &outbuf2[1].coeffs[bytecnt],
                                 &outbuf2[2].coeffs[bytecnt], &outbuf2[3].coeffs[bytecnt], 1,
                                 &state);
        available = bytecnt + STREAM256_BLOCKBYTES;

        if (ctr0 < len0)
            ctr0 += bit_gauss_process_buffer(r0 + ctr0, sqsum, outbuf2[0].coeffs, available,
                                             len0 - ctr0, len0 % N);
        if (ctr1 < len1)
            ctr1 += bit_gauss_process_buffer(r1 + ctr1, sqsum, outbuf2[1].coeffs, available,
                                             len1 - ctr1, len1 % N);
        if (ctr2 < len2)
            ctr2 += bit_gauss_process_buffer(r2 + ctr2, sqsum, outbuf2[2].coeffs, available,
                                             len2 - ctr2, len2 % N);
        if (ctr3 < len3)
            ctr3 += bit_gauss_process_buffer(r3 + ctr3, sqsum, outbuf2[3].coeffs, available,
                                             len3 - ctr3, len3 % N);

        bytecnt = available % GAUSS_RAND_BYTES;
        if (bytecnt != 0 && (ctr0 < len0 || ctr1 < len1 || ctr2 < len2 || ctr3 < len3)) {
            for (i = 0; i < 4; i++)
                memmove(outbuf2[i].coeffs, outbuf2[i].coeffs + available - bytecnt, bytecnt);
        }
    }
}

#define GAUSS_X6_STREAMS 6
#define GAUSS_X6_BLOCKS 66
#define GAUSS_X6_BLOCK_BYTES (GAUSS_X6_BLOCKS * STREAM256_BLOCKBYTES)
#define GAUSS_X6_BLOCK_VECS (GAUSS_X6_BLOCK_BYTES / 8)
#define GAUSS_X6_A_CANDIDATES 520
#define GAUSS_X6_B_COMMON_CANDIDATES 520
#define GAUSS_X6_B_TAIL_CANDIDATES 4
#define GAUSS_X6_C_CANDIDATES 528
#define GAUSS_X6_MAX_CANDIDATES GAUSS_X6_C_CANDIDATES
#define GAUSS_X6_COMMON_BYTES (GAUSS_X6_B_COMMON_CANDIDATES * GAUSS_RAND_BYTES)
#define GAUSS_X6_COMMON_PADDED_BYTES (((GAUSS_X6_COMMON_BYTES + 7) / 8) * 8)
#define GAUSS_X6_TAIL_STREAM_BYTES (8 * GAUSS_RAND_BYTES)
#define GAUSS_X6_TAIL_LANE_BYTES (4 * GAUSS_RAND_BYTES)
#define GAUSS_X6_TAIL_PADDED_BYTES (((GAUSS_X6_TAIL_LANE_BYTES + 7) / 8) * 8)

#if BIT_K + BIT_L != GAUSS_X6_STREAMS
#error "The fixed Gaussian x6 schedule requires K+L=6"
#endif
#if N / 8 + GAUSS_X6_A_CANDIDATES * GAUSS_RAND_BYTES + 8 != GAUSS_X6_BLOCK_BYTES
#error "Gaussian x6 phase A no longer fills exactly 66 SHAKE256 blocks"
#endif
#if 8 + GAUSS_X6_BLOCK_BYTES != GAUSS_X6_C_CANDIDATES * GAUSS_RAND_BYTES + 8
#error "Gaussian x6 continuation no longer preserves its eight-byte carry"
#endif
#if GAUSS_X6_B_COMMON_CANDIDATES + 8 != GAUSS_X6_C_CANDIDATES
#error "Gaussian x6 phase B candidate split is inconsistent"
#endif

static void gauss_x6_prepend_carry8(__m256i *buf, size_t vectors, uint64_t carry[4])
{
    __m256i prefix = _mm256_set_epi64x(carry[3], carry[2], carry[1], carry[0]);
    union {
        __m256i vec;
        uint64_t lane[4];
    } tail;

    for (size_t i = 0; i < vectors; i++) {
        __m256i current = buf[i];

        buf[i] = prefix;
        prefix = current;
    }
    tail.vec = prefix;
    for (size_t lane = 0; lane < 4; lane++)
        carry[lane] = tail.lane[lane];
}

static void gauss_x6_pack_lanes(__m256i *packed, size_t words, const uint8_t *lane0,
                                const uint8_t *lane1, const uint8_t *lane2, const uint8_t *lane3)
{
    const uint8_t *lanes[4] = {lane0, lane1, lane2, lane3};

    for (size_t word = 0; word < words; word++) {
        uint64_t value[4];

        for (size_t lane = 0; lane < 4; lane++)
            memcpy(&value[lane], lanes[lane] + 8 * word, sizeof(value[lane]));
        packed[word] = _mm256_set_epi64x(value[3], value[2], value[1], value[0]);
    }
}

static void gauss_x6_pipeline(__m256i *sample_candidates, __m256i *squares, __m256i *exponents,
                              __m256i *rejection, const __m256i *records, size_t count)
{
    preprocessing_x4(sample_candidates, squares, rejection, records, count);
    sample_gauss16_x4(sample_candidates, count);
    sample_candidates_x4(sample_candidates, squares, exponents, count);
    approx_exp_4x(exponents, count);
    rej_msk_4x(rejection, exponents, sample_candidates, count);
    BIT_CT_DECLASSIFY(rejection, count * sizeof *rejection);
}

static inline void gauss_x6_renormalize(fp96_76 *sum)
{
    sum->limb48[1] += sum->limb48[0] >> 48;
    sum->limb48[0] &= (1ULL << 48) - 1;
}

static void gauss_x6_consume(uint64_t samples[GAUSS_X6_STREAMS * N], fp96_76 *sqsum,
                             size_t accepted[GAUSS_X6_STREAMS],
                             const size_t needed[GAUSS_X6_STREAMS], const unsigned int streams[4],
                             const __m256i *sample_candidates, const __m256i *squares,
                             const __m256i *rejection, size_t count)
{
    union {
        __m256i vec;
        uint64_t lane[4];
    } sample, low, high, accept;

    for (size_t i = 0; i < count; i++) {
        sample.vec = sample_candidates[i];
        low.vec = squares[2 * i];
        high.vec = squares[2 * i + 1];
        accept.vec = rejection[i];
        for (size_t lane = 0; lane < 4; lane++) {
            unsigned int stream = streams[lane];

            if ((accept.lane[lane] & 1U) == 0 || accepted[stream] >= needed[stream])
                continue;
            if (accepted[stream] < N)
                samples[(size_t)stream * N + accepted[stream]] = sample.lane[lane];
            sqsum->limb48[0] += low.lane[lane];
            sqsum->limb48[1] += high.lane[lane];
            accepted[stream]++;
        }
    }
    gauss_x6_renormalize(sqsum);
}

static void gauss_x6_consume_unique(uint64_t samples[GAUSS_X6_STREAMS * N], fp96_76 *sqsum,
                                    size_t accepted[GAUSS_X6_STREAMS],
                                    const size_t needed[GAUSS_X6_STREAMS],
                                    const unsigned int streams[4], const __m256i *sample_candidates,
                                    const __m256i *squares, const __m256i *rejection, size_t count)
{
    uint64_t *out[4];
    size_t store[4];
    size_t remaining[4];
    union {
        __m256i vec;
        int64_t lane[4];
    } left;

    for (size_t lane = 0; lane < 4; lane++) {
        unsigned int stream = streams[lane];
        size_t stored = accepted[stream] < N ? accepted[stream] : N;

        out[lane] = samples + (size_t)stream * N + stored;
        store[lane] = N - stored;
        remaining[lane] = needed[stream] - accepted[stream];
        left.lane[lane] = (int64_t)remaining[lane];
    }
    sum_sqr_4x(sqsum->limb48, squares, rejection, &left.vec, count);
    move_to_mem_4x(out[0], out[1], out[2], out[3], store[0], store[1], store[2], store[3],
                   sample_candidates, rejection, count);
    for (size_t lane = 0; lane < 4; lane++) {
        unsigned int stream = streams[lane];
        size_t taken =
            left.lane[lane] > 0 ? remaining[lane] - (size_t)left.lane[lane] : remaining[lane];

        accepted[stream] += taken;
    }
}

void bit_gauss_sample_x6(uint64_t samples[(BIT_K + BIT_L) * BIT_N],
                         uint8_t signs[(BIT_K + BIT_L) * (BIT_N / 8)], fp96_76 *sqsum,
                         const uint8_t seed[BIT_SEEDBYTES], uint16_t nonce)
{
    static const unsigned int map_a[4] = {0, 1, 2, 3};
    static const unsigned int map_b[4] = {4, 5, 0, 1};
    static const unsigned int map_b_tail[4] = {0, 1, 0, 1};
    static const unsigned int map_c[4] = {4, 5, 2, 3};
    const size_t needed[GAUSS_X6_STREAMS] = {N + 1U, N + 1U, N + 1U, N + 1U, N, N};
    ALIGNED_UINT8(CRHBYTES + 2) extseed[GAUSS_X6_STREAMS];
    ALIGNED_UINT8(GAUSS_X6_BLOCK_BYTES * 4) random;
    ALIGNED_INT64(GAUSS_X6_MAX_CANDIDATES * 4) sample_candidates;
    ALIGNED_INT64(GAUSS_X6_MAX_CANDIDATES * 4) exponents;
    ALIGNED_INT64(GAUSS_X6_MAX_CANDIDATES * 4) rejection;
    ALIGNED_INT64(GAUSS_X6_MAX_CANDIDATES * 8) squares;
    uint8_t common[4][GAUSS_X6_COMMON_PADDED_BYTES] __attribute__((aligned(32)));
    uint8_t continuation[2][8 + GAUSS_X6_BLOCK_BYTES] __attribute__((aligned(32)));
    uint8_t tail_stream[2][GAUSS_X6_TAIL_STREAM_BYTES];
    uint8_t tail_lane[4][GAUSS_X6_TAIL_PADDED_BYTES] __attribute__((aligned(32))) = {{0}};
    __m256i common_packed[GAUSS_X6_COMMON_PADDED_BYTES / 8] __attribute__((aligned(32)));
    __m256i tail_packed[GAUSS_X6_TAIL_PADDED_BYTES / 8] __attribute__((aligned(32)));
    uint64_t carry[GAUSS_X6_STREAMS];
    uint8_t refill[GAUSS_X6_STREAMS][STREAM256_BLOCKBYTES + 8];
    size_t accepted[GAUSS_X6_STREAMS] = {0};
    keccakx4_state state_a, state_b;
    shake256ctx scalar_state[GAUSS_X6_STREAMS];

    for (size_t stream = 0; stream < GAUSS_X6_STREAMS; stream++) {
        memset(&extseed[stream], 0, sizeof(extseed[stream]));
        memcpy(extseed[stream].coeffs, seed, BIT_SEEDBYTES);
        extseed[stream].coeffs[CRHBYTES] = (uint8_t)(nonce + stream);
        extseed[stream].coeffs[CRHBYTES + 1] = (uint8_t)((nonce + stream) >> 8);
    }

    shake256x4_absorb_once(&state_a, extseed[0].coeffs, extseed[1].coeffs, extseed[2].coeffs,
                           extseed[3].coeffs, CRHBYTES + 2);
    shake256x4_squeezeblocks_vec(random.vec, GAUSS_X6_BLOCKS, &state_a);
    for (size_t lane = 0; lane < 4; lane++) {
        bit_keccakx4_extract_bytes(signs + lane * (N / 8), random.vec, (unsigned int)lane, 0,
                                   N / 8);
        bit_keccakx4_extract_bytes((uint8_t *)&carry[lane], random.vec, (unsigned int)lane,
                                   GAUSS_X6_BLOCK_BYTES - 8, 8);
    }
    gauss_x6_pipeline(sample_candidates.vec, squares.vec, exponents.vec, rejection.vec,
                      random.vec + N / 64, GAUSS_X6_A_CANDIDATES);
    gauss_x6_consume_unique(samples, sqsum, accepted, needed, map_a, sample_candidates.vec,
                            squares.vec, rejection.vec, GAUSS_X6_A_CANDIDATES);

    shake256x4_absorb_once(&state_b, extseed[4].coeffs, extseed[5].coeffs, extseed[4].coeffs,
                           extseed[5].coeffs, CRHBYTES + 2);
    bit_keccakx4_copy_lanes2(&state_b, 2, 3, &state_a, 0, 1);
    shake256x4_squeezeblocks_vec(random.vec, GAUSS_X6_BLOCKS, &state_b);
    for (size_t lane = 0; lane < 2; lane++) {
        bit_keccakx4_extract_bytes(signs + (lane + 4) * (N / 8), random.vec, (unsigned int)lane, 0,
                                   N / 8);
        bit_keccakx4_extract_bytes(common[lane], random.vec, (unsigned int)lane, N / 8,
                                   GAUSS_X6_COMMON_BYTES);
        bit_keccakx4_extract_bytes((uint8_t *)&carry[lane + 4], random.vec, (unsigned int)lane,
                                   GAUSS_X6_BLOCK_BYTES - 8, 8);
    }
    for (size_t lane = 0; lane < 2; lane++) {
        memcpy(continuation[lane], &carry[lane], 8);
        bit_keccakx4_extract_bytes(continuation[lane] + 8, random.vec, (unsigned int)(lane + 2), 0,
                                   GAUSS_X6_BLOCK_BYTES);
        memcpy(common[lane + 2], continuation[lane], GAUSS_X6_COMMON_BYTES);
        memcpy(tail_stream[lane], continuation[lane] + GAUSS_X6_COMMON_BYTES,
               GAUSS_X6_TAIL_STREAM_BYTES);
        memcpy(&carry[lane], continuation[lane] + GAUSS_X6_BLOCK_BYTES, 8);
    }
    gauss_x6_pack_lanes(common_packed, GAUSS_X6_COMMON_PADDED_BYTES / 8, common[0], common[1],
                        common[2], common[3]);
    gauss_x6_pipeline(sample_candidates.vec, squares.vec, exponents.vec, rejection.vec,
                      common_packed, GAUSS_X6_B_COMMON_CANDIDATES);
    gauss_x6_consume_unique(samples, sqsum, accepted, needed, map_b, sample_candidates.vec,
                            squares.vec, rejection.vec, GAUSS_X6_B_COMMON_CANDIDATES);

    for (size_t i = 0; i < 4; i++) {
        memcpy(tail_lane[0] + i * GAUSS_RAND_BYTES, tail_stream[0] + (2 * i) * GAUSS_RAND_BYTES,
               GAUSS_RAND_BYTES);
        memcpy(tail_lane[1] + i * GAUSS_RAND_BYTES, tail_stream[1] + (2 * i) * GAUSS_RAND_BYTES,
               GAUSS_RAND_BYTES);
        memcpy(tail_lane[2] + i * GAUSS_RAND_BYTES, tail_stream[0] + (2 * i + 1) * GAUSS_RAND_BYTES,
               GAUSS_RAND_BYTES);
        memcpy(tail_lane[3] + i * GAUSS_RAND_BYTES, tail_stream[1] + (2 * i + 1) * GAUSS_RAND_BYTES,
               GAUSS_RAND_BYTES);
    }
    gauss_x6_pack_lanes(tail_packed, GAUSS_X6_TAIL_PADDED_BYTES / 8, tail_lane[0], tail_lane[1],
                        tail_lane[2], tail_lane[3]);
    gauss_x6_pipeline(sample_candidates.vec, squares.vec, exponents.vec, rejection.vec, tail_packed,
                      GAUSS_X6_B_TAIL_CANDIDATES);
    gauss_x6_consume(samples, sqsum, accepted, needed, map_b_tail, sample_candidates.vec,
                     squares.vec, rejection.vec, GAUSS_X6_B_TAIL_CANDIDATES);
    bit_keccakx4_export_lanes2(scalar_state[0].ctx, scalar_state[1].ctx, &state_b, 2, 3);

    bit_keccakx4_copy_lanes2(&state_b, 2, 3, &state_a, 2, 3);
    shake256x4_squeezeblocks_vec(random.vec, GAUSS_X6_BLOCKS, &state_b);
    {
        uint64_t phase_carry[4] = {carry[4], carry[5], carry[2], carry[3]};

        gauss_x6_prepend_carry8(random.vec, GAUSS_X6_BLOCK_VECS, phase_carry);
        carry[4] = phase_carry[0];
        carry[5] = phase_carry[1];
        carry[2] = phase_carry[2];
        carry[3] = phase_carry[3];
    }
    gauss_x6_pipeline(sample_candidates.vec, squares.vec, exponents.vec, rejection.vec, random.vec,
                      GAUSS_X6_C_CANDIDATES);
    gauss_x6_consume_unique(samples, sqsum, accepted, needed, map_c, sample_candidates.vec,
                            squares.vec, rejection.vec, GAUSS_X6_C_CANDIDATES);
    bit_keccakx4_export_all(scalar_state[4].ctx, scalar_state[5].ctx, scalar_state[2].ctx,
                            scalar_state[3].ctx, &state_b);

    for (size_t stream = 0; stream < GAUSS_X6_STREAMS; stream++)
        memcpy(refill[stream], &carry[stream], 8);
    for (;;) {
        int done = 1;

        for (size_t stream = 0; stream < GAUSS_X6_STREAMS; stream++) {
            size_t got;

            if (accepted[stream] >= needed[stream])
                continue;
            done = 0;
            shake256_squeezeblocks(refill[stream] + 8, 1, &scalar_state[stream]);
            got = bit_gauss_process_buffer(
                samples + stream * N + (accepted[stream] < N ? accepted[stream] : N), sqsum,
                refill[stream], STREAM256_BLOCKBYTES + 8, needed[stream] - accepted[stream],
                (int)(needed[stream] % N));
            accepted[stream] += got;
            memcpy(refill[stream], refill[stream] + STREAM256_BLOCKBYTES, 8);
        }
        if (done)
            break;
    }
}

/* Seven SHAKE streams occupy two four-lane batches.
 * The duplicate final lane contributes no samples or squared norm. */
void bit_gauss_sample_x7(uint64_t samples[BIT_PARABOLA_BLOCKS * BIT_N],
                         uint8_t signs[BIT_PARABOLA_BLOCKS * (BIT_N / 8)], fp96_76 *sqsum,
                         const uint8_t seed[BIT_SEEDBYTES], uint16_t nonce)
{
    bit_gauss_sample_x4(samples, samples + BIT_N, samples + 2 * BIT_N, samples + 3 * BIT_N, signs,
                        signs + BIT_N / 8, signs + 2 * (BIT_N / 8), signs + 3 * (BIT_N / 8), sqsum,
                        seed, nonce, (uint16_t)(nonce + 1U), (uint16_t)(nonce + 2U),
                        (uint16_t)(nonce + 3U), BIT_N + 1U, BIT_N + 1U, BIT_N + 1U, BIT_N + 1U);
    bit_gauss_sample_x4(samples + 4 * BIT_N, samples + 5 * BIT_N, samples + 6 * BIT_N, samples,
                        signs + 4 * (BIT_N / 8), signs + 5 * (BIT_N / 8), signs + 6 * (BIT_N / 8),
                        signs, sqsum, seed, (uint16_t)(nonce + 4U), (uint16_t)(nonce + 5U),
                        (uint16_t)(nonce + 6U), (uint16_t)(nonce + 6U), BIT_N, BIT_N, BIT_N, 0);
}

