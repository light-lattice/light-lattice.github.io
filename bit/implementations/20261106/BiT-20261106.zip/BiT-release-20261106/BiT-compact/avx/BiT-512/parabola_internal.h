/* Copyright (c) 2026 Hang Zhang. */

#ifndef PARABOLA_INTERNAL_H
#define PARABOLA_INTERNAL_H

#include <stddef.h>
#include <stdint.h>

#include "params.h"
#include "symmetric.h"

typedef struct {
    uint64_t limb48[2];
} fp96_76;

typedef struct {
    uint64_t z_norm2;
    uint64_t v_norm2;
    int64_t dot;
} parabola_fixed_stats;

uint64_t bit_parabola_scale_round_avx(int32_t out[BIT_N], const uint64_t samples[BIT_N],
                                      const uint8_t signs[BIT_N / 8], const fp96_76 *scale);
void bit_parabola_accumulate_response_stats_avx(parabola_fixed_stats *stats,
                                                const int32_t mask[BIT_N],
                                                const bit_coeff_t shift[BIT_N], int32_t shift_scale);

void bit_gauss_sample_x6(uint64_t samples[(BIT_K + BIT_L) * BIT_N],
                         uint8_t signs[(BIT_K + BIT_L) * (BIT_N / 8)], fp96_76 *sqsum,
                         const uint8_t seed[BIT_SEEDBYTES], uint16_t nonce);
void bit_gauss_sample_x7(uint64_t samples[BIT_PARABOLA_BLOCKS * BIT_N],
                         uint8_t signs[BIT_PARABOLA_BLOCKS * (BIT_N / 8)], fp96_76 *sqsum,
                         const uint8_t seed[BIT_SEEDBYTES], uint16_t nonce);

/* Scalar continuation used only when an AVX2 batch does not contain enough
 * accepted Gaussian candidates. */
size_t bit_gauss_process_buffer(uint64_t *samples, fp96_76 *sqsum, const uint8_t *buf,
                                size_t buflen, size_t needed, int drop_last);

void bit_gauss_sample_x4(uint64_t *r0, uint64_t *r1, uint64_t *r2, uint64_t *r3, uint8_t *signs0,
                         uint8_t *signs1, uint8_t *signs2, uint8_t *signs3, fp96_76 *sqsum,
                         const uint8_t seed[BIT_SEEDBYTES], uint16_t nonce0, uint16_t nonce1,
                         uint16_t nonce2, uint16_t nonce3, size_t len0, size_t len1, size_t len2,
                         size_t len3);


#endif
