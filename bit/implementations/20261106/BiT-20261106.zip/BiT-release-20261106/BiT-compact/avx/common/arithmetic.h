/* Copyright (c) 2026 Hang Zhang. */
#ifndef BIT_AVX_ARITHMETIC_H
#define BIT_AVX_ARITHMETIC_H
#include <immintrin.h>
#include "params.h"

static inline __m256i bit_load_coeff8(const bit_coeff_t *p)
{
#if BIT_N == 1024
    return _mm256_loadu_si256((const __m256i *)p);
#else
    return _mm256_cvtepi16_epi32(_mm_loadu_si128((const __m128i *)p));
#endif
}

static inline void bit_store_coeff8(bit_coeff_t *p, __m256i x)
{
#if BIT_N == 1024
    _mm256_storeu_si256((__m256i *)p, x);
#else
    _mm_storeu_si128((__m128i *)p, _mm_packs_epi32(
        _mm256_castsi256_si128(x), _mm256_extracti128_si256(x, 1)));
#endif
}

static inline __m256i bit_srai64_32(__m256i x)
{
    __m256i sign = _mm256_cmpgt_epi64(_mm256_setzero_si256(), x);
    return _mm256_or_si256(_mm256_srli_epi64(x, 32), _mm256_slli_epi64(sign, 32));
}

static inline __m256i bit_reduce_unsigned8(__m256i x)
{
    const __m256i multiplier = _mm256_set1_epi32(BIT_BARRETT_MULT);
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    __m256i even = bit_srai64_32(_mm256_mul_epi32(x, multiplier));
    __m256i odd = bit_srai64_32(_mm256_mul_epi32(_mm256_srli_epi64(x, 32), multiplier));
    __m256i quotient = _mm256_blend_epi32(even, _mm256_slli_epi64(odd, 32), 0xaa);

    x = _mm256_sub_epi32(x, _mm256_mullo_epi32(quotient, q));
    x = _mm256_add_epi32(x, _mm256_and_si256(_mm256_srai_epi32(x, 31), q));
    x = _mm256_sub_epi32(x, q);
    return _mm256_add_epi32(x, _mm256_and_si256(_mm256_srai_epi32(x, 31), q));
}

static inline __m256i bit_center8(__m256i x)
{
    return _mm256_sub_epi32(x, _mm256_and_si256(
        _mm256_cmpgt_epi32(x, _mm256_set1_epi32(BIT_Q_HALF)), _mm256_set1_epi32(BIT_Q)));
}

#endif
