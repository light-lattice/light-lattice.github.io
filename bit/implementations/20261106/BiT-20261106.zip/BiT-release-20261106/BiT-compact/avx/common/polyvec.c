/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */
#include "polyvec.h"
#include "align.h"
#include "params.h"
#include "symmetric.h"
#include <stddef.h>
#include <string.h>
#include "fips202x4.h"
#include "endian.h"
#include "arithmetic.h"
#include "uniform_compact_table.inc"

int polyvecl_sample_S1(polyvecl *v, const uint8_t *seed, uint16_t *nonce)
{
    poly *out[4] = {&v->vec[0], &v->vec[1], &v->vec[2], NULL};
    return poly_sample_S1_x4(out, BIT_L, seed, nonce);
}

int polyvec_sample_S1_keypair(polyvecl *s, polyveck *e, const uint8_t *seed, uint16_t *nonce)
{
    poly *first[4] = {&s->vec[0], &s->vec[1], &s->vec[2], &e->vec[0]};
    poly *last[4] = {&e->vec[1], &e->vec[2], NULL, NULL};
    if (poly_sample_S1_x4(first, 4, seed, nonce) != 0)
        return -1;
    return poly_sample_S1_x4(last, 2, seed, nonce);
}


int polyveck_sample_S1(polyveck *v, const uint8_t *seed, uint16_t *nonce)
{
    poly *out[4] = {&v->vec[0], &v->vec[1], &v->vec[2], NULL};
    return poly_sample_S1_x4(out, BIT_K, seed, nonce);
}


#if BIT_N == 1024
#define MATRIX_XOF_BUFFER_SIZE (4 * BIT_XOF128_RATE)
#else
#define MATRIX_XOF_BUFFER_SIZE (3 * BIT_XOF128_RATE)
#endif


static void matrix_store(poly_ntt *a, size_t index, uint32_t value)
{
#if BIT_N == 1024
    a->coeffs[index] = reduce_to_signed(value);
#else
    a->coeffs[index] = (bit_coeff_t)value;
#endif
}

static void matrix_parse(poly_ntt *a, size_t *count, const uint8_t *bytes, size_t length,
                         uint32_t *carry, unsigned *bits)
{
    size_t pos = 0;
    const unsigned width = BIT_PUBLIC_COEFF_BITS;
    const uint32_t mask = (1U << BIT_PUBLIC_COEFF_BITS) - 1U;
    while (*bits && *count < BIT_N) {
        while (*bits < width && pos < length) {
            *carry |= (uint32_t)bytes[pos++] << *bits;
            *bits += 8;
        }
        if (*bits < width)
            return;
        uint32_t value = *carry & mask;
        *carry >>= width;
        *bits -= width;
        if (value < BIT_Q)
            matrix_store(a, (*count)++, value);
    }
#if BIT_PUBLIC_COEFF_BITS == 12
    const __m256i gather = _mm256_setr_epi8(
        0,1,2,-1, 1,2,3,-1, 3,4,5,-1, 4,5,6,-1,
        6,7,8,-1, 7,8,9,-1, 9,10,11,-1, 10,11,12,-1);
    const __m256i shifts = _mm256_setr_epi32(0,4,0,4,0,4,0,4);
#else
    const __m256i gather = _mm256_setr_epi8(
        0,1,2,-1, 1,2,3,-1, 3,4,5,-1, 4,5,6,-1,
        6,7,8,-1, 8,9,10,-1, 9,10,11,-1, 11,12,13,-1);
    const __m256i shifts = _mm256_setr_epi32(0,5,2,7,4,1,6,3);
#endif
    while (*count + 8 <= BIT_N && pos + 16 <= length) {
        __m128i input = _mm_loadu_si128((const __m128i *)(bytes + pos));
        __m256i values = _mm256_shuffle_epi8(_mm256_broadcastsi128_si256(input), gather);
        values = _mm256_and_si256(_mm256_srlv_epi32(values, shifts), _mm256_set1_epi32(mask));
        uint32_t valid = ~(uint32_t)_mm256_movemask_ps(_mm256_castsi256_ps(
            _mm256_cmpgt_epi32(values, _mm256_set1_epi32(BIT_Q - 1)))) & 255U;
        pos += width;
        if (valid != 0) {
            __m128i indices = _mm_cvtsi64_si128((long long)bit_uniform_compact_indices[valid]);
            values = _mm256_permutevar8x32_epi32(values, _mm256_cvtepu8_epi32(indices));
#if BIT_N == 1024
            values = bit_center8(values);
#endif
            bit_store_coeff8(a->coeffs + *count, values);
            *count += (unsigned)__builtin_popcount(valid);
        }
    }
    while (*count < BIT_N) {
        while (*bits < width && pos < length) {
            *carry |= (uint32_t)bytes[pos++] << *bits;
            *bits += 8;
        }
        if (*bits < width)
            break;
        uint32_t value = *carry & mask;
        *carry >>= width;
        *bits -= width;
        if (value < BIT_Q)
            matrix_store(a, (*count)++, value);
    }
}

static int poly_uniform_ntt(poly_ntt *a, const uint8_t *seed, size_t row, size_t col)
{
    uint8_t bytes[MATRIX_XOF_BUFFER_SIZE], message[BIT_SEEDBYTES + 2];
    bit_xof128_state state;
    size_t count = 0;
    uint32_t carry = 0;
    unsigned bits = 0;
    memcpy(message, seed, BIT_SEEDBYTES);
    message[BIT_SEEDBYTES] = (uint8_t)col;
    message[BIT_SEEDBYTES + 1] = (uint8_t)row;
    bit_xof128_init(&state, message, sizeof message);
    while (count < BIT_N) {
        if (bit_xof128_squeeze(&state, bytes, sizeof bytes) != 0) {
            bit_xof128_zeroize(&state);
            return -1;
        }
        matrix_parse(a, &count, bytes, sizeof bytes, &carry, &bits);
    }
    bit_xof128_zeroize(&state);
    return 0;
}

static void poly_uniform_ntt_x4(poly_ntt *a[4], const uint8_t *seed, size_t base)
{
    BIT_ALIGN_64 uint8_t bytes[4][MATRIX_XOF_BUFFER_SIZE];
    uint8_t messages[4][BIT_SEEDBYTES + 2];
    keccakx4_state state;
    size_t count[4] = {0};
    uint32_t carry[4] = {0};
    unsigned bits[4] = {0};
    for (size_t lane = 0; lane < 4; lane++) {
        size_t index = base + lane;
        memcpy(messages[lane], seed, BIT_SEEDBYTES);
        messages[lane][BIT_SEEDBYTES] = (uint8_t)(index % BIT_L);
        messages[lane][BIT_SEEDBYTES + 1] = (uint8_t)(index / BIT_L);
    }
    shake128x4_absorb_once(&state, messages[0], messages[1], messages[2], messages[3],
                           sizeof messages[0]);
    while (count[0] < BIT_N || count[1] < BIT_N || count[2] < BIT_N || count[3] < BIT_N) {
        shake128x4_squeezeblocks(bytes[0], bytes[1], bytes[2], bytes[3],
                                 MATRIX_XOF_BUFFER_SIZE / SHAKE128_RATE, &state);
        for (size_t lane = 0; lane < 4; lane++)
            if (count[lane] < BIT_N)
                matrix_parse(a[lane], &count[lane], bytes[lane], sizeof bytes[lane],
                             &carry[lane], &bits[lane]);
    }
    bit_secure_zero(&state, sizeof state);
    bit_secure_zero(bytes, sizeof bytes);
    bit_secure_zero(messages, sizeof messages);
}


int poly_matrix_expand_ntt(poly_matrix_ntt *matrix, const uint8_t *seed)
{
    for (size_t base = 0; base + 4 <= BIT_K * BIT_L; base += 4) {
        poly_ntt *out[4];
        for (size_t lane = 0; lane < 4; lane++) {
            size_t index = base + lane;
            out[lane] = &matrix->vec[index / BIT_L].vec[index % BIT_L];
        }
        poly_uniform_ntt_x4(out, seed, base);
    }
    return poly_uniform_ntt(&matrix->vec[BIT_K - 1].vec[BIT_L - 1], seed, BIT_K - 1, BIT_L - 1);
}


void polyvecl_to_ntt(polyvecl_ntt *result, const polyvecl *v)
{
    for (int i = 0; i < BIT_L; i++) {
        poly_to_ntt(&result->vec[i], &v->vec[i]);
    }
}

void polyvecy_y1_to_ntt(polyvecl_ntt *result, const polyvecy *y)
{
    for (int i = 0; i < BIT_L; i++) {
        poly_to_ntt(&result->vec[i], &y->vec[1 + i]);
    }
}

void polyveck_from_ntt(polyveck *result, polyveck_ntt *v_ntt)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_from_ntt_inplace(&result->vec[i], &v_ntt->vec[i]);
    }
}

void poly_matrix_mul_vector_ntt(polyveck *result, const poly_matrix_ntt *A_ntt,
                                const polyvecl_ntt *v_ntt)
{
    polyveck_ntt acc;

    for (int i = 0; i < BIT_K; i++) {
        poly_ntt_dot3_raw(&acc.vec[i], A_ntt->vec[i].vec, v_ntt->vec);
        poly_ntt_montgomery_lift(&acc.vec[i]);
    }

    polyveck_from_ntt(result, &acc);
}

void polyveck_add_small(polyveck *result, const polyveck *a, const polyveck *small)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_add_small(&result->vec[i], &a->vec[i], &small->vec[i]);
    }
}

void polyveck_canonicalize(polyveck *b)
{
    for (int i = 0; i < BIT_K; i++)
        poly_canonicalize(&b->vec[i]);
}

void polyveck_public_to_ntt(polyveck_ntt *b_ntt, const polyveck *b)
{
    for (int i = 0; i < BIT_K; i++)
        poly_to_ntt(&b_ntt->vec[i], &b->vec[i]);
}

void polyveck_compute_w_ntt(polyveck *w, const poly_matrix_ntt *A_0_ntt, const polyveck_ntt *b_ntt,
                            const polyvecl_ntt *y1_ntt, const poly_ntt *y0_ntt, const polyvecy *y)
{
    polyveck_ntt w_ntt;
    poly_ntt tmp_ntt;

    for (int i = 0; i < BIT_K; i++) {
        poly_ntt_dot3_raw(&w_ntt.vec[i], A_0_ntt->vec[i].vec, y1_ntt->vec);
        poly_ntt_basemul_raw(&tmp_ntt, &b_ntt->vec[i], y0_ntt);
        for (int j = 0; j < BIT_N; j++) {
            w_ntt.vec[i].coeffs[j] = (bit_coeff_t)((int32_t)w_ntt.vec[i].coeffs[j] - tmp_ntt.coeffs[j]);
        }
        poly_ntt_montgomery_lift(&w_ntt.vec[i]);
    }
    polyveck_from_ntt(w, &w_ntt);

    for (int j = 0; j < BIT_N; j++) {
        int32_t val = w->vec[0].coeffs[j];
        int32_t q_hat_y0 = (int32_t)y->vec[0].coeffs[j] * BIT_Q_HAT_MINUS;

        w->vec[0].coeffs[j] = reduce_signed_barrett(val + q_hat_y0);
    }

    for (int i = 0; i < BIT_K; i++) {
        poly_add(&w->vec[i], &w->vec[i], &y->vec[1 + BIT_L + i]);
    }
}

void polyveck_highbits(polyveck *w1, const polyveck *w)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_highbits(&w1->vec[i], &w->vec[i]);
    }
}

void polyveck_pack_w1(unsigned char *r, const polyveck *w1)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_pack_w1(r + i * BIT_POLY_W1_BYTES, &w1->vec[i]);
    }
}

void polyvecl_mul_challenge_no_reduce(polyvecl *result, const polyvecl *a,
                                      const sparse_challenge *c)
{
    for (int i = 0; i < BIT_L; i++) {
        poly_mul_challenge_no_reduce(&result->vec[i], &a->vec[i], c);
    }
}

void polyveck_mul_challenge_no_reduce(polyveck *result, const polyveck *a,
                                      const sparse_challenge *c)
{
    for (int i = 0; i < BIT_K; i++) {
        poly_mul_challenge_no_reduce(&result->vec[i], &a->vec[i], c);
    }
}

void polyveck_make_hint(polyveck *h, const polyveck *w1, const polyveck *w,
                          const polyveck *z2, const poly *c, uint8_t b)
{
    const int32_t add_c_mask = -(int32_t)(1U - b);

    for (int j = 0; j < BIT_N; j++) {
        int32_t w_hat_val = (int32_t)w->vec[0].coeffs[j] - z2->vec[0].coeffs[j];
        w_hat_val += (int32_t)c->coeffs[j] & add_c_mask;

        bit_coeff_t hb_w_hat;
        decompose_hint(&hb_w_hat, w_hat_val);

        int32_t h_raw = (int32_t)w1->vec[0].coeffs[j] - hb_w_hat;
        int32_t h_val = h_raw;
        h_val += (h_val >> 31) & BIT_HINT_MODULUS;
        int32_t over_half = (BIT_HINT_MODULUS / 2 - h_val) >> 31;
        h_val -= BIT_HINT_MODULUS & over_half;
        h->vec[0].coeffs[j] = (bit_coeff_t)h_val;
    }
    for (int i = 1; i < BIT_K; i++) {
        for (int j = 0; j < BIT_N; j++) {
            int32_t w_hat_val = (int32_t)w->vec[i].coeffs[j] - z2->vec[i].coeffs[j];

            bit_coeff_t hb_w_hat;
            decompose_hint(&hb_w_hat, w_hat_val);

            int32_t h_raw = (int32_t)w1->vec[i].coeffs[j] - hb_w_hat;
            int32_t h_val = h_raw;
            h_val += (h_val >> 31) & BIT_HINT_MODULUS;
            int32_t over_half = (BIT_HINT_MODULUS / 2 - h_val) >> 31;
            h_val -= BIT_HINT_MODULUS & over_half;
            h->vec[i].coeffs[j] = (bit_coeff_t)h_val;
        }
    }
}

void polyveck_compute_w_hat_prime_ntt(polyveck *w_hat_prime, const poly_matrix_ntt *A_0_ntt,
                                      const polyveck_ntt *public_ntt, const polyvecl_ntt *z1_tail_ntt,
                                      const poly_ntt *z0_ntt, const poly *z0, const poly *c_poly)
{
    polyveck_ntt acc;
    poly_ntt tmp_ntt;

    for (int i = 0; i < BIT_K; i++) {
        poly_ntt_dot3_raw(&acc.vec[i], A_0_ntt->vec[i].vec, z1_tail_ntt->vec);
        poly_ntt_basemul_raw(&tmp_ntt, &public_ntt->vec[i], z0_ntt);
        for (int j = 0; j < BIT_N; j++) {
            acc.vec[i].coeffs[j] = (bit_coeff_t)((int32_t)acc.vec[i].coeffs[j] - tmp_ntt.coeffs[j]);
        }
        poly_ntt_montgomery_lift(&acc.vec[i]);
    }

    polyveck_from_ntt(w_hat_prime, &acc);

    for (int j = 0; j < BIT_N; j++) {
        int32_t val = w_hat_prime->vec[0].coeffs[j];
        int32_t z0_c_sum = (int32_t)z0->coeffs[j] + c_poly->coeffs[j];

        val += z0_c_sum * BIT_Q_HAT;
        w_hat_prime->vec[0].coeffs[j] = reduce_signed_barrett(val);
    }
}

void polyveck_compute_w_prime(polyveck *w_prime, const polyveck *w_hat_prime, const polyveck *h)
{
    for (int i = 0; i < BIT_K; i++) {
        for (int j = 0; j < BIT_N; j++) {
            bit_coeff_t hb;
            decompose_hint(&hb, w_hat_prime->vec[i].coeffs[j]);
            int32_t val = (int32_t)hb + h->vec[i].coeffs[j];
            val += (val >> 31) & BIT_HINT_MODULUS;
            val -= BIT_HINT_MODULUS;
            val += (val >> 31) & BIT_HINT_MODULUS;

            w_prime->vec[i].coeffs[j] = (bit_coeff_t)val;
        }
    }
}

#if BIT_TAU < 64
#define PSPM_SE_SHIFT 7
#else
#define PSPM_SE_SHIFT 8
#endif
#define PSPM_SE_MASK ((UINT64_C(1) << PSPM_SE_SHIFT) - 1)
#define PSPM_SE_U 1
#define PSPM_SE_BIAS (BIT_TAU * PSPM_SE_U)

_Static_assert(2 * BIT_TAU * PSPM_SE_U < (1 << PSPM_SE_SHIFT),
               "s/e PSPM digit must not carry into its neighbor");
_Static_assert(PSPM_SE_SHIFT *(BIT_L + BIT_K) <= 64, "all s/e PSPM digits must fit in uint64_t");

void polyvec_prepare_challenge_mul_se(bit_pspm_se_precomp *table, const polyvecl *s,
                                      const polyveck *e)
{
    const poly *src[BIT_L + BIT_K] = {&s->vec[0], &s->vec[1], &s->vec[2],
                                      &e->vec[0], &e->vec[1], &e->vec[2]};

    for (int i = 0; i < BIT_N; i++) {
        uint64_t plus = 0;
        uint64_t minus = 0;

        for (int j = 0; j < BIT_L + BIT_K; j++) {
            int32_t a = src[j]->coeffs[i];
            plus |= (uint64_t)(PSPM_SE_U + a) << (PSPM_SE_SHIFT * j);
            minus |= (uint64_t)(PSPM_SE_U - a) << (PSPM_SE_SHIFT * j);
        }
        table->words[BIT_N + i] = plus;
        table->words[i] = minus;
    }
}

static void pspm_add_neg_words(uint64_t *dst, const uint64_t *src, uint64_t twice_bias)
{
    const __m256i bias = _mm256_set1_epi64x((int64_t)twice_bias);

    for (size_t i = 0; i < BIT_N; i += 4) {
        __m256i d = _mm256_loadu_si256((const __m256i *)(dst + i));
        __m256i x = _mm256_loadu_si256((const __m256i *)(src + i));
        _mm256_storeu_si256((__m256i *)(dst + i), _mm256_add_epi64(d, _mm256_sub_epi64(bias, x)));
    }
}

static void pspm_add_words(uint64_t *dst, const uint64_t *src, size_t count)
{
    size_t i = 0;

    for (; i + 4 <= count; i += 4) {
        __m256i d = _mm256_loadu_si256((const __m256i *)(dst + i));
        __m256i x = _mm256_loadu_si256((const __m256i *)(src + i));
        _mm256_storeu_si256((__m256i *)(dst + i), _mm256_add_epi64(d, x));
    }
    for (; i < count; i++)
        dst[i] += src[i];
}

void polyvec_mul_challenge_no_reduce_se_pspm(polyvecl *c_s, polyveck *c_e,
                                             const bit_pspm_se_precomp *table,
                                             const sparse_challenge *c)
{
    BIT_ALIGN uint64_t acc[BIT_N] = {0};
    poly *dst[BIT_L + BIT_K] = {&c_s->vec[0], &c_s->vec[1], &c_s->vec[2],
                                &c_e->vec[0], &c_e->vec[1], &c_e->vec[2]};
    const int32_t sign_mask = -(int32_t)c->bflip;
    uint64_t twice_bias = 0;

    for (int j = 0; j < BIT_L + BIT_K; j++)
        twice_bias |= (uint64_t)(2 * PSPM_SE_U) << (PSPM_SE_SHIFT * j);

    for (int t = 0; t < BIT_TAU; t++) {
        size_t rot = c->pos[t];

        /* A negacyclic rotation is an N-word window in the negative/positive table. */
        const uint64_t *window = table->words + BIT_N - rot;
        if (c->sign[t] > 0)
            pspm_add_words(acc, window, BIT_N);
        else
            pspm_add_neg_words(acc, window, twice_bias);
    }

    for (int j = 0; j < BIT_L + BIT_K; j++) {
        unsigned int shift = PSPM_SE_SHIFT * (unsigned int)j;

        for (int i = 0; i < BIT_N; i++) {
            int32_t value = (int32_t)((acc[i] >> shift) & PSPM_SE_MASK) - PSPM_SE_BIAS;
            dst[j]->coeffs[i] = (bit_coeff_t)((value ^ sign_mask) - sign_mask);
        }
    }
}

#undef PSPM_SE_SHIFT
#undef PSPM_SE_MASK
#undef PSPM_SE_U
#undef PSPM_SE_BIAS

