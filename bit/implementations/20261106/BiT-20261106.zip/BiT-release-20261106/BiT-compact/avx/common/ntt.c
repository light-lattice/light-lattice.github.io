/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */
#include <stdint.h>

#include "ntt.h"
#include "reduce.h"

#include "ntt_roots.h"
#include "arithmetic.h"

#define NTT_DEGREE (BIT_N / NTT_COMPONENTS)
#if (NTT_DEGREE != 2 && NTT_DEGREE != 4) || 4 * BIT_Q > 32767
#error "Unsupported incomplete NTT parameters"
#endif

static inline bit_coeff_t montgomery_reduce(int32_t a)
{
    uint32_t m = ((uint32_t)a * (uint32_t)MONT_QINV) & 0xFFFFU;
    int32_t r = (a >> 16) - ((int32_t)(m * BIT_Q) >> 16);

    r += (r >> 31) & BIT_Q;
    r += (r >> 31) & BIT_Q;
    return (bit_coeff_t)r;
}

static inline bit_coeff_t mul_mod(bit_coeff_t a, bit_coeff_t b)
{
    return montgomery_reduce((int32_t)a * b);
}

static inline bit_coeff_t reduce_4q(int32_t a)
{
    a -= 2 * BIT_Q;
    a += (a >> 31) & (2 * BIT_Q);
    return reduce_modq(a);
}


static inline __m256i montgomery8(__m256i a, __m256i b)
{
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    __m256i product = _mm256_mullo_epi32(a, b);
    __m256i low = _mm256_and_si256(
        _mm256_mullo_epi32(product, _mm256_set1_epi32(MONT_QINV)), _mm256_set1_epi32(65535));
    __m256i value = _mm256_sub_epi32(_mm256_srai_epi32(product, 16),
        _mm256_srli_epi32(_mm256_mullo_epi32(low, q), 16));
    value = _mm256_add_epi32(value, _mm256_and_si256(_mm256_srai_epi32(value, 31), q));
    return _mm256_add_epi32(value, _mm256_and_si256(_mm256_srai_epi32(value, 31), q));
}

static inline __m256i reduce2q8(__m256i x)
{
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    x = _mm256_sub_epi32(x, q);
    return _mm256_add_epi32(x, _mm256_and_si256(_mm256_srai_epi32(x, 31), q));
}

static inline __m256i reduce4q8(__m256i x)
{
    const __m256i twice_q = _mm256_set1_epi32(2 * BIT_Q);
    x = _mm256_sub_epi32(x, twice_q);
    x = _mm256_add_epi32(x, _mm256_and_si256(_mm256_srai_epi32(x, 31), twice_q));
    return reduce2q8(x);
}

static inline __m256i load_component8(const bit_coeff_t *a, unsigned component)
{
    return _mm256_setr_epi32(a[component], a[NTT_DEGREE + component],
        a[2 * NTT_DEGREE + component], a[3 * NTT_DEGREE + component],
        a[4 * NTT_DEGREE + component], a[5 * NTT_DEGREE + component],
        a[6 * NTT_DEGREE + component], a[7 * NTT_DEGREE + component]);
}

static inline __m256i base_roots8(unsigned block)
{
    const int32_t a = roots[NTT_COMPONENTS / 2 + block / 2];
    const int32_t b = roots[NTT_COMPONENTS / 2 + block / 2 + 1];
    const int32_t c = roots[NTT_COMPONENTS / 2 + block / 2 + 2];
    const int32_t d = roots[NTT_COMPONENTS / 2 + block / 2 + 3];
    return _mm256_setr_epi32(a, BIT_Q - a, b, BIT_Q - b, c, BIT_Q - c, d, BIT_Q - d);
}

#if NTT_DEGREE == 4
static inline void mul_linear8(__m256i out[3], __m256i a0, __m256i a1,
                               __m256i b0, __m256i b1)
{
    out[0] = montgomery8(a0, b0);
    out[2] = montgomery8(a1, b1);
    __m256i sum = montgomery8(reduce2q8(_mm256_add_epi32(a0, a1)),
                              reduce2q8(_mm256_add_epi32(b0, b1)));
    out[1] = reduce4q8(_mm256_add_epi32(_mm256_sub_epi32(
        _mm256_sub_epi32(sum, out[0]), out[2]), _mm256_set1_epi32(2 * BIT_Q)));
}

static inline void store_quartic8(bit_coeff_t *r, const __m256i x[4])
{
    __m256i a = _mm256_unpacklo_epi32(x[0], x[1]);
    __m256i b = _mm256_unpackhi_epi32(x[0], x[1]);
    __m256i c = _mm256_unpacklo_epi32(x[2], x[3]);
    __m256i d = _mm256_unpackhi_epi32(x[2], x[3]);
    __m256i rows[4] = {_mm256_unpacklo_epi64(a, c), _mm256_unpackhi_epi64(a, c),
                       _mm256_unpacklo_epi64(b, d), _mm256_unpackhi_epi64(b, d)};
#if BIT_N == 1024
    for (unsigned j = 0; j < 4; j++) {
        _mm_storeu_si128((__m128i *)(r + 4 * j), _mm256_castsi256_si128(rows[j]));
        _mm_storeu_si128((__m128i *)(r + 4 * (j + 4)), _mm256_extracti128_si256(rows[j], 1));
    }
#else
    a = _mm256_packs_epi32(rows[0], rows[1]);
    b = _mm256_packs_epi32(rows[2], rows[3]);
    _mm256_storeu_si256((__m256i *)r, _mm256_permute2x128_si256(a, b, 0x20));
    _mm256_storeu_si256((__m256i *)(r + 16), _mm256_permute2x128_si256(a, b, 0x31));
#endif
}
#else
static inline void store_quadratic8(bit_coeff_t *r, __m256i a, __m256i b)
{
    __m256i low = _mm256_unpacklo_epi32(a, b);
    __m256i high = _mm256_unpackhi_epi32(a, b);
    _mm256_storeu_si256((__m256i *)r, _mm256_packs_epi32(low, high));
}
#endif

void ntt_forward(bit_coeff_t a[BIT_N])
{
    unsigned int lazy_layers = 0;
    int t = BIT_N;

    for (int m = 1; m < NTT_COMPONENTS; m <<= 1) {
        int reduce_layer;

        t >>= 1;
        lazy_layers++;
        reduce_layer = lazy_layers == 3 || m == NTT_COMPONENTS / 2;
        for (int i = 0; i < m; i++) {
            int start = 2 * i * t;
            int end = start + t;
            bit_coeff_t zeta = roots[m + i];

            int j = start;
            const __m256i root = _mm256_set1_epi32(zeta);
            for (; j + 8 <= end; j += 8) {
                __m256i u = bit_load_coeff8(a + j);
                __m256i v = montgomery8(bit_load_coeff8(a + j + t), root);
                __m256i sum = _mm256_add_epi32(u, v);
                __m256i difference = _mm256_add_epi32(_mm256_sub_epi32(u, v),
                                                     _mm256_set1_epi32(BIT_Q));
                if (reduce_layer) {
                    sum = reduce4q8(sum);
                    difference = reduce4q8(difference);
                }
                bit_store_coeff8(a + j, sum);
                bit_store_coeff8(a + j + t, difference);
            }
            for (; j < end; j++) {
                int32_t u = a[j];
                int32_t v = mul_mod(a[j + t], zeta);

                if (reduce_layer) {
                    a[j] = reduce_4q(u + v);
                    a[j + t] = reduce_4q(u - v + BIT_Q);
                } else {
                    a[j] = (bit_coeff_t)(u + v);
                    a[j + t] = (bit_coeff_t)(u - v + BIT_Q);
                }
            }
        }
        if (reduce_layer)
            lazy_layers = 0;
    }
}

static void ntt_inverse_scaled(bit_coeff_t a[BIT_N], bit_coeff_t scale)
{
    unsigned int lazy_layers = 0;
    int t = NTT_DEGREE;

    for (int m = NTT_COMPONENTS; m > 1; m >>= 1) {
        int h = m >> 1;
        int start = 0;
        int reduce_layer;

        lazy_layers++;
        reduce_layer = lazy_layers == 2 && m > 2;
        for (int i = 0; i < h; i++) {
            int end = start + t;
            bit_coeff_t zeta = roots_inv[h + i];

            int j = start;
            const __m256i root = _mm256_set1_epi32(zeta);
            for (; j + 8 <= end; j += 8) {
                __m256i u = bit_load_coeff8(a + j);
                __m256i v = bit_load_coeff8(a + j + t);
                __m256i sum = _mm256_add_epi32(u, v);
                __m256i difference = _mm256_add_epi32(_mm256_sub_epi32(u, v),
                                                     _mm256_set1_epi32(2 * BIT_Q));
                if (reduce_layer)
                    sum = reduce4q8(sum);
                bit_store_coeff8(a + j, sum);
                bit_store_coeff8(a + j + t, montgomery8(difference, root));
            }
            for (; j < end; j++) {
                int32_t u = a[j];
                int32_t v = a[j + t];

                a[j] = reduce_layer ? reduce_4q(u + v)
                                    : (bit_coeff_t)(u + v);
                a[j + t] = mul_mod((bit_coeff_t)(u - v + 2 * BIT_Q), zeta);
            }
            start += 2 * t;
        }
        t <<= 1;
        if (reduce_layer)
            lazy_layers = 0;
    }

    const __m256i factor = _mm256_set1_epi32(scale);
    for (unsigned i = 0; i < BIT_N; i += 8)
        bit_store_coeff8(a + i, montgomery8(bit_load_coeff8(a + i), factor));
}

void ntt_inverse(bit_coeff_t a[BIT_N])
{
    ntt_inverse_scaled(a, INV_NTT_SCALE);
}

void ntt_inverse_raw(bit_coeff_t a[BIT_N])
{
    /* Verification subtracts in the centered NTT domain. */
    for (unsigned i = 0; i < BIT_N; i++) {
        int32_t value = a[i];
        a[i] = (bit_coeff_t)(value + ((value >> 31) & BIT_Q));
    }
    ntt_inverse_scaled(a, INV_NTT_PRODUCT_SCALE);
}


void ntt_basemul_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_N],
                      const bit_coeff_t b[BIT_N])
{
    for (unsigned block = 0; block < NTT_COMPONENTS; block += 8) {
        unsigned offset = block * NTT_DEGREE;
        __m256i root = base_roots8(block);
        __m256i a0 = load_component8(a + offset, 0);
        __m256i a1 = load_component8(a + offset, 1);
        __m256i b0 = load_component8(b + offset, 0);
        __m256i b1 = load_component8(b + offset, 1);
#if NTT_DEGREE == 4
        __m256i a2 = load_component8(a + offset, 2);
        __m256i a3 = load_component8(a + offset, 3);
        __m256i b2 = load_component8(b + offset, 2);
        __m256i b3 = load_component8(b + offset, 3);
        __m256i low[3], high[3], combined[3], cross[3], out[4];
        mul_linear8(low, a0, a1, b0, b1);
        mul_linear8(high, a2, a3, b2, b3);
        mul_linear8(combined, reduce2q8(_mm256_add_epi32(a0, a2)),
                    reduce2q8(_mm256_add_epi32(a1, a3)),
                    reduce2q8(_mm256_add_epi32(b0, b2)),
                    reduce2q8(_mm256_add_epi32(b1, b3)));
        for (unsigned j = 0; j < 3; j++)
            cross[j] = reduce4q8(_mm256_add_epi32(_mm256_sub_epi32(
                _mm256_sub_epi32(combined[j], low[j]), high[j]), _mm256_set1_epi32(2 * BIT_Q)));
        out[0] = reduce2q8(_mm256_add_epi32(low[0], montgomery8(
            reduce2q8(_mm256_add_epi32(cross[2], high[0])), root)));
        out[1] = reduce2q8(_mm256_add_epi32(low[1], montgomery8(high[1], root)));
        out[2] = reduce4q8(_mm256_add_epi32(_mm256_add_epi32(low[2], cross[0]),
                                             montgomery8(high[2], root)));
        out[3] = cross[1];
        store_quartic8(r + offset, out);
#else
        __m256i low = montgomery8(a0, b0);
        __m256i high = montgomery8(montgomery8(a1, b1), root);
        __m256i cross = _mm256_add_epi32(montgomery8(a0, b1), montgomery8(a1, b0));
        store_quadratic8(r + offset, reduce2q8(_mm256_add_epi32(low, high)), reduce2q8(cross));
#endif
    }
}

void ntt_basemul_acc_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_N],
                          const bit_coeff_t b[BIT_N])
{
    bit_coeff_t product[BIT_N];
    ntt_basemul_raw(product, a, b);
    for (unsigned i = 0; i < BIT_N; i++)
        r[i] = reduce_modq((int32_t)r[i] + product[i]);
}

void ntt_dot3_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_L][BIT_N],
                   const bit_coeff_t b[BIT_L][BIT_N])
{
    bit_coeff_t product[BIT_N];
    ntt_basemul_raw(r, a[0], b[0]);
    for (unsigned k = 1; k < BIT_L; k++) {
        ntt_basemul_raw(product, a[k], b[k]);
        for (unsigned i = 0; i < BIT_N; i++)
            r[i] = (bit_coeff_t)((int32_t)r[i] + product[i]);
    }
}

void ntt_montgomery_lift(bit_coeff_t r[BIT_N])
{
    const __m256i scale = _mm256_set1_epi32(MONT_R2);
    for (unsigned i = 0; i < BIT_N; i += 8)
        bit_store_coeff8(r + i, montgomery8(bit_load_coeff8(r + i), scale));
}
