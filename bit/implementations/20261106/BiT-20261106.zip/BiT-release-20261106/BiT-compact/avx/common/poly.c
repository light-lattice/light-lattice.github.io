/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */
#include "../../common/ct_audit.h"
#include "poly.h"
#include "ntt.h"
#include "symmetric.h"
#include "endian.h"
#include "../../common/packing_w1.h"
#include <stddef.h>
#include <string.h>
#include "fips202x4.h"
#include "arithmetic.h"
#include "highbits.h"

inline void decompose_hint(bit_coeff_t *highbits, bit_coeff_t r)
{
    uint32_t val = (uint32_t)reduce_barrett(r);
    uint32_t numerator = val + (BIT_GAMMA2 >> 1);
    int32_t hb =
        (int32_t)(((uint64_t)numerator * BIT_GAMMA2_BARRETT_MULT) >> BIT_GAMMA2_BARRETT_SHIFT);

    int32_t edgecase = (BIT_HINT_MODULUS - (hb + 1)) >> 31;
    hb -= BIT_HINT_MODULUS & edgecase;
    *highbits = (bit_coeff_t)hb;
}

#if BIT_N == 1024
uint32_t reduce_barrett(int64_t a)
#else
uint16_t reduce_barrett(int32_t a)
#endif
{
    int64_t t;
    t = ((int64_t)a * BIT_BARRETT_MULT) >> BIT_BARRETT_SHIFT;
    a -= t * BIT_Q;
    /* Barrett estimate may be off by one; fold back into [0, q) */
    a += (a >> 31) & BIT_Q;
    a -= BIT_Q;
    a += (a >> 31) & BIT_Q;
    return (uint16_t)a;
}

static void unpack_secret_avx(bit_coeff_t out[BIT_N], const uint8_t *bytes)
{
#if BIT_SECRET_SYMBOL_BITS == 4
    const __m128i mask = _mm_set1_epi8(15);
    const __m256i one = _mm256_set1_epi32(1);
    const __m256i zero = _mm256_setzero_si256();
    for (unsigned off = 0; off < BIT_SAMPLE_S1_BUFLEN; off += 16) {
        __m128i input = _mm_loadu_si128((const __m128i *)(bytes + off));
        __m128i low = _mm_and_si128(input, mask);
        __m128i high = _mm_and_si128(_mm_srli_epi16(input, 4), mask);
        __m128i first = _mm_unpacklo_epi8(low, high);
        __m128i last = _mm_unpackhi_epi8(low, high);
        for (unsigned group = 0; group < 4; group++) {
            __m128i symbols = group < 2 ? first : last;
            symbols = group & 1 ? _mm_srli_si128(symbols, 8) : symbols;
            __m256i values = _mm256_cvtepu8_epi32(symbols);
            values = _mm256_sub_epi32(
                _mm256_and_si256(_mm256_cmpeq_epi32(values, one), one),
                _mm256_and_si256(_mm256_cmpeq_epi32(values, zero), one));
            bit_store_coeff8(out + 2 * off + 8 * group, values);
        }
    }
#else
    const __m256i gather = _mm256_setr_epi8(
        0,1,-1,-1, 0,1,-1,-1, 1,2,-1,-1, 2,3,-1,-1,
        3,4,-1,-1, 3,4,-1,-1, 4,5,-1,-1, 5,6,-1,-1);
    const __m256i shifts = _mm256_setr_epi32(0,6,4,2,0,6,4,2);
    for (unsigned i = 0; i < BIT_N; i += 8) {
        const uint8_t *p = bytes + 6 * (i / 8);
        uint64_t word = load32_le(p) | ((uint64_t)load16_le(p + 4) << 32);
        __m128i input = _mm_cvtsi64_si128((long long)word);
        __m256i codes = _mm256_shuffle_epi8(_mm256_broadcastsi128_si256(input), gather);
        codes = _mm256_and_si256(_mm256_srlv_epi32(codes, shifts), _mm256_set1_epi32(63));
        __m256i negative = _mm256_cmpgt_epi32(_mm256_set1_epi32(3), codes);
        __m256i positive = _mm256_andnot_si256(negative,
            _mm256_cmpgt_epi32(_mm256_set1_epi32(6), codes));
        bit_store_coeff8(out + i, _mm256_sub_epi32(negative, positive));
    }
#endif
}

int poly_sample_S1(poly *a, const uint8_t *seed, uint16_t *nonce)
{
    uint8_t bytes[BIT_SAMPLE_S1_BUFLEN];
    if (bit_xof256_nonce(bytes, sizeof bytes, seed, BIT_SEEDBYTES, *nonce) != 0) {
        bit_secure_zero(bytes, sizeof bytes);
        return -1;
    }
    *nonce = (uint16_t)(*nonce + 1U);
    unpack_secret_avx(a->coeffs, bytes);
    bit_secure_zero(bytes, sizeof bytes);
    return 0;
}

int poly_sample_S1_x4(poly *out[4], size_t count, const uint8_t *seed, uint16_t *nonce)
{
    if (count == 0 || count > 4)
        return -1;
    BIT_ALIGN_64 uint8_t messages[4][BIT_SEEDBYTES + 2];
    BIT_ALIGN_64 uint8_t bytes[4][BIT_SAMPLE_S1_BUFLEN];
    for (size_t lane = 0; lane < 4; lane++) {
        memcpy(messages[lane], seed, BIT_SEEDBYTES);
        store16_le(messages[lane] + BIT_SEEDBYTES,
                   (uint16_t)(*nonce + (lane < count ? lane : 0)));
    }
    shake256x4(bytes[0], bytes[1], bytes[2], bytes[3], BIT_SAMPLE_S1_BUFLEN,
               messages[0], messages[1], messages[2], messages[3], sizeof messages[0]);
    for (size_t lane = 0; lane < count; lane++)
        unpack_secret_avx(out[lane]->coeffs, bytes[lane]);
    *nonce = (uint16_t)(*nonce + count);
    bit_secure_zero(messages, sizeof messages);
    bit_secure_zero(bytes, sizeof bytes);
    return 0;
}


static inline void poly_to_ntt_impl(poly_ntt *result, const poly *a, poly *centered)
{
    for (int i = 0; i < BIT_N; i++) {
        result->coeffs[i] = (bit_coeff_t)reduce_barrett(a->coeffs[i]);
        if (centered != NULL)
            centered->coeffs[i] = reduce_to_signed(result->coeffs[i]);
    }
    ntt_forward(result->coeffs);
}

void poly_to_ntt(poly_ntt *result, const poly *a)
{
    poly_to_ntt_impl(result, a, NULL);
}

void poly_to_ntt_centered(poly_ntt *result, poly *a)
{
    poly_to_ntt_impl(result, a, a);
}

void poly_from_ntt(poly *result, const poly_ntt *a)
{
    poly_ntt tmp = *a;

    ntt_inverse(tmp.coeffs);
    for (int i = 0; i < BIT_N; i++) {
        result->coeffs[i] = reduce_to_signed((uint32_t)tmp.coeffs[i]);
    }
}

void poly_from_ntt_inplace(poly *result, poly_ntt *a)
{
    ntt_inverse(a->coeffs);
    for (int i = 0; i < BIT_N; i++) {
        result->coeffs[i] = reduce_to_signed((uint16_t)a->coeffs[i]);
    }
}

void poly_ntt_basemul_raw(poly_ntt *result, const poly_ntt *a, const poly_ntt *b)
{
    ntt_basemul_raw(result->coeffs, a->coeffs, b->coeffs);
}

void poly_ntt_dot3_raw(poly_ntt *result, const poly_ntt a[BIT_L], const poly_ntt b[BIT_L])
{
    poly_ntt product;
    ntt_basemul_raw(result->coeffs, a[0].coeffs, b[0].coeffs);
    for (unsigned k = 1; k < BIT_L; k++) {
        ntt_basemul_raw(product.coeffs, a[k].coeffs, b[k].coeffs);
        for (unsigned i = 0; i < BIT_N; i++)
            result->coeffs[i] = (bit_coeff_t)((int32_t)result->coeffs[i] + product.coeffs[i]);
    }
}


void poly_ntt_montgomery_lift(poly_ntt *result)
{
    ntt_montgomery_lift(result->coeffs);
}

void poly_add(poly *result, const poly *a, const poly *b)
{
    for (unsigned i = 0; i < BIT_N; i += 8)
        bit_store_coeff8(result->coeffs + i, bit_center8(bit_reduce_unsigned8(
            _mm256_add_epi32(bit_load_coeff8(a->coeffs + i), bit_load_coeff8(b->coeffs + i)))));
}


void poly_add_no_reduce(poly *result, const poly *a, const poly *b)
{
    for (unsigned i = 0; i < BIT_N; i += 8)
        bit_store_coeff8(result->coeffs + i,
            _mm256_add_epi32(bit_load_coeff8(a->coeffs + i), bit_load_coeff8(b->coeffs + i)));
}


void poly_add_small(poly *result, const poly *a, const poly *small)
{
    poly_add(result, a, small);
}


void poly_highbits(poly *w1, const poly *w)
{
    for (unsigned i = 0; i < BIT_N; i += 8)
        bit_store_coeff8(w1->coeffs + i,
            bit_highbits_i32x8(bit_reduce_unsigned8(bit_load_coeff8(w->coeffs + i))));
}


void poly_canonicalize(poly *a)
{
    for (unsigned i = 0; i < BIT_N; i += 8)
        bit_store_coeff8(a->coeffs + i, bit_reduce_unsigned8(bit_load_coeff8(a->coeffs + i)));
}


void poly_pack_w1(unsigned char *r, const poly *a)
{
    bit_pack_w1(r, a->coeffs);
}

int poly_challenge(poly *c, const unsigned char seed[BIT_CHALLENGEBYTES])
{
    unsigned int i, b, pos;
    uint8_t buf[BIT_XOF256_RATE];
    uint8_t sign_bits[(BIT_TAU + 7) / 8];
    bit_xof256_ctx ctx;

    bit_xof256_ctx_init(&ctx, seed, BIT_CHALLENGEBYTES);
    if (bit_xof256_ctx_squeezeblocks(&ctx, buf, 1) != 0) {
        bit_xof256_ctx_zeroize(&ctx);
        bit_secure_zero(buf, sizeof(buf));
        return -1;
    }
    for (size_t j = 0; j < sizeof(sign_bits); j++)
        sign_bits[j] = buf[j];
    BIT_CT_HAETAE_PUBLIC(sign_bits, sizeof sign_bits);
    pos = (unsigned int)sizeof(sign_bits);

    for (i = 0; i < BIT_N; ++i) {
        c->coeffs[i] = 0;
    }

    for (i = BIT_N - BIT_TAU; i < BIT_N; ++i) {
        do {
            if (pos + (BIT_N == 256 ? 1U : 2U) > BIT_XOF256_RATE) {
                if (bit_xof256_ctx_squeezeblocks(&ctx, buf, 1) != 0) {
                    bit_xof256_ctx_zeroize(&ctx);
                    bit_secure_zero(buf, sizeof(buf));
                    return -1;
                }
                pos = 0;
            }

#if BIT_N == 256
            b = buf[pos++];
#else
            b = load16_le(buf + pos) & (BIT_N - 1U);
            pos += 2;
#endif
            BIT_CT_HAETAE_PUBLIC(&b, sizeof b);
        } while (b > i);

        c->coeffs[i] = c->coeffs[b];
        {
            unsigned int t = i - (BIT_N - BIT_TAU);
            c->coeffs[b] = 1 - 2 * ((sign_bits[t >> 3] >> (t & 7)) & 1U);
        }
    }
    bit_xof256_ctx_zeroize(&ctx);
    return 0;
}

void poly_challenge_to_sparse(sparse_challenge *s, const poly *c)
{
    int ctr = 0;

    s->bflip = 0;

    for (int i = 0; i < BIT_N; i++) {
        if (c->coeffs[i] != 0) {
            s->pos[ctr] = i;
            s->sign[ctr] = (int8_t)c->coeffs[i];
            ctr++;
            if (ctr == BIT_TAU) {
                break;
            }
        }
    }
}

void poly_cneg(poly *a, uint8_t b)
{
    const int32_t mask = -(int32_t)b;

    for (int i = 0; i < BIT_N; i++) {
        a->coeffs[i] = (bit_coeff_t)(((int32_t)a->coeffs[i] ^ mask) - mask);
    }
}

void poly_mul_challenge_no_reduce(poly *result, const poly *a, const sparse_challenge *c)
{
    bit_coeff_t acc[BIT_N];
    const bit_coeff_t mask = (bit_coeff_t)(-(int32_t)c->bflip);

    for (int i = 0; i < BIT_N; i++) {
        acc[i] = 0;
    }

    for (int t = 0; t < BIT_TAU; t++) {
        int i = c->pos[t];
        if (c->sign[t] > 0) {
            for (int j = 0; j < BIT_N - i; j++)
                acc[i + j] += a->coeffs[j];
            for (int j = BIT_N - i; j < BIT_N; j++)
                acc[i + j - BIT_N] -= a->coeffs[j];
        } else {
            for (int j = 0; j < BIT_N - i; j++)
                acc[i + j] -= a->coeffs[j];
            for (int j = BIT_N - i; j < BIT_N; j++)
                acc[i + j - BIT_N] += a->coeffs[j];
        }
    }

    for (int i = 0; i < BIT_N; i++) {
        result->coeffs[i] = (bit_coeff_t)((acc[i] ^ mask) - mask);
    }
}

int poly_reject_highbits_bimodal(const poly *w1, const poly *w0, const sparse_challenge *c)
{
    uint32_t reject_flag = 0;
    const int32_t signed_one = 1 - 2 * (int32_t)c->bflip;

    for (int t = 0; t < BIT_TAU; t++) {
        int i = c->pos[t];
        bit_coeff_t hb;
        int32_t w_prime_val = (int32_t)w0->coeffs[i] + (int32_t)c->sign[t] * signed_one;

        decompose_hint(&hb, w_prime_val);
        reject_flag |= (uint32_t)((uint16_t)w1->coeffs[i] ^ (uint16_t)hb);
    }

    return (reject_flag != 0) ? 1 : 0;
}

void poly_from_ntt_raw(poly *result, const poly_ntt *a)
{
    poly_ntt temporary = *a;
    ntt_inverse_raw(temporary.coeffs);
    for (unsigned i = 0; i < BIT_N; i++)
        result->coeffs[i] = reduce_to_signed((uint32_t)temporary.coeffs[i]);
}
void poly_ntt_basemul_acc_raw(poly_ntt *result, const poly_ntt *a, const poly_ntt *b)
{
    ntt_basemul_acc_raw(result->coeffs, a->coeffs, b->coeffs);
}
void poly_ntt_zero(poly_ntt *result)
{
    memset(result, 0, sizeof(*result));
}
