/* Copyright (c) 2026 Hang Zhang. */
#ifndef BIT_SMALL_SAMPLE_H
#define BIT_SMALL_SAMPLE_H
#include <stdint.h>
#include "params.h"
#include "endian.h"

/* Fixed-width ternary mapping without indexed memory. */
static inline int32_t bit_small_sample(uint32_t symbol)
{
#if BIT_SECRET_SYMBOL_WEIGHT == 3
    return (int32_t)((uint32_t)(symbol - 3U) < 3U) - (int32_t)(symbol < 3U);
#else
    return (int32_t)(symbol == 1U) - (int32_t)(symbol == 0U);
#endif
}
/* Decode the fixed-width coefficient stream. */
static inline void bit_unpack_secret(bit_coeff_t out[BIT_N], const uint8_t *bytes)
{
#if BIT_SECRET_SYMBOL_BITS == 4
    for (unsigned i = 0; i < BIT_N / 2; i++) {
        uint8_t value = bytes[i];
        out[2 * i] = (bit_coeff_t)bit_small_sample(value & 15U);
        out[2 * i + 1] = (bit_coeff_t)bit_small_sample(value >> 4);
    }
#elif BIT_SECRET_SYMBOL_BITS == 6
    for (unsigned i = 0; i < BIT_N / 4; i++) {
        uint32_t value = load24_le(bytes + 3 * i);
        for (unsigned j = 0; j < 4; j++)
            out[4 * i + j] = (bit_coeff_t)bit_small_sample((value >> (6 * j)) & 63U);
    }
#else
#error "Unsupported secret coefficient distribution"
#endif
}
#endif
