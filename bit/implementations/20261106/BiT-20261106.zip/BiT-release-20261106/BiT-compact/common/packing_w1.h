/* Copyright (c) 2026 Hang Zhang. */
#ifndef BIT_PACKING_W1_H
#define BIT_PACKING_W1_H
#include "params.h"
#include "endian.h"

static inline void bit_pack_w1(uint8_t *out, const bit_coeff_t *coeffs)
{
    for (unsigned i = 0; i < BIT_N; i += 8) {
        uint64_t value = 0;
        for (unsigned j = 0; j < 8; j++)
            value |= (uint64_t)(uint32_t)coeffs[i + j] << (BIT_W1_BITS * j);
#if BIT_W1_BITS == 3
        store16_le(out, (uint16_t)value);
        out[2] = (uint8_t)(value >> 16);
#elif BIT_W1_BITS == 4
        store32_le(out, (uint32_t)value);
#else
#error "Unsupported HighBits encoding width"
#endif
        out += BIT_W1_BITS;
    }
}
#endif
