/* Copyright (c) 2026 Hang Zhang. */
#ifndef BIT_NTT_H
#define BIT_NTT_H
#include "params.h"
void ntt_forward(bit_coeff_t a[BIT_N]);
void ntt_inverse(bit_coeff_t a[BIT_N]);
/* Accept canonical or centered raw Montgomery products; return canonical residues. */
void ntt_inverse_raw(bit_coeff_t a[BIT_N]);
void ntt_basemul_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_N], const bit_coeff_t b[BIT_N]);
void ntt_basemul_acc_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_N], const bit_coeff_t b[BIT_N]);
void ntt_dot3_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_L][BIT_N], const bit_coeff_t b[BIT_L][BIT_N]);
void ntt_montgomery_lift(bit_coeff_t r[BIT_N]);
#endif
