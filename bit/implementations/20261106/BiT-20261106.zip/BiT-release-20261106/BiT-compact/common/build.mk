# Copyright (c) 2026 Hang Zhang.

.DEFAULT_GOAL := all
CC = gcc
ifeq ($(IMPLEMENTATION),avx)
CFLAGS ?= -std=c99 -Wpedantic -Wall -Wextra -O3 -fomit-frame-pointer
override CFLAGS += -mavx2
else
CFLAGS ?= -std=c99 -Wpedantic -Wall -Wextra -O2
endif
CPPFLAGS ?=
LDLIBS ?= -lm
BACKEND ?= shake
NTESTS ?= 1000
RUNNER ?=

ifneq ($(BACKEND),shake)
$(error Only the SHAKE backend is supported)
endif
override CPPFLAGS += -I. -Itest -I../../common
ifeq ($(IMPLEMENTATION),avx)
override CPPFLAGS += -DBIT_IMPL_AVX=1 -I../common
else
override CPPFLAGS += -DBIT_IMPL_AVX=0
endif

# Common sources are compiled separately for each parameter set and backend.
COMMON_DIR := ../../common
COMMON_MODULES := sample sign spectral symmetric signature_api ntt signature_codec
COMMON_SRCS := $(addprefix $(COMMON_DIR)/,$(addsuffix .c,$(COMMON_MODULES)))
LOCAL_SRCS := $(filter-out KAT_SIG.c,$(wildcard *.c))
OBJS := $(LOCAL_SRCS:.c=.o) $(addsuffix .o,$(COMMON_MODULES))

ifeq ($(IMPLEMENTATION),avx)
COMMON_MODULES := $(filter-out ntt,$(COMMON_MODULES))
COMMON_SRCS := $(filter-out $(COMMON_DIR)/ntt.c,$(COMMON_SRCS))
OBJS := $(filter-out ntt.o,$(OBJS))
AVX_DIR := ../common
AVX_MODULES := poly polyvec parabola_avx keccakx4_lanes ntt
AVX_SRCS := $(addprefix $(AVX_DIR)/,$(addsuffix .c,$(AVX_MODULES)))
OBJS += $(addsuffix .o,$(AVX_MODULES))
ifeq ($(PARAMETER_SET),512)
ASM_SRC := f1600x4.S
else
AVX_MODULES += fips202x4
AVX_SRCS += $(AVX_DIR)/fips202x4.c
OBJS += fips202x4.o
ASM_SRC := $(AVX_DIR)/f1600x4.S
endif
OBJS += f1600x4_avx.o
else ifneq ($(PARAMETER_SET),512)
COMMON_SRCS += $(COMMON_DIR)/polyvec_ref.c
OBJS += polyvec_ref.o
endif
SRCS := $(LOCAL_SRCS) $(COMMON_SRCS) $(AVX_SRCS)
OBJS := signature_api.o $(filter-out signature_api.o,$(sort $(OBJS)))

# Change the stamp only when the effective compiler configuration changes.
.PHONY: FORCE
.build-config: FORCE
	@printf '%s\n' '$(CC)' '$(CFLAGS)' '$(CPPFLAGS)' '$(SRCS)' '$(ASM_SRC)' > $@.tmp
	@if cmp -s $@.tmp $@; then rm -f $@.tmp; else mv -f $@.tmp $@; fi

TEST_HEADERS := $(wildcard test/*.h ../../tests/common/*.h ../../common/*_test.h)
-include $(OBJS:.o=.d) test_gaussian_exp.d

.PHONY: all check unit correctness speed clean message-binding
all: KAT_SIG
check: correctness
ifneq ($(wildcard test/test_message_binding.c),)
check: message-binding

message-binding: test/test_message_binding.c $(TEST_HEADERS) $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $< $(OBJS) -Wl,--wrap=bit_hash_message $(LDLIBS) -o $@
	$(RUNNER) ./$@
endif

KAT_SIG: KAT_SIG.c $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $^ $(LDLIBS) -o $@

correctness: test_correctness
	$(RUNNER) ./test_correctness

unit: test_correctness test_ntt test_small_sample test_rans_support test_nonce_exhaustion
	$(RUNNER) ./test_correctness --unit
	$(RUNNER) ./test_ntt
	$(RUNNER) ./test_small_sample
	$(RUNNER) ./test_rans_support
	$(RUNNER) ./test_nonce_exhaustion
ifeq ($(IMPLEMENTATION),avx)
	$(RUNNER) ./test_ntt_equivalence
ifeq ($(BACKEND),shake)
	$(RUNNER) ./test_gaussian_exp
endif
unit: test_ntt_equivalence
ifeq ($(BACKEND),shake)
unit: test_gaussian_exp

test_gaussian_exp: ../../tests/common/test_gaussian_exp.c samplerx4.c .build-config
	$(CC) $(CFLAGS) $(CPPFLAGS) -ffunction-sections -fdata-sections -MMD -MP \
	  -DGAUSSIAN_TEST_SOURCE=\"samplerx4.c\" $< -Wl,--gc-sections -o $@
endif

test_ntt_equivalence: ../../tests/common/test_ntt_equivalence.c ntt.o ntt_scalar_test.o
	$(CC) $(CFLAGS) $(CPPFLAGS) $^ $(LDLIBS) -o $@

ntt_scalar_test.o: $(COMMON_DIR)/ntt.c .build-config
	$(CC) $(CFLAGS) $(CPPFLAGS) \
	  $(foreach name,forward inverse inverse_raw basemul_raw basemul_acc_raw dot3_raw montgomery_lift,-Dntt_$(name)=scalar_ntt_$(name)) \
	  -c $< -o $@
endif

test_correctness: ../../tests/common/test_compact_correctness.c $(TEST_HEADERS) $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) -I../../tests/common $< $(OBJS) $(LDLIBS) -o $@

test_ntt: ../../tests/common/test_compact_ntt.c ntt.o
	$(CC) $(CFLAGS) $(CPPFLAGS) $^ $(LDLIBS) -o $@

test_small_sample: ../../tests/common/test_compact_sampling.c .build-config $(COMMON_DIR)/small_sample.h $(COMMON_DIR)/params_$(PARAMETER_SET).h
	$(CC) $(CFLAGS) $(CPPFLAGS) $< -o $@

test_rans_support: ../../tests/common/test_rans_support.c $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $< $(OBJS) $(LDLIBS) -o $@

test_nonce_exhaustion: ../../tests/common/test_nonce_exhaustion.c $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $< $(OBJS) $(LDLIBS) -o $@

speed: test/test_speed.c test/cpucycles.c test/speed_print.c $(TEST_HEADERS) $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) -DNTESTS=$(NTESTS) \
	  test/test_speed.c test/cpucycles.c test/speed_print.c $(OBJS) $(LDLIBS) -o $@
	$(RUNNER) ./$@

# Common and local modules both write objects into this build directory.
$(addsuffix .o,$(COMMON_MODULES)) polyvec_ref.o: %.o: $(COMMON_DIR)/%.c .build-config
	$(CC) $(CFLAGS) $(CPPFLAGS) -MMD -MP -c $< -o $@

ifeq ($(IMPLEMENTATION),avx)
$(addsuffix .o,$(AVX_MODULES)): %.o: $(AVX_DIR)/%.c .build-config
	$(CC) $(CFLAGS) $(CPPFLAGS) -MMD -MP -c $< -o $@

f1600x4_avx.o: $(ASM_SRC) .build-config
	$(CC) $(CFLAGS) $(CPPFLAGS) -c $< -o $@
endif

.PHONY: print-sources print-objects
print-sources:
	@printf '%s\n' $(SRCS) $(ASM_SRC)
print-objects:
	@printf '%s\n' $(OBJS)

%.o: %.c .build-config
	$(CC) $(CFLAGS) $(CPPFLAGS) -MMD -MP -c $< -o $@


.PHONY: ctcheck

ctcheck: ../../tests/common/test_compact_ct.c $(OBJS)
	$(CC) $(CFLAGS) $(CPPFLAGS) $< $(OBJS) $(LDLIBS) -o $@
	valgrind --tool=memcheck --error-exitcode=97 --quiet ./ctcheck

clean:
	rm -f KAT_SIG correctness speed message-binding test_correctness test_ntt \
	  test_small_sample test_rans_support test_nonce_exhaustion ctcheck \
	  test_ntt_equivalence test_gaussian_exp \
	  *.o *.d *.su .build-config .build-config.tmp
