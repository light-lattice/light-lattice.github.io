/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */
#include <stdint.h>

#include "ntt.h"
#include "reduce.h"

#include "ntt_roots.h"

#define NTT_DEGREE (BIT_N / NTT_COMPONENTS)
#if (NTT_DEGREE != 2 && NTT_DEGREE != 4) || 4 * BIT_Q > 32767
#error "Unsupported incomplete NTT parameters"
#endif

static inline bit_coeff_t montgomery_reduce(int32_t a)
{
    uint32_t m = ((uint32_t)a * (uint32_t)MONT_QINV) & 0xFFFFU;
    int32_t r = (a >> 16) - ((int32_t)(m * BIT_Q) >> 16);

    r += (r >> 31) & BIT_Q;
    r += (r >> 31) & BIT_Q;
    return (bit_coeff_t)r;
}

static inline bit_coeff_t mul_mod(bit_coeff_t a, bit_coeff_t b)
{
    return montgomery_reduce((int32_t)a * b);
}

static inline bit_coeff_t reduce_4q(int32_t a)
{
    a -= 2 * BIT_Q;
    a += (a >> 31) & (2 * BIT_Q);
    return reduce_modq(a);
}

void ntt_forward(bit_coeff_t a[BIT_N])
{
    unsigned int lazy_layers = 0;
    int t = BIT_N;

    for (int m = 1; m < NTT_COMPONENTS; m <<= 1) {
        int reduce_layer;

        t >>= 1;
        lazy_layers++;
        reduce_layer = lazy_layers == 3 || m == NTT_COMPONENTS / 2;
        for (int i = 0; i < m; i++) {
            int start = 2 * i * t;
            int end = start + t;
            bit_coeff_t zeta = roots[m + i];

            for (int j = start; j < end; j++) {
                int32_t u = a[j];
                int32_t v = mul_mod(a[j + t], zeta);

                if (reduce_layer) {
                    a[j] = reduce_4q(u + v);
                    a[j + t] = reduce_4q(u - v + BIT_Q);
                } else {
                    a[j] = (bit_coeff_t)(u + v);
                    a[j + t] = (bit_coeff_t)(u - v + BIT_Q);
                }
            }
        }
        if (reduce_layer)
            lazy_layers = 0;
    }
}

static void ntt_inverse_scaled(bit_coeff_t a[BIT_N], bit_coeff_t scale)
{
    unsigned int lazy_layers = 0;
    int t = NTT_DEGREE;

    for (int m = NTT_COMPONENTS; m > 1; m >>= 1) {
        int h = m >> 1;
        int start = 0;
        int reduce_layer;

        lazy_layers++;
        reduce_layer = lazy_layers == 2 && m > 2;
        for (int i = 0; i < h; i++) {
            int end = start + t;
            bit_coeff_t zeta = roots_inv[h + i];

            for (int j = start; j < end; j++) {
                int32_t u = a[j];
                int32_t v = a[j + t];

                a[j] = reduce_layer ? reduce_4q(u + v)
                                    : (bit_coeff_t)(u + v);
                a[j + t] = mul_mod((bit_coeff_t)(u - v + 2 * BIT_Q), zeta);
            }
            start += 2 * t;
        }
        t <<= 1;
        if (reduce_layer)
            lazy_layers = 0;
    }

    for (int i = 0; i < BIT_N; i++)
        a[i] = mul_mod(a[i], scale);
}

void ntt_inverse(bit_coeff_t a[BIT_N])
{
    ntt_inverse_scaled(a, INV_NTT_SCALE);
}

void ntt_inverse_raw(bit_coeff_t a[BIT_N])
{
    /* Verification subtracts in the centered NTT domain. */
    for (unsigned i = 0; i < BIT_N; i++) {
        int32_t value = a[i];
        a[i] = (bit_coeff_t)(value + ((value >> 31) & BIT_Q));
    }
    ntt_inverse_scaled(a, INV_NTT_PRODUCT_SCALE);
}

#if NTT_DEGREE == 4
static void mul_linear(bit_coeff_t r[3], const bit_coeff_t a[2],
                       const bit_coeff_t b[2])
{
    bit_coeff_t a_sum = reduce_modq((int32_t)a[0] + a[1]);
    bit_coeff_t b_sum = reduce_modq((int32_t)b[0] + b[1]);

    r[0] = mul_mod(a[0], b[0]);
    r[2] = mul_mod(a[1], b[1]);
    r[1] = reduce_4q((int32_t)mul_mod(a_sum, b_sum)
                     - r[0] - r[2] + 2 * BIT_Q);
}

static void basemul_quartic(bit_coeff_t r[4], const bit_coeff_t a[4],
                            const bit_coeff_t b[4], bit_coeff_t zeta)
{
    bit_coeff_t low[3], high[3], combined[3], cross[3];
    bit_coeff_t a_sum[2], b_sum[2];

    mul_linear(low, a, b);
    mul_linear(high, a + 2, b + 2);
    a_sum[0] = reduce_modq((int32_t)a[0] + a[2]);
    a_sum[1] = reduce_modq((int32_t)a[1] + a[3]);
    b_sum[0] = reduce_modq((int32_t)b[0] + b[2]);
    b_sum[1] = reduce_modq((int32_t)b[1] + b[3]);
    mul_linear(combined, a_sum, b_sum);

    for (int i = 0; i < 3; i++)
        cross[i] = reduce_4q((int32_t)combined[i] - low[i] - high[i]
                             + 2 * BIT_Q);

    r[0] = reduce_modq((int32_t)low[0]
                       + mul_mod(reduce_modq((int32_t)cross[2] + high[0]),
                                 zeta));
    r[1] = reduce_modq((int32_t)low[1] + mul_mod(high[1], zeta));
    r[2] = reduce_4q((int32_t)low[2] + cross[0]
                     + mul_mod(high[2], zeta));
    r[3] = cross[1];
}

#else
static void basemul_quadratic(bit_coeff_t r[2], const bit_coeff_t a[2],
                              const bit_coeff_t b[2], bit_coeff_t zeta)
{
    bit_coeff_t low = mul_mod(a[0], b[0]);
    bit_coeff_t high = mul_mod(mul_mod(a[1], b[1]), zeta);
    bit_coeff_t cross0 = mul_mod(a[0], b[1]);
    bit_coeff_t cross1 = mul_mod(a[1], b[0]);
    r[0] = reduce_modq((int32_t)low + high);
    r[1] = reduce_modq((int32_t)cross0 + cross1);
}
#endif

void ntt_basemul_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_N],
                      const bit_coeff_t b[BIT_N])
{
    for (unsigned i = 0; i < NTT_COMPONENTS / 2; i++) {
        bit_coeff_t zeta = roots[NTT_COMPONENTS / 2 + i];
        unsigned offset = 2 * NTT_DEGREE * i;
#if NTT_DEGREE == 4
        basemul_quartic(r + offset, a + offset, b + offset, zeta);
        basemul_quartic(r + offset + 4, a + offset + 4, b + offset + 4,
                        (bit_coeff_t)(BIT_Q - zeta));
#else
        basemul_quadratic(r + offset, a + offset, b + offset, zeta);
        basemul_quadratic(r + offset + 2, a + offset + 2, b + offset + 2,
                          (bit_coeff_t)(BIT_Q - zeta));
#endif
    }
}

void ntt_basemul_acc_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_N],
                          const bit_coeff_t b[BIT_N])
{
    bit_coeff_t product[BIT_N];
    ntt_basemul_raw(product, a, b);
    for (unsigned i = 0; i < BIT_N; i++)
        r[i] = reduce_modq((int32_t)r[i] + product[i]);
}

void ntt_dot3_raw(bit_coeff_t r[BIT_N], const bit_coeff_t a[BIT_L][BIT_N],
                   const bit_coeff_t b[BIT_L][BIT_N])
{
    bit_coeff_t product[BIT_N];
    ntt_basemul_raw(r, a[0], b[0]);
    for (unsigned k = 1; k < BIT_L; k++) {
        ntt_basemul_raw(product, a[k], b[k]);
        for (unsigned i = 0; i < BIT_N; i++)
            r[i] = (bit_coeff_t)((int32_t)r[i] + product[i]);
    }
}

void ntt_montgomery_lift(bit_coeff_t r[BIT_N])
{
    for (unsigned i = 0; i < BIT_N; i++)
        r[i] = mul_mod(r[i], MONT_R2);
}
