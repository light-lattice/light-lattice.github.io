/* Copyright (c) 2026 Hang Zhang. */

#include "../../common/reduce_512.h"
