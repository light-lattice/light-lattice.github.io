/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */
#include "../../common/ct_audit.h"
#include "poly.h"
#include "../common/highbits.h"
#include "ntt_avx.h"
#include "symmetric.h"
#include "fips202x4.h"
#include "endian.h"
#include <stddef.h>
#include <string.h>

static inline __m256i reduce_signed_i32x8(__m256i x)
{
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    const __m256i half = _mm256_set1_epi32(BIT_Q_HALF);
    const __m256i neg_half = _mm256_set1_epi32(-BIT_Q_HALF);

    for (int pass = 0; pass < 3; pass++) {
        x = _mm256_sub_epi32(x, _mm256_and_si256(_mm256_cmpgt_epi32(x, half), q));
        x = _mm256_add_epi32(x, _mm256_and_si256(_mm256_cmpgt_epi32(neg_half, x), q));
    }
    return x;
}

static inline __m256i decompose_hint_centered_i32x8(__m256i x)
{
    const __m256i q = _mm256_set1_epi32(BIT_Q);
    x = _mm256_add_epi32(x, _mm256_and_si256(_mm256_srai_epi32(x, 31), q));
    return bit_highbits_i32x8(x);
}

static void unpack_S1_4bit(int32_t *a, const uint8_t *buf)
{
    const __m128i mask = _mm_set1_epi8(15);
    const __m256i one = _mm256_set1_epi32(1);
    const __m256i zero = _mm256_setzero_si256();

    _Static_assert(BIT_SAMPLE_S1_BUFLEN % 16 == 0, "AVX2 S1 unpack requires full 16-byte groups");
    for (size_t off = 0; off < BIT_SAMPLE_S1_BUFLEN; off += 16) {
        __m128i bytes = _mm_loadu_si128((const __m128i *)(buf + off));
        __m128i lo = _mm_and_si128(bytes, mask);
        __m128i hi = _mm_and_si128(_mm_srli_epi16(bytes, 4), mask);
        __m128i nibbles_lo = _mm_unpacklo_epi8(lo, hi);
        __m128i nibbles_hi = _mm_unpackhi_epi8(lo, hi);

        for (size_t group = 0; group < 4; group++) {
            __m128i nibbles = group < 2 ? nibbles_lo : nibbles_hi;
            __m128i bytes8 = group & 1 ? _mm_srli_si128(nibbles, 8) : nibbles;
            __m256i code = _mm256_cvtepu8_epi32(bytes8);
            __m256i value = _mm256_sub_epi32(_mm256_and_si256(_mm256_cmpeq_epi32(code, one), one),
                                             _mm256_and_si256(_mm256_cmpeq_epi32(code, zero), one));

            _mm256_store_si256((__m256i *)(a + 2 * off + 8 * group), value);
        }
    }
}

inline void decompose_hint(int32_t *highbits, int32_t r)
{
    uint32_t val = reduce_barrett(r);
    uint32_t numerator = val + (BIT_GAMMA2 >> 1);
    int32_t hb =
        (int32_t)(((uint64_t)numerator * BIT_GAMMA2_BARRETT_MULT) >> BIT_GAMMA2_BARRETT_SHIFT);

    int32_t edgecase = (BIT_HINT_MODULUS - (hb + 1)) >> 31;
    hb -= BIT_HINT_MODULUS & edgecase;
    *highbits = (int32_t)hb;
}

uint32_t reduce_barrett(int64_t a)
{
    int64_t t;
    t = (a * BIT_BARRETT_MULT) >> BIT_BARRETT_SHIFT;
    a -= t * BIT_Q;
    /* Barrett estimate may be off by one; fold back into [0, q) */
    a += (a >> 63) & BIT_Q;
    a -= BIT_Q;
    a += (a >> 63) & BIT_Q;
    return (uint32_t)a;
}

int poly_sample_S1(poly *a, const uint8_t *seed, uint16_t *nonce)
{
    uint8_t buf[BIT_SAMPLE_S1_BUFLEN];

    if (bit_xof256_nonce(buf, sizeof(buf), seed, BIT_SEEDBYTES, *nonce) != 0) {
        bit_secure_zero(buf, sizeof(buf));
        return -1;
    }
    *nonce = (uint16_t)(*nonce + 1U);
    unpack_S1_4bit(a->coeffs, buf);
    bit_secure_zero(buf, sizeof(buf));
    return 0;
}

int poly_sample_S1_4x(poly *a0, poly *a1, poly *a2, poly *a3, const uint8_t *seed, uint16_t nonce0,
                      uint16_t nonce1, uint16_t nonce2, uint16_t nonce3)
{
    const uint16_t nonce[4] = {nonce0, nonce1, nonce2, nonce3};
    poly *dst[4] = {a0, a1, a2, a3};
#if BIT_USE_SHAKE
    ALIGNED_UINT8(BIT_SEEDBYTES + 2) in[4];
    ALIGNED_UINT8(BIT_SAMPLE_S1_BUFLEN) out[4];

    for (size_t lane = 0; lane < 4; lane++) {
        memcpy(in[lane].coeffs, seed, BIT_SEEDBYTES);
        store16_le(in[lane].coeffs + BIT_SEEDBYTES, nonce[lane]);
    }
    shake256x4(out[0].coeffs, out[1].coeffs, out[2].coeffs, out[3].coeffs, BIT_SAMPLE_S1_BUFLEN,
               in[0].coeffs, in[1].coeffs, in[2].coeffs, in[3].coeffs, BIT_SEEDBYTES + 2);

    for (size_t lane = 0; lane < 4; lane++)
        if (dst[lane] != NULL)
            unpack_S1_4bit(dst[lane]->coeffs, out[lane].coeffs);
#else
    for (size_t lane = 0; lane < 4; lane++) {
        if (dst[lane] != NULL) {
            uint16_t n = nonce[lane];
            if (poly_sample_S1(dst[lane], seed, &n) != 0) {
                return -1;
            }
        }
    }
#endif
    return 0;
}

static inline void poly_to_ntt_impl(poly_ntt *result, const poly *a, poly *centered)
{
    for (int i = 0; i < BIT_N; i++) {
        result->coeffs[i] = reduce_signed_barrett(a->coeffs[i]);
        if (centered != NULL)
            centered->coeffs[i] = result->coeffs[i];
    }
    ntt_fwd_asm(result->coeffs);
}

void poly_to_ntt(poly_ntt *result, const poly *a)
{
    poly_to_ntt_impl(result, a, NULL);
}

void poly_to_ntt_centered(poly_ntt *result, poly *a)
{
    poly_to_ntt_impl(result, a, a);
}

void poly_from_ntt(poly *result, const poly_ntt *a)
{
    poly_ntt tmp = *a;

    ntt_inv_asm(tmp.coeffs);
    for (int i = 0; i < BIT_N; i += 8)
        _mm256_store_si256((__m256i *)&result->coeffs[i],
                           reduce_signed_i32x8(_mm256_load_si256((const __m256i *)&tmp.coeffs[i])));
}

void poly_from_ntt_raw(poly *result, const poly_ntt *a)
{
    poly_ntt tmp = *a;

    /* Pointwise multiplication contributes R^-1.  The tomont inverse
     * folds the compensating R into its final 1/N normalization. */
    ntt_inv_tomont_asm(tmp.coeffs);
    for (int i = 0; i < BIT_N; i += 8)
        _mm256_store_si256((__m256i *)&result->coeffs[i],
                           reduce_signed_i32x8(_mm256_load_si256((const __m256i *)&tmp.coeffs[i])));
}

void poly_ntt_basemul_raw(poly_ntt *result, const poly_ntt *a, const poly_ntt *b)
{
    ntt_basemul_asm(result->coeffs, a->coeffs, b->coeffs);
}

void poly_ntt_dot3_raw(poly_ntt *result, const poly_ntt a[BIT_L], const poly_ntt b[BIT_L])
{
    ntt_dot3_asm(result->coeffs, (const int32_t (*)[BIT_N])a, (const int32_t (*)[BIT_N])b);
}

void poly_ntt_montgomery_lift(poly_ntt *result)
{
    ntt_montgomery_lift_asm(result->coeffs);
}

void poly_add(poly *result, const poly *a, const poly *b)
{
    /* Six folds cover |a+b| <= q/2 + gamma1 for a centered addend and a mask. */
#if BIT_GAMMA1 > 6 * BIT_Q
#error "mask addition needs more reduction folds"
#endif
    for (int i = 0; i < BIT_N; i += 8)
        _mm256_store_si256((__m256i *)&result->coeffs[i],
                           reduce_signed_i32x8(reduce_signed_i32x8(_mm256_add_epi32(
                               _mm256_load_si256((const __m256i *)&a->coeffs[i]),
                               _mm256_load_si256((const __m256i *)&b->coeffs[i])))));
}

void poly_add_no_reduce(poly *result, const poly *a, const poly *b)
{
    for (int i = 0; i < BIT_N; i += 8)
        _mm256_store_si256((__m256i *)&result->coeffs[i],
                           _mm256_add_epi32(_mm256_load_si256((const __m256i *)&a->coeffs[i]),
                                            _mm256_load_si256((const __m256i *)&b->coeffs[i])));
}

void poly_add_small(poly *result, const poly *a, const poly *small)
{
    poly_add(result, a, small);
}

void poly_highbits(poly *w1, const poly *w)
{
    for (int i = 0; i < BIT_N; i += 8)
        _mm256_store_si256(
            (__m256i *)&w1->coeffs[i],
            decompose_hint_centered_i32x8(_mm256_load_si256((const __m256i *)&w->coeffs[i])));
}

void poly_canonicalize(poly *b)
{
    for (int i = 0; i < BIT_N; i++)
        b->coeffs[i] = reduce_to_unsigned(b->coeffs[i]);
}

void poly_pack_w1(unsigned char *r, const poly *a)
{
    const __m128i weights = _mm_set1_epi16(0x1001);

    _Static_assert(BIT_W1_BITS == 4 && BIT_HINT_MODULUS <= 16,
                   "AVX2 w1 packing requires four-bit values");

    for (int i = 0; i < BIT_N; i += 16) {
        __m256i x0 = _mm256_load_si256((const __m256i *)&a->coeffs[i]);
        __m256i x1 = _mm256_load_si256((const __m256i *)&a->coeffs[i + 8]);
        __m256i x16 = _mm256_permute4x64_epi64(_mm256_packs_epi32(x0, x1), 0xD8);
        __m128i bytes =
            _mm_packus_epi16(_mm256_castsi256_si128(x16), _mm256_extracti128_si256(x16, 1));
        __m128i pairs = _mm_maddubs_epi16(bytes, weights);
        __m128i packed = _mm_packus_epi16(pairs, pairs);

        _mm_storel_epi64((__m128i *)(r + i / 2), packed);
    }
}

int poly_challenge(poly *c, const unsigned char seed[BIT_CHALLENGEBYTES])
{
    unsigned int i, b, pos;
    uint8_t buf[BIT_XOF256_RATE];
    uint8_t sign_bits[(BIT_TAU + 7) / 8];
    bit_xof256_ctx ctx;

    bit_xof256_ctx_init(&ctx, seed, BIT_CHALLENGEBYTES);
    if (bit_xof256_ctx_squeezeblocks(&ctx, buf, 1) != 0) {
        bit_xof256_ctx_zeroize(&ctx);
        bit_secure_zero(buf, sizeof(buf));
        return -1;
    }
    for (size_t j = 0; j < sizeof(sign_bits); j++)
        sign_bits[j] = buf[j];
    BIT_CT_HAETAE_PUBLIC(sign_bits, sizeof sign_bits);
    pos = (unsigned int)sizeof(sign_bits);

    for (i = 0; i < BIT_N; ++i) {
        c->coeffs[i] = 0;
    }

    for (i = BIT_N - BIT_TAU; i < BIT_N; ++i) {
        do {
            if (pos + 2 > BIT_XOF256_RATE) {
                if (bit_xof256_ctx_squeezeblocks(&ctx, buf, 1) != 0) {
                    bit_xof256_ctx_zeroize(&ctx);
                    bit_secure_zero(buf, sizeof(buf));
                    return -1;
                }
                pos = 0;
            }
            b = load16_le(buf + pos) & (BIT_N - 1U);
            BIT_CT_HAETAE_PUBLIC(&b, sizeof b);
            pos += 2;
        } while (b > i);

        c->coeffs[i] = c->coeffs[b];
        {
            unsigned int t = i - (BIT_N - BIT_TAU);
            c->coeffs[b] = 1 - 2 * ((sign_bits[t >> 3] >> (t & 7)) & 1U);
        }
    }
    bit_xof256_ctx_zeroize(&ctx);
    return 0;
}

void poly_challenge_to_sparse(sparse_challenge *s, const poly *c)
{
    int ctr = 0;
    const __m256i zero = _mm256_setzero_si256();

    s->bflip = 0;

    for (int i = 0; i < BIT_N && ctr < BIT_TAU; i += 8) {
        __m256i v = _mm256_load_si256((const __m256i *)&c->coeffs[i]);
        __m256i nonzero = _mm256_xor_si256(_mm256_cmpeq_epi32(v, zero), _mm256_set1_epi32(-1));
        uint32_t lane_mask = (uint32_t)_mm256_movemask_ps(_mm256_castsi256_ps(nonzero));

        while (lane_mask != 0 && ctr < BIT_TAU) {
            unsigned int lane = (unsigned int)__builtin_ctz(lane_mask);
            s->pos[ctr] = (uint16_t)(i + (int)lane);
            s->sign[ctr] = (int8_t)c->coeffs[s->pos[ctr]];
            ctr++;
            lane_mask &= lane_mask - 1U;
        }
    }
}

void poly_cneg(poly *a, uint8_t b)
{
    const __m256i mask = _mm256_set1_epi32(-(int32_t)b);

    for (int i = 0; i < BIT_N; i += 8) {
        __m256i x = _mm256_load_si256((const __m256i *)&a->coeffs[i]);
        _mm256_store_si256((__m256i *)&a->coeffs[i],
                           _mm256_sub_epi32(_mm256_xor_si256(x, mask), mask));
    }
}

void poly_mul_challenge_no_reduce(poly *result, const poly *a, const sparse_challenge *c)
{
    int32_t acc[BIT_N];
    const int32_t mask = (int32_t)(-(int32_t)c->bflip);

    for (int i = 0; i < BIT_N; i++) {
        acc[i] = 0;
    }

    for (int t = 0; t < BIT_TAU; t++) {
        int i = c->pos[t];
        if (c->sign[t] > 0) {
            for (int j = 0; j < BIT_N - i; j++)
                acc[i + j] += a->coeffs[j];
            for (int j = BIT_N - i; j < BIT_N; j++)
                acc[i + j - BIT_N] -= a->coeffs[j];
        } else {
            for (int j = 0; j < BIT_N - i; j++)
                acc[i + j] -= a->coeffs[j];
            for (int j = BIT_N - i; j < BIT_N; j++)
                acc[i + j - BIT_N] += a->coeffs[j];
        }
    }

    for (int i = 0; i < BIT_N; i++) {
        result->coeffs[i] = (int32_t)((acc[i] ^ mask) - mask);
    }
}

int poly_reject_highbits_bimodal(const poly *w1, const poly *w0, const sparse_challenge *c)
{
    uint32_t reject_flag = 0;
    const int32_t signed_one = 1 - 2 * (int32_t)c->bflip;

    for (int t = 0; t < BIT_TAU; t++) {
        int i = c->pos[t];
        int32_t hb;
        int32_t w_prime_val = (int32_t)w0->coeffs[i] + (int32_t)c->sign[t] * signed_one;

        decompose_hint(&hb, w_prime_val);
        reject_flag |= (uint32_t)((uint32_t)w1->coeffs[i] ^ (uint32_t)hb);
    }

    return (reject_flag != 0) ? 1 : 0;
}
