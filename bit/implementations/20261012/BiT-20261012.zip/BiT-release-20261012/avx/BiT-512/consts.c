/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */

#include <stdint.h>

#include "align.h"
#include "params.h"

#if BIT_Q != 25601 || BIT_N != 1024 || BIT_L != 3
#error "AVX2 qdata is specialized for q=25601, N=1024, L=3"
#endif

enum {
    QDATA_8XQ = 0,
    QDATA_8XQINV = 8,
    QDATA_8XR2_QINV = 16,
    QDATA_8XR2 = 24,
    QDATA_WORDS = 32
};

typedef struct {
    int32_t coeffs[QDATA_WORDS];
} qdata_t;

#define DUP8(a) a,a,a,a,a,a,a,a

BIT_ALIGN const qdata_t qdata = {{
    DUP8(BIT_Q),
    DUP8(-418407423),
    DUP8(1689399659),
    DUP8(-661)
}};

#undef DUP8

typedef char qdata_size_must_match[
    sizeof(qdata) == QDATA_WORDS * sizeof(int32_t) ? 1 : -1];
