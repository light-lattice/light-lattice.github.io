/* Copyright (c) 2026 Hang Zhang. */
#ifndef BIT_TEST_MASK_ADD_H
#define BIT_TEST_MASK_ADD_H

#include <stdio.h>
#include <string.h>

/* The first addend is centered; the mask may span [-gamma1, gamma1].
 * Expectations use division, not the production reduction helpers. */
static int test_mask_add_range(void)
{
    poly a = {0}, b = {0}, sum, high, alias;
    const int32_t limit = BIT_Q_HALF + BIT_GAMMA1;

    a.coeffs[0] = 3216;
    b.coeffs[0] = BIT_GAMMA1 - 1072;
    const int32_t residue = (a.coeffs[0] + b.coeffs[0]) % BIT_Q;
    const int32_t expected = residue > BIT_Q_HALF ? residue - BIT_Q : residue;
    const int32_t expected_high = (residue + BIT_GAMMA2 / 2) / BIT_GAMMA2;
    poly_add(&sum, &a, &b);
    poly_highbits(&high, &sum);
    if (sum.coeffs[0] != expected || high.coeffs[0] != expected_high) {
        printf("FAIL: mask-add boundary: sum=%d high=%d\n",
               (int)sum.coeffs[0], (int)high.coeffs[0]);
        return 1;
    }

    for (int32_t base = -limit; base <= limit; base += BIT_N) {
        for (int j = 0; j < BIT_N; j++) {
            int32_t value = base + j;
            if (value > limit)
                value = limit;
            a.coeffs[j] = value < -BIT_Q_HALF ? -BIT_Q_HALF :
                          value > BIT_Q_HALF ? BIT_Q_HALF : value;
            b.coeffs[j] = value - a.coeffs[j];
        }
        poly_add(&sum, &a, &b);
        poly_highbits(&high, &sum);
        for (int j = 0; j < BIT_N; j++) {
            int32_t value = a.coeffs[j] + b.coeffs[j];
            int32_t residue = value % BIT_Q;
            if (residue < 0)
                residue += BIT_Q;
            int32_t centered = residue > BIT_Q_HALF ? residue - BIT_Q : residue;
            int32_t expected_high = (residue + BIT_GAMMA2 / 2) / BIT_GAMMA2;
            if (sum.coeffs[j] != centered || high.coeffs[j] != expected_high) {
                printf("FAIL: mask-add range value=%d lane=%d sum=%d high=%d\n",
                       (int)value, j, (int)sum.coeffs[j], (int)high.coeffs[j]);
                return 1;
            }
        }
        /* Signing uses result == a; also cover the other supported alias. */
        alias = a;
        poly_add(&alias, &alias, &b);
        if (memcmp(&alias, &sum, sizeof sum) != 0)
            return 1;
        alias = b;
        poly_add(&alias, &a, &alias);
        if (memcmp(&alias, &sum, sizeof sum) != 0)
            return 1;
    }
    printf("PASS: mask-add/HighBits over all %d sums and both output aliases\n",
           (int)(2 * limit + 1));
    return 0;
}
#endif
