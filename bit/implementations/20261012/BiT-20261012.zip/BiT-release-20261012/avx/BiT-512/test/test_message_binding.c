/* Copyright (c) 2026 Hang Zhang. */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "../SIG_AlgorithmInstance.h"
#include "../symmetric.h"
#include "../drng.h"
#include "test_common.h"

/* Force a prehash collision without changing the challenge hash. */
int __wrap_bit_hash_message(uint8_t out[BIT_MESSAGEBYTES], const uint8_t *a, size_t an,
                           const uint8_t *b, size_t bn)
{
    (void)a;
    (void)an;
    (void)b;
    (void)bn;
    memset(out, 0x5a, BIT_MESSAGEBYTES);
    return 0;
}

int main(void)
{
    uint8_t pk[BIT_PUBLICKEYBYTES], sk[BIT_SECRETKEYBYTES], sig[BIT_SIGNBYTES];
    uint8_t seed[55], message[64], other[64];
    unsigned long long pn = 0, sn = 0, siglen = 0;
    test_fill_seed(seed, sizeof(seed), 512, 7);
    test_fill_message(message, sizeof(message), 512, 7);
    memcpy(other, message, sizeof(other));
    other[17] ^= 1;
    if (init_random_number(&drng_algorithm, seed, sizeof(seed)) != 0 ||
        sig_keygen(pk, &pn, sk, &sn) != 0 ||
        sig_sign(sk, sn, message, sizeof(message), sig, &siglen) != 0 ||
        sig_verify(pk, pn, sig, siglen, message, sizeof(message)) != 0) {
        puts("FAIL: valid signature with forced prehash collision");
        return 2;
    }
    if (sig_verify(pk, pn, sig, siglen, other, sizeof(other)) == 0) {
        puts("FAIL: signature transfers across equal prehashes");
        return 1;
    }
    puts("PASS: equal prehashes do not allow message transfer");
    return 0;
}
