/*
Copyright (c) 2026 Hang Zhang.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information
Engineering, CAS School of Cyber Security, University of Chinese Academy of Sciences
*/
#ifndef ALIGN_H
#define ALIGN_H

#include <immintrin.h>
#include <stdint.h>

#define BIT_ALIGN __attribute__((aligned(32)))
#define BIT_ALIGN_64 __attribute__((aligned(64)))

#define ALIGNED_UINT8(N)                                                                           \
    union {                                                                                        \
        uint8_t coeffs[N];                                                                         \
        __m256i vec[((N) + 31) / 32];                                                              \
    }

#define ALIGNED_INT64(N)                                                                           \
    union {                                                                                        \
        int64_t coeffs[N];                                                                         \
        __m256i vec[((N) + 3) / 4];                                                                \
    }

#endif
