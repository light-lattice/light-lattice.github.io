/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */
#include "packing.h"
#include "../../common/packing_checks.h"
#include "polyvec.h"
#include "endian.h"
#include <stdint.h>
#include <string.h>

static uint32_t load32_le_local(const unsigned char *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void store32_le_local(unsigned char *p, uint32_t x)
{
    p[0] = (uint8_t)x;
    p[1] = (uint8_t)(x >> 8);
    p[2] = (uint8_t)(x >> 16);
    p[3] = (uint8_t)(x >> 24);
}

#define BIT_IMPL_AVX 1
#include "../../common/packing_public.h"

/* Offset encoding for the first response block. */
static void pack_poly_z0(unsigned char *r, const poly *a)
{
    uint64_t acc = 0;
    int acc_bits = 0;
    size_t wi = 0;

    for (int i = 0; i < BIT_N; i++) {
        uint32_t code = (uint32_t)(BIT_GAMMA1 - a->coeffs[i]);
        acc |= (uint64_t)code << acc_bits;
        acc_bits += BIT_Z0_BITS;
        while (acc_bits >= 8) {
            r[wi++] = (uint8_t)acc;
            acc >>= 8;
            acc_bits -= 8;
        }
    }
    if (acc_bits)
        r[wi++] = (uint8_t)acc;
}

static void unpack_poly_z0(poly *r, const unsigned char *a)
{
    uint64_t acc = 0;
    int acc_bits = 0;
    size_t ri = 0;
    const uint32_t mask = (1U << BIT_Z0_BITS) - 1U;

    for (int i = 0; i < BIT_N; i++) {
        while (acc_bits < BIT_Z0_BITS) {
            acc |= (uint64_t)a[ri++] << acc_bits;
            acc_bits += 8;
        }
        uint32_t code = (uint32_t)acc & mask;
        acc >>= BIT_Z0_BITS;
        acc_bits -= BIT_Z0_BITS;
        r->coeffs[i] = BIT_GAMMA1 - (int32_t)code;
    }
}

static void pack_ternary_2bit(unsigned char out[BIT_N / 4], const poly *a)
{
    const __m256i mask = _mm256_set1_epi32(3);
    const __m128i pair_weights = _mm_set1_epi16(0x0401);
    const __m128i quad_weights = _mm_set1_epi32(0x00100001);
    const __m128i gather =
        _mm_setr_epi8(0, 4, 8, 12, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);

    for (int i = 0; i < BIT_N; i += 16) {
        __m256i x0 = _mm256_and_si256(_mm256_load_si256((const __m256i *)&a->coeffs[i]), mask);
        __m256i x1 = _mm256_and_si256(_mm256_load_si256((const __m256i *)&a->coeffs[i + 8]), mask);
        __m256i x16 = _mm256_permute4x64_epi64(_mm256_packs_epi32(x0, x1), 0xD8);
        __m128i bytes =
            _mm_packus_epi16(_mm256_castsi256_si128(x16), _mm256_extracti128_si256(x16, 1));
        __m128i pairs = _mm_maddubs_epi16(bytes, pair_weights);
        __m128i quads = _mm_madd_epi16(pairs, quad_weights);
        __m128i packed = _mm_shuffle_epi8(quads, gather);

        store32_le_local(out + i / 4, (uint32_t)_mm_cvtsi128_si32(packed));
    }
}

/* Decode eight packed bytes into 32 signed two-bit coefficients. */
static void unpack_ternary_2bit(int32_t *r, const unsigned char *a)
{
    for (int i = 0; i < BIT_N; i += 32, a += 8) {
        __m256i b = _mm256_cvtepu8_epi32(_mm_loadl_epi64((const __m128i *)a));
        __m256i c0 = _mm256_slli_epi32(b, 30);
        __m256i c1 = _mm256_slli_epi32(_mm256_srli_epi32(b, 2), 30);
        __m256i c2 = _mm256_slli_epi32(_mm256_srli_epi32(b, 4), 30);
        __m256i c3 = _mm256_slli_epi32(_mm256_srli_epi32(b, 6), 30);
        __m256i p01, p23, q0, q1, q2, q3;

        c0 = _mm256_srai_epi32(c0, 30);
        c1 = _mm256_srai_epi32(c1, 30);
        c2 = _mm256_srai_epi32(c2, 30);
        c3 = _mm256_srai_epi32(c3, 30);

        p01 = _mm256_unpacklo_epi32(c0, c1);
        p23 = _mm256_unpacklo_epi32(c2, c3);
        q0 = _mm256_unpacklo_epi64(p01, p23);
        q1 = _mm256_unpackhi_epi64(p01, p23);
        p01 = _mm256_unpackhi_epi32(c0, c1);
        p23 = _mm256_unpackhi_epi32(c2, c3);
        q2 = _mm256_unpacklo_epi64(p01, p23);
        q3 = _mm256_unpackhi_epi64(p01, p23);

        _mm256_store_si256((__m256i *)(r + i), _mm256_permute2x128_si256(q0, q1, 0x20));
        _mm256_store_si256((__m256i *)(r + i + 8), _mm256_permute2x128_si256(q2, q3, 0x20));
        _mm256_store_si256((__m256i *)(r + i + 16), _mm256_permute2x128_si256(q0, q1, 0x31));
        _mm256_store_si256((__m256i *)(r + i + 24), _mm256_permute2x128_si256(q2, q3, 0x31));
    }
}

void pack_pk(unsigned char *pk, const unsigned char *seed_A, const polyveck *public_vector)
{
    memcpy(pk, seed_A, BIT_SEEDBYTES);
    pk += BIT_SEEDBYTES;
    for (int i = 0; i < BIT_K; i++) {
        pack_poly_public(pk + i * BIT_POLY_PUBLIC_BYTES, &public_vector->vec[i]);
    }
}

void pack_sk(unsigned char *sk, const unsigned char *seed_A, const polyveck *public_vector,
             const unsigned char *secret_seed, const unsigned char *tr, const polyvecl *s_0,
             const polyveck *e)
{
    memcpy(sk, seed_A, BIT_SEEDBYTES);
    sk += BIT_SEEDBYTES;
    for (int i = 0; i < BIT_K; i++) {
        pack_poly_public(sk + i * BIT_POLY_PUBLIC_BYTES, &public_vector->vec[i]);
    }
    sk += BIT_POLYVECK_PUBLIC_BYTES;
    memcpy(sk, secret_seed, BIT_SEEDBYTES);
    sk += BIT_SEEDBYTES;
    memcpy(sk, tr, BIT_TRBYTES);
    sk += BIT_TRBYTES;
    for (int i = 0; i < BIT_L; ++i) {
        pack_ternary_2bit(sk, &s_0->vec[i]);
        sk += BIT_N / 4;
    }

    for (int i = 0; i < BIT_K; i++) {
        pack_ternary_2bit(sk, &e->vec[i]);
        sk += BIT_N / 4;
    }
}

int unpack_sk(unsigned char *seed_A, polyveck *public_vector, unsigned char *secret_seed,
              unsigned char *tr, polyvecl *s_0, polyveck *e, const unsigned char *sk)
{
    const size_t small_offset = 2 * BIT_SEEDBYTES + BIT_POLYVECK_PUBLIC_BYTES + BIT_TRBYTES;
    if (small2_encoding_invalid(sk + small_offset))
        return -1;

    memcpy(seed_A, sk, BIT_SEEDBYTES);
    sk += BIT_SEEDBYTES;
    for (int i = 0; i < BIT_K; i++) {
        if (unpack_poly_public(&public_vector->vec[i], sk + i * BIT_POLY_PUBLIC_BYTES) != 0)
            return -1;
    }
    sk += BIT_POLYVECK_PUBLIC_BYTES;
    memcpy(secret_seed, sk, BIT_SEEDBYTES);
    sk += BIT_SEEDBYTES;
    memcpy(tr, sk, BIT_TRBYTES);
    sk += BIT_TRBYTES;

    for (int i = 0; i < BIT_L; ++i) {
        unpack_ternary_2bit(s_0->vec[i].coeffs, sk);
        sk += BIT_N / 4;
    }

    for (int i = 0; i < BIT_K; i++) {
        unpack_ternary_2bit(e->vec[i].coeffs, sk);
        sk += BIT_N / 4;
    }

    return 0;
}

int unpack_pk(unsigned char *seed_A, polyveck *public_vector, const unsigned char *pk)
{
    memcpy(seed_A, pk, BIT_SEEDBYTES);
    pk += BIT_SEEDBYTES;

    for (int i = 0; i < BIT_K; i++) {
        if (unpack_poly_public(&public_vector->vec[i], pk + i * BIT_POLY_PUBLIC_BYTES) != 0)
            return -1;
    }
    return 0;
}

/* Byte-aligned rANS with a full-support Q16 model.
 * Response coefficients have eleven centered low bits. */
#include "../../common/rans_decode.h"

#define RANS_SCALE_BITS 16
#define RANS_SCALE (1U << RANS_SCALE_BITS)
#define RANS_BYTE_L (1U << 23)
#define RANS_TMP_BYTES (2 * BIT_K * BIT_N + 256)
#define Z_HIGH_MAX ((BIT_RESPONSE_COEFF_BOUND + (1 << (BIT_Z1_LOW_BITS - 1))) >> BIT_Z1_LOW_BITS)
#define Z_HIGH_MIN (-Z_HIGH_MAX)
#define Z_HIGH_SYMBOLS (Z_HIGH_MAX - Z_HIGH_MIN + 1)

#if BIT_L != BIT_K
#error "The paired rANS decoder requires BIT_L == BIT_K"
#endif

typedef struct {
    uint32_t x_max;
    uint32_t rcp_freq;
    uint32_t bias;
    uint16_t cmpl_freq;
    uint8_t rcp_shift;
} rans_enc_symbol;

/* Precomputed reciprocal form for byte-aligned rANS encoding. */
#include "rans_model.h"

static int rans_encode_pair(unsigned char *z_out, size_t *z_out_len, const uint8_t *z_symbols,
                            const rans_enc_symbol *z_model, unsigned int z_nsymbols,
                            unsigned char *h_out, size_t *h_out_len, const uint8_t *h_symbols,
                            const rans_enc_symbol *h_model, unsigned int h_nsymbols, size_t count)
{
    unsigned char z_tmp[RANS_TMP_BYTES], h_tmp[RANS_TMP_BYTES];
    unsigned char *z_ptr = z_tmp + sizeof(z_tmp);
    unsigned char *h_ptr = h_tmp + sizeof(h_tmp);
    uint32_t z_state = RANS_BYTE_L;
    uint32_t h_state = RANS_BYTE_L;

    for (size_t i = count; i > 0; i--) {
        unsigned int z_symbol = z_symbols[i - 1];
        unsigned int h_symbol = h_symbols[i - 1];
        const rans_enc_symbol *z_sym;
        const rans_enc_symbol *h_sym;
        uint32_t z_x, h_x, z_q, h_q;

        if (z_symbol >= z_nsymbols || h_symbol >= h_nsymbols)
            return -1;
        z_sym = &z_model[z_symbol];
        h_sym = &h_model[h_symbol];
        z_x = z_state;
        h_x = h_state;
        while (z_x >= z_sym->x_max) {
            if (z_ptr == z_tmp)
                return -1;
            *--z_ptr = (uint8_t)z_x;
            z_x >>= 8;
        }
        while (h_x >= h_sym->x_max) {
            if (h_ptr == h_tmp)
                return -1;
            *--h_ptr = (uint8_t)h_x;
            h_x >>= 8;
        }
        z_q = (uint32_t)(((uint64_t)z_x * z_sym->rcp_freq) >> 32) >> z_sym->rcp_shift;
        h_q = (uint32_t)(((uint64_t)h_x * h_sym->rcp_freq) >> 32) >> h_sym->rcp_shift;
        z_state = z_x + z_sym->bias + z_q * z_sym->cmpl_freq;
        h_state = h_x + h_sym->bias + h_q * h_sym->cmpl_freq;
    }
    if ((size_t)(z_ptr - z_tmp) < 4 || (size_t)(h_ptr - h_tmp) < 4)
        return -1;
    z_ptr -= 4;
    h_ptr -= 4;
    store32_le_local(z_ptr, z_state);
    store32_le_local(h_ptr, h_state);
    *z_out_len = (size_t)(z_tmp + sizeof(z_tmp) - z_ptr);
    *h_out_len = (size_t)(h_tmp + sizeof(h_tmp) - h_ptr);
    memcpy(z_out, z_ptr, *z_out_len);
    memcpy(h_out, h_ptr, *h_out_len);
    return 0;
}

static int rans_decode_pair(uint8_t *z_symbols, uint8_t *h_symbols, size_t count,
                            const unsigned char *z_in, size_t z_len, const unsigned char *h_in,
                            size_t h_len)
{
    const unsigned char *z_ptr = z_in;
    const unsigned char *h_ptr = h_in;
    const unsigned char *z_end = z_in + z_len;
    const unsigned char *h_end = h_in + h_len;
    uint32_t z_state, h_state;

    if (z_len < 4 || h_len < 4)
        return -1;
    z_state = load32_le_local(z_ptr);
    h_state = load32_le_local(h_ptr);
    z_ptr += 4;
    h_ptr += 4;
    if (z_state < RANS_BYTE_L || z_state >= (RANS_BYTE_L << 8) || h_state < RANS_BYTE_L ||
        h_state >= (RANS_BYTE_L << 8))
        return -1;

    for (size_t i = 0; i < count; i++) {
        uint32_t z_slot = z_state & (RANS_SCALE - 1);
        uint32_t h_slot = h_state & (RANS_SCALE - 1);
        uint32_t z_base = 0, h_base = 0;
        unsigned int z_symbol, h_symbol;

        z_symbol = rans_find_symbol(z_slot, z_high_freq, z_high_start, z_high_lookup, &z_base);
        h_symbol = rans_find_symbol(h_slot, h_freq, h_start, h_lookup, &h_base);

        z_symbols[i] = (uint8_t)z_symbol;
        h_symbols[i] = (uint8_t)h_symbol;
        z_state = z_high_freq[z_symbol] * (z_state >> RANS_SCALE_BITS) + z_slot - z_base;
        h_state = h_freq[h_symbol] * (h_state >> RANS_SCALE_BITS) + h_slot - h_base;
        while (z_state < RANS_BYTE_L && z_ptr < z_end)
            z_state = (z_state << 8) | *z_ptr++;
        while (h_state < RANS_BYTE_L && h_ptr < h_end)
            h_state = (h_state << 8) | *h_ptr++;
    }
    return z_state == RANS_BYTE_L && h_state == RANS_BYTE_L && z_ptr == z_end && h_ptr == h_end
               ? 0
               : -1;
}

int pack_sig(unsigned char *sig, const polyvecm1 *z1, const polyveck *h,
             const unsigned char *challenge)
{
    uint8_t z_high[BIT_L * BIT_N];
    uint8_t h_symbols[BIT_K * BIT_N];
    unsigned char enc_z[RANS_TMP_BYTES], enc_h[RANS_TMP_BYTES];
    size_t z_len, h_len;
    unsigned char *p = sig;

    for (int i = 0; i < BIT_L + 1; i++)
        for (int j = 0; j < BIT_N; j++)
            if (z1->vec[i].coeffs[j] < -BIT_RESPONSE_COEFF_BOUND ||
                z1->vec[i].coeffs[j] > BIT_RESPONSE_COEFF_BOUND)
                return -1;

    memset(sig, 0, BIT_SIGNBYTES);
    memcpy(p, challenge, BIT_CHALLENGEBYTES);
    p += BIT_CHALLENGEBYTES;
    pack_poly_z0(p, &z1->vec[0]);
    p += BIT_POLY_Z0_BYTES;

    {
        const __m256i low_mask = _mm256_set1_epi32((1U << BIT_Z1_LOW_BITS) - 1U);
        const __m256i high_min_minus_one = _mm256_set1_epi32(Z_HIGH_MIN - 1);
        const __m256i high_max = _mm256_set1_epi32(Z_HIGH_MAX);

        _Static_assert(BIT_Z1_LOW_BITS == 11, "AVX2 z1 packing assumes eleven low bits");
        for (int i = 0; i < BIT_L; i++) {
            for (int j = 0; j < BIT_N; j += 8) {
                BIT_ALIGN uint32_t code[8];
                BIT_ALIGN int32_t high_value[8];
                __m256i z = _mm256_load_si256((const __m256i *)&z1->vec[i + 1].coeffs[j]);
                __m256i code_vec = _mm256_and_si256(z, low_mask);
                __m256i low = _mm256_srai_epi32(_mm256_slli_epi32(code_vec, 32 - BIT_Z1_LOW_BITS),
                                                32 - BIT_Z1_LOW_BITS);
                __m256i high = _mm256_srai_epi32(_mm256_sub_epi32(z, low), BIT_Z1_LOW_BITS);
                __m256i invalid = _mm256_or_si256(_mm256_cmpgt_epi32(high, high_max),
                                                  _mm256_cmpgt_epi32(high_min_minus_one, high));
                size_t low_off = ((size_t)i * BIT_N + (size_t)j) * BIT_Z1_LOW_BITS / 8;

                if (_mm256_movemask_epi8(invalid) != 0)
                    return -1;
                _mm256_store_si256((__m256i *)code, code_vec);
                _mm256_store_si256((__m256i *)high_value, high);
                uint64_t word0 = (uint64_t)code[0] | ((uint64_t)code[1] << 11) |
                    ((uint64_t)code[2] << 22) | ((uint64_t)code[3] << 33) |
                    ((uint64_t)code[4] << 44) | ((uint64_t)code[5] << 55);
                uint32_t word1 = (code[5] >> 9) | (code[6] << 2) | (code[7] << 13);
                store64_le_n(p + low_off, word0, 8);
                store64_le_n(p + low_off + 8, word1, 3);
                for (int k = 0; k < 8; k++)
                    z_high[i * BIT_N + j + k] = (uint8_t)(high_value[k] - Z_HIGH_MIN);
            }
        }
        p += BIT_Z1_LOW_BYTES;
    }
    for (int i = 0; i < BIT_K; i++) {
        const __m256i min_minus_one = _mm256_set1_epi32(-BIT_H_INF - 1);
        const __m256i max = _mm256_set1_epi32(BIT_H_INF);
        const __m256i offset = _mm256_set1_epi32(BIT_H_INF);
        for (int j = 0; j < BIT_N; j += 8) {
            BIT_ALIGN int32_t symbol[8];
            __m256i v = _mm256_load_si256((const __m256i *)&h->vec[i].coeffs[j]);
            __m256i invalid =
                _mm256_or_si256(_mm256_cmpgt_epi32(v, max), _mm256_cmpgt_epi32(min_minus_one, v));

            if (_mm256_movemask_epi8(invalid) != 0)
                return -1;
            _mm256_store_si256((__m256i *)symbol, _mm256_add_epi32(v, offset));
            for (int k = 0; k < 8; k++)
                h_symbols[i * BIT_N + j + k] = (uint8_t)symbol[k];
        }
    }
    if (rans_encode_pair(enc_z, &z_len, z_high, z_high_enc, Z_HIGH_SYMBOLS, enc_h, &h_len,
                         h_symbols, h_enc, 2 * BIT_H_INF + 1, sizeof(z_high)) != 0)
        return -1;
    if (z_len > UINT16_MAX || h_len > UINT16_MAX || z_len + h_len > BIT_SIG_RANS_PAYLOAD_BYTES)
        return -1;

    store16_le(p, (uint16_t)z_len);
    store16_le(p + 2, (uint16_t)h_len);
    p += BIT_SIG_RANS_LENGTH_BYTES;
    memcpy(p, enc_z, z_len);
    p += z_len;
    memcpy(p, enc_h, h_len);
    return 0;
}

int unpack_sig(polyvecm1 *z1, polyveck *h, unsigned char *challenge, const unsigned char *sig)
{
    uint8_t z_high[BIT_L * BIT_N];
    uint8_t h_symbols[BIT_K * BIT_N];
    const unsigned char *p = sig;
    size_t z_len, h_len, used;

    memcpy(challenge, p, BIT_CHALLENGEBYTES);
    p += BIT_CHALLENGEBYTES;
    unpack_poly_z0(&z1->vec[0], p);
    p += BIT_POLY_Z0_BYTES;

    const unsigned char *low = p;
    p += BIT_Z1_LOW_BYTES;
    z_len = load16_le(p);
    h_len = load16_le(p + 2);
    p += BIT_SIG_RANS_LENGTH_BYTES;
    if (z_len < 4 || h_len < 4 || z_len + h_len > BIT_SIG_RANS_PAYLOAD_BYTES)
        return -1;
    if (rans_decode_pair(z_high, h_symbols, sizeof(z_high), p, z_len, p + z_len, h_len) != 0)
        return -1;
    p += z_len + h_len;

    {
        const __m256i high_offset = _mm256_set1_epi32(Z_HIGH_MIN);
        for (int i = 0; i < BIT_L; i++) {
            for (int j = 0; j < BIT_N; j += 8) {
                uint32_t code[8];
                uint64_t word0 = 0, word1 = 0;
                size_t low_off = ((size_t)i * BIT_N + (size_t)j) * BIT_Z1_LOW_BITS / 8;
                __m128i high8;
                __m256i high;
                __m256i low_value;

                word0 = load64_le_n(low + low_off, 8);
                word1 = load64_le_n(low + low_off + 8, 3);
                for (int k = 0; k < 5; k++)
                    code[k] = (uint32_t)(word0 >> (11 * k)) & 0x7FFU;
                code[5] = (uint32_t)((word0 >> 55) | (word1 << 9)) & 0x7FFU;
                code[6] = (uint32_t)(word1 >> 2) & 0x7FFU;
                code[7] = (uint32_t)(word1 >> 13) & 0x7FFU;
                low_value = _mm256_srai_epi32(
                    _mm256_slli_epi32(_mm256_loadu_si256((const __m256i *)code),
                                     32 - BIT_Z1_LOW_BITS), 32 - BIT_Z1_LOW_BITS);
                high8 = _mm_loadl_epi64((const __m128i *)(z_high + i * BIT_N + j));
                high = _mm256_add_epi32(_mm256_cvtepu8_epi32(high8), high_offset);
                _mm256_store_si256(
                    (__m256i *)&z1->vec[i + 1].coeffs[j],
                    _mm256_add_epi32(_mm256_slli_epi32(high, BIT_Z1_LOW_BITS), low_value));
            }
        }
    }
    for (int i = 0; i < BIT_K; i++) {
        const __m256i offset = _mm256_set1_epi32(BIT_H_INF);
        for (int j = 0; j < BIT_N; j += 8) {
            __m128i symbols = _mm_loadl_epi64((const __m128i *)(h_symbols + i * BIT_N + j));
            _mm256_store_si256((__m256i *)&h->vec[i].coeffs[j],
                               _mm256_sub_epi32(_mm256_cvtepu8_epi32(symbols), offset));
        }
    }

    for (int i = 0; i < BIT_L + 1; i++)
        for (int j = 0; j < BIT_N; j++)
            if (z1->vec[i].coeffs[j] < -BIT_RESPONSE_COEFF_BOUND ||
                z1->vec[i].coeffs[j] > BIT_RESPONSE_COEFF_BOUND)
                return -1;

    used = (size_t)(p - sig);
    for (size_t i = used; i < BIT_SIGNBYTES; i++)
        if (sig[i] != 0)
            return -1;
    return 0;
}
