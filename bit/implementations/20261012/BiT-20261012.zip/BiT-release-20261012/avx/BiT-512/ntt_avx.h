/*
 * Copyright (c) 2026 Hang Zhang.
 * State Key Laboratory of Cyberspace Security Defense,
 * Institute of Information Engineering, CAS
 * School of Cyber Security, University of Chinese Academy of Sciences
 */

#ifndef BIT_NTT_AVX_H
#define BIT_NTT_AVX_H

#include <stdint.h>
#include "params.h"

/* Arrays must be 32-byte aligned.  Forward output and inverse input use the
 * generated packed NTT order; transform values use R=2^32 Montgomery form. */
void ntt_fwd_asm(int32_t a[BIT_N]);
void ntt_inv_asm(int32_t a[BIT_N]);
void ntt_inv_tomont_asm(int32_t a[BIT_N]);
void ntt_pack_asm(int32_t a[BIT_N]);
void ntt_basemul_asm(int32_t r[BIT_N], const int32_t a[BIT_N], const int32_t b[BIT_N]);
void ntt_dot3_asm(int32_t r[BIT_N], const int32_t a[BIT_L][BIT_N], const int32_t b[BIT_L][BIT_N]);
void ntt_montgomery_lift_asm(int32_t r[BIT_N]);

#endif
