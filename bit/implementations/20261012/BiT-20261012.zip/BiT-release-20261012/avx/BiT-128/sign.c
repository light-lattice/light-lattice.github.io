/* Copyright (c) 2026 Hang Zhang. */

#define BIT_IMPL_AVX 1
#include "../../common/sign.inc"
