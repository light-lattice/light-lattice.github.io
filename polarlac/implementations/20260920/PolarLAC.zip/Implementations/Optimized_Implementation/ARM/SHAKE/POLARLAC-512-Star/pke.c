/*
Copyright (c) 2026 Ying Liu.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information Engineering, CAS
              School of Cyber Security, University of Chinese Academy of Sciences
File Description: Implements the MLWE-style POLARLAC public-key encryption layer for the optimized POLARLAC-512 instance.
*/

#include <stdint.h>
#include <string.h>

#include "params.h"
#include "sample.h"
#include "ntt.h"
#include "fft.h"
#include "symmetric.h"
#include "poly.h"
#include "pke.h"

#define POLY_NTT_BYTES (RL_KEM_N * sizeof(int16_t))

static int spectral_bound(const int16_t *poly)
{
#if RL_KEM_USE_CONJ_NTT_REJECTION
    return con_poly_within_bound(poly, (int32_t)CONJ_NTT_T);
#else
    return fft_within_bound_int16(poly, (int32_t)RL_KEM_T);
#endif
}

static void sample_screened_poly(polarlac_poly *poly, const uint8_t *seed, uint8_t *nonce)
{
    polarlac_poly candidate;

    for (;;) {
        poly_generate_tenary(candidate.coeffs, seed, *nonce);
        *nonce = (uint8_t)(*nonce + 1U);
        if (spectral_bound(candidate.coeffs)) {
            *poly = candidate;
            return;
        }
    }
}

static void sample_screened_polyvec(polarlac_polyvec *vec, const uint8_t *seed, uint8_t *nonce)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        sample_screened_poly(&vec->vec[k], seed, nonce);
    }
}

static inline void poly_ntt_from(polarlac_poly *dst, const polarlac_poly *src)
{
    *dst = *src;
    mq_poly_ntt(dst->coeffs);
}

static inline void polyvec_ntt_from(polarlac_polyvec *dst, const polarlac_polyvec *src)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        poly_ntt_from(&dst->vec[k], &src->vec[k]);
    }
}

//output [0,Q)
static inline void poly_mulacc2_ntt(polarlac_poly *out,
    const polarlac_poly *a0, const polarlac_poly *b0,
    const polarlac_poly *a1, const polarlac_poly *b1)
{
    mq_poly_pointwise_mulacc2(out->coeffs, a0->coeffs, b0->coeffs,
                               a1->coeffs, b1->coeffs);
}

static inline void poly_intt_to_coeff(polarlac_poly *poly)
{
    mq_poly_intt(poly->coeffs);
}

static inline void serialize_polyvec_ntt(uint8_t *dst, const polarlac_polyvec *vec)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        memcpy(dst + k * POLY_NTT_BYTES, vec->vec[k].coeffs, POLY_NTT_BYTES);
    }
}

static inline void deserialize_polyvec_ntt(polarlac_polyvec *vec, const uint8_t *src)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        memcpy(vec->vec[k].coeffs, src + k * POLY_NTT_BYTES, POLY_NTT_BYTES);
    }
}

int PKE_KeyGen(uint8_t *pk, uint8_t *sk, const uint8_t *seed)
{
    uint8_t expanded[PKE_EXPANDED_SEED_BYTES];
    uint8_t seed_se[KEM_SEED_LEN_BYTES];
    polarlac_polymat a_ntt;
    polarlac_polyvec s;
    polarlac_polyvec e;
    polarlac_polyvec s_ntt;
    polarlac_polyvec e_ntt;
    polarlac_polyvec b_ntt;
    uint8_t nonce = 0;

    if (pk == NULL || sk == NULL || seed == NULL) {
        return -1;
    }

    if (bit_xof(PKE_EXPANDED_SEED_BYTES * 8ULL, seed,
            KEM_SEED_LEN_BYTES * 8ULL, expanded) != 0) {
        return -1;
    }
    memcpy(pk, expanded, PK_SEED_LEN_BYTES);
    memcpy(seed_se, expanded + PK_SEED_LEN_BYTES, KEM_SEED_LEN_BYTES);

    poly_generate_uniformQ(&a_ntt, pk, 0);

    sample_screened_polyvec(&s, seed_se, &nonce);
    sample_screened_polyvec(&e, seed_se, &nonce);
    polyvec_ntt_from(&s_ntt, &s);
    polyvec_ntt_from(&e_ntt, &e);

    for (int i = 0; i < RL_KEM_K; i++) {
        poly_mulacc2_ntt(&b_ntt.vec[i],
            &a_ntt.row[i].vec[0], &s_ntt.vec[0],
            &a_ntt.row[i].vec[1], &s_ntt.vec[1]);
        for (int t = 0; t < RL_KEM_N; t++) {
            b_ntt.vec[i].coeffs[t] = rl_kem_mod_q((int32_t)b_ntt.vec[i].coeffs[t] + e_ntt.vec[i].coeffs[t]);

            // b_ntt.vec[i].coeffs[t] = b_ntt.vec[i].coeffs[t] + e_ntt.vec[i].coeffs[t] - RL_KEM_Q;
            // b_ntt.vec[i].coeffs[t] += (b_ntt.vec[i].coeffs[t] >> 15) & RL_KEM_Q;
        }
    }

    polyvec_compress(pk + PK_SEED_LEN_BYTES, &b_ntt);
    serialize_polyvec_ntt(sk, &s_ntt);

    return 0;
}

void PKE_Encrypt(uint8_t *c, const uint8_t *pk, const uint8_t *m, const uint8_t *seed)
{
    uint8_t com_c2[RL_KEM_Lv];
    uint8_t hatm[RL_KEM_Lv];
    polarlac_polymat a_t_ntt;
    polarlac_polyvec b_ntt;
    polarlac_polyvec r;
    polarlac_polyvec r_ntt;
    polarlac_polyvec e1;
    polarlac_polyvec e1_ntt;
    polarlac_poly e2;
    polarlac_polyvec u;
    polarlac_poly v;
    uint8_t nonce = 0;

    if (c == NULL || pk == NULL || m == NULL || seed == NULL) {
        return;
    }

    polyvec_decompress(&b_ntt, pk + PK_SEED_LEN_BYTES);
    poly_generate_uniformQ(&a_t_ntt, pk, 1);
    Encode_m(hatm, (uint8_t *)m);

    sample_screened_polyvec(&r, seed, &nonce);
    sample_screened_polyvec(&e1, seed, &nonce);
    poly_generate_tenary(e2.coeffs, seed, nonce);
    polyvec_ntt_from(&r_ntt, &r);
    polyvec_ntt_from(&e1_ntt, &e1);

    for (int i = 0; i < RL_KEM_K; i++) {
        poly_mulacc2_ntt(&u.vec[i],
            &a_t_ntt.row[i].vec[0], &r_ntt.vec[0],
            &a_t_ntt.row[i].vec[1], &r_ntt.vec[1]);
        for (int t = 0; t < RL_KEM_N; t++) {
            u.vec[i].coeffs[t] = rl_kem_mod_q((int32_t)u.vec[i].coeffs[t] + e1_ntt.vec[i].coeffs[t]);

            // u.vec[i].coeffs[t] = u.vec[i].coeffs[t] + e1_ntt.vec[i].coeffs[t] - RL_KEM_Q;
            // u.vec[i].coeffs[t] += (u.vec[i].coeffs[t] >> 15) & RL_KEM_Q;
        }
    }

    poly_mulacc2_ntt(&v, &b_ntt.vec[0], &r_ntt.vec[0],
                           &b_ntt.vec[1], &r_ntt.vec[1]);
    poly_intt_to_coeff(&v);
    for (int i = 0; i < RL_KEM_N; i++) {
        v.coeffs[i] = rl_kem_mod_q((int32_t)v.coeffs[i] + e2.coeffs[i]);
    }
    for (int i = 0; i < RL_KEM_Lv; i++) {
        // v.coeffs[i] = rl_kem_mod_q((int32_t)v.coeffs[i] + (RATIO * (int16_t)hatm[i]));
        v.coeffs[i] = v.coeffs[i] + (RATIO * (int16_t)hatm[i]) - RL_KEM_Q;
        v.coeffs[i] += (v.coeffs[i] >> 15) & RL_KEM_Q;
    }

    (void)polyvec_compress(c, &u);
    poly_compress_c2(com_c2, v.coeffs, D_C2_BITS);
    pack_c2_dbit(c + C1_LEN_BYTES, com_c2);
}

void PKE_Decrypt(uint8_t *m, const uint8_t *c, const uint8_t *sk)
{
    polarlac_polyvec u;
    polarlac_polyvec s_ntt;
    polarlac_poly su;
    polarlac_poly v;
    int16_t hatm[RL_KEM_Lv];
    uint8_t com_c2[RL_KEM_Lv];

    if (m == NULL || c == NULL || sk == NULL) {
        return;
    }

    polyvec_decompress(&u, c);
    unpack_c2_dbit(com_c2, c + C1_LEN_BYTES);
    poly_decompress_c2(v.coeffs, com_c2, D_C2_BITS);
    deserialize_polyvec_ntt(&s_ntt, sk);

    poly_mulacc2_ntt(&su, &u.vec[0], &s_ntt.vec[0],
                            &u.vec[1], &s_ntt.vec[1]);
    poly_intt_to_coeff(&su);

    for (int i = 0; i < RL_KEM_Lv; i++) {
        int16_t su_i = rl_kem_mod_q(su.coeffs[i]);
        hatm[i] = v.coeffs[i] - su_i;
        hatm[i] += (hatm[i] >> 15) & RL_KEM_Q;
    }

    Decode_m(m, hatm);
}
