/*
Copyright (c) 2026 Ying Liu.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information Engineering, CAS
              School of Cyber Security, University of Chinese Academy of Sciences
File Description: Implements the MLWE-style POLARLAC public-key encryption layer for the optimized POLARLAC-512-Star instance.
*/

#include <stdint.h>
#include <string.h>

#include "params.h"
#include "sample.h"
#include "ntt.h"
#include "fft.h"
#include "symmetric.h"
#include "poly.h"
#include "pke.h"

#define POLY_NTT_BYTES (RL_KEM_N * sizeof(int16_t))

static int spectral_bound(const int16_t *poly)
{
    return fft_within_bound_int16(poly, (int32_t)RL_KEM_T);
}

static void sample_screened_poly(polarlac_poly *poly, const uint8_t *seed, uint8_t *nonce)
{
    for (;;) {
        poly_generate_tenary(poly->coeffs, seed, *nonce);
        *nonce = (uint8_t)(*nonce + 1U);
        if (spectral_bound(poly->coeffs)) {
            return;
        }
    }
}

static void sample_screened_polyvec(polarlac_polyvec *vec, const uint8_t *seed, uint8_t *nonce)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        sample_screened_poly(&vec->vec[k], seed, nonce);
    }
}

static void sample_screened_polyvec_pair(polarlac_polyvec *vec0, polarlac_polyvec *vec1,
                                         const uint8_t *seed, uint8_t *nonce)
{
#if RL_KEM_K == 2
    polarlac_poly *targets[2 * RL_KEM_K] = {
        &vec0->vec[0], &vec0->vec[1],
        &vec1->vec[0], &vec1->vec[1]
    };
    polarlac_poly candidates[4];
    uint8_t n = *nonce;
    int filled = 0;

    while (filled < 2 * RL_KEM_K) {
        poly_generate_tenary_x4(candidates[0].coeffs, candidates[1].coeffs,
                                candidates[2].coeffs, candidates[3].coeffs,
                                seed, n, (uint8_t)(n + 1U),
                                (uint8_t)(n + 2U), (uint8_t)(n + 3U));

        for (int j = 0; j < 4 && filled < 2 * RL_KEM_K; j++) {
            if (spectral_bound(candidates[j].coeffs)) {
                *targets[filled] = candidates[j];
                filled++;
            }
            n = (uint8_t)(n + 1U);
        }
    }

    *nonce = n;
#else
    sample_screened_polyvec(vec0, seed, nonce);
    sample_screened_polyvec(vec1, seed, nonce);
#endif
}

static inline void poly_zero(polarlac_poly *poly)
{
    memset(poly->coeffs, 0, sizeof(poly->coeffs));
}

static inline void poly_ntt_from(polarlac_poly *dst, const polarlac_poly *src)
{
    *dst = *src;
    mq_poly_ntt(dst->coeffs);
}

static inline void polyvec_ntt_from(polarlac_polyvec *dst, const polarlac_polyvec *src)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        poly_ntt_from(&dst->vec[k], &src->vec[k]);
    }
}

static inline void poly_muladd2_ntt_products(polarlac_poly *out,
                                             const polarlac_poly *a0_ntt, const polarlac_poly *b0_ntt,
                                             const polarlac_poly *a1_ntt, const polarlac_poly *b1_ntt)
{
    mq_poly_pointwise_muladd2_aligned(out->coeffs,
                                      a0_ntt->coeffs, b0_ntt->coeffs,
                                      a1_ntt->coeffs, b1_ntt->coeffs);
}

static inline void poly_intt_to_coeff(polarlac_poly *poly)
{
    mq_poly_intt(poly->coeffs);
}

static inline void serialize_polyvec_ntt(uint8_t *dst, const polarlac_polyvec *vec)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        memcpy(dst + k * POLY_NTT_BYTES, vec->vec[k].coeffs, POLY_NTT_BYTES);
    }
}

static inline void deserialize_polyvec_ntt(polarlac_polyvec *vec, const uint8_t *src)
{
    for (int k = 0; k < RL_KEM_K; k++) {
        memcpy(vec->vec[k].coeffs, src + k * POLY_NTT_BYTES, POLY_NTT_BYTES);
    }
}

int PKE_KeyGen(uint8_t *pk, uint8_t *sk, const uint8_t *seed)
{
    uint8_t expanded[PKE_EXPANDED_SEED_BYTES];
    uint8_t seed_se[KEM_SEED_LEN_BYTES];
    polarlac_polymat a_ntt;
    polarlac_polyvec s;
    polarlac_polyvec e;
    polarlac_polyvec s_ntt;
    polarlac_polyvec e_ntt;
    polarlac_polyvec b_ntt;
    uint8_t nonce = 0;

    if (pk == NULL || sk == NULL || seed == NULL) {
        return -1;
    }

    bit_xof_bytes(expanded, PKE_EXPANDED_SEED_BYTES, seed, KEM_SEED_LEN_BYTES);
    memcpy(pk, expanded, PK_SEED_LEN_BYTES);
    memcpy(seed_se, expanded + PK_SEED_LEN_BYTES, KEM_SEED_LEN_BYTES);

    poly_generate_uniformQ(&a_ntt, pk, 0);

    sample_screened_polyvec_pair(&s, &e, seed_se, &nonce);
    polyvec_ntt_from(&s_ntt, &s);
    polyvec_ntt_from(&e_ntt, &e);

    for (int i = 0; i < RL_KEM_K; i++) {
        poly_muladd2_ntt_products(&b_ntt.vec[i],
                                  &a_ntt.row[i].vec[0], &s_ntt.vec[0],
                                  &a_ntt.row[i].vec[1], &s_ntt.vec[1]);
        for (int t = 0; t < RL_KEM_N; t++) {
            b_ntt.vec[i].coeffs[t] = rl_kem_mod_q((int32_t)b_ntt.vec[i].coeffs[t] + e_ntt.vec[i].coeffs[t]);

            // b_ntt.vec[i].coeffs[t] = b_ntt.vec[i].coeffs[t] + e_ntt.vec[i].coeffs[t] - RL_KEM_Q;
            // b_ntt.vec[i].coeffs[t] += (b_ntt.vec[i].coeffs[t] >> 15) & RL_KEM_Q;
        }
    }

    polyvec_compress(pk + PK_SEED_LEN_BYTES, &b_ntt);
    serialize_polyvec_ntt(sk, &s_ntt);

    return 0;
}

void PKE_Encrypt(uint8_t *c, const uint8_t *pk, const uint8_t *m, const uint8_t *seed)
{
    uint8_t com_c2[RL_KEM_Lv];
    uint8_t hatm[RL_KEM_Lv];
    polarlac_polymat a_t_ntt;
    polarlac_polyvec b_ntt;
    polarlac_polyvec r;
    polarlac_polyvec r_ntt;
    polarlac_polyvec e1;
    polarlac_polyvec e1_ntt;
    polarlac_poly e2;
    polarlac_polyvec u;
    polarlac_poly v;
    uint8_t nonce = 0;

    if (c == NULL || pk == NULL || m == NULL || seed == NULL) {
        return;
    }

    polyvec_decompress(&b_ntt, pk + PK_SEED_LEN_BYTES);
    poly_generate_uniformQ(&a_t_ntt, pk, 1);
    Encode_m(hatm, (uint8_t *)m);

    sample_screened_polyvec_pair(&r, &e1, seed, &nonce);
    poly_generate_tenary(e2.coeffs, seed, nonce);
    polyvec_ntt_from(&r_ntt, &r);
    polyvec_ntt_from(&e1_ntt, &e1);

    for (int i = 0; i < RL_KEM_K; i++) {
        poly_muladd2_ntt_products(&u.vec[i],
                                  &a_t_ntt.row[i].vec[0], &r_ntt.vec[0],
                                  &a_t_ntt.row[i].vec[1], &r_ntt.vec[1]);
        poly_add_inplace_reduce_q_avx2(u.vec[i].coeffs, e1_ntt.vec[i].coeffs);
    }

    poly_muladd2_ntt_products(&v,
                              &b_ntt.vec[0], &r_ntt.vec[0],
                              &b_ntt.vec[1], &r_ntt.vec[1]);
    poly_intt_to_coeff(&v);
    poly_add_inplace_reduce_q_avx2(v.coeffs, e2.coeffs);
    poly_add_msg_inplace_reduce_q_avx2(v.coeffs, hatm);

    (void)polyvec_compress(c, &u);
    poly_compress_c2(com_c2, v.coeffs, D_C2_BITS);
    pack_c2_dbit(c + C1_LEN_BYTES, com_c2);
}

void PKE_Decrypt(uint8_t *m, const uint8_t *c, const uint8_t *sk)
{
    polarlac_polyvec u;
    polarlac_polyvec s_ntt;
    polarlac_poly su;
    polarlac_poly v;
    int16_t hatm[RL_KEM_Lv];
    uint8_t com_c2[RL_KEM_Lv];

    if (m == NULL || c == NULL || sk == NULL) {
        return;
    }

    polyvec_decompress(&u, c);
    unpack_c2_dbit(com_c2, c + C1_LEN_BYTES);
    poly_decompress_c2(v.coeffs, com_c2, D_C2_BITS);
    deserialize_polyvec_ntt(&s_ntt, sk);

    poly_muladd2_ntt_products(&su,
                              &u.vec[0], &s_ntt.vec[0],
                              &u.vec[1], &s_ntt.vec[1]);
    poly_intt_to_coeff(&su);

    poly_normalize_q_avx2(su.coeffs);
    poly_sub_reduce_q_avx2(hatm, v.coeffs, su.coeffs);

    Decode_m(m, hatm);
}
