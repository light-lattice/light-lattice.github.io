# ZEN Changelog

## Changes Since the Original NGCC Submission

This changelog summarizes the main implementation changes made to ZEN since its original submission to NGCC. It covers the reference (plain C) and AVX2 implementations at the 128-, 256-, and 512-bit security levels.

The updated implementations improve polynomial arithmetic, eliminate secret-dependent memory accesses in decoding, remove external buffer-alignment requirements, and introduce a build option for higher performance. These changes preserve the SM3 variant's algorithm parameters, sampling rules, KEM API signatures, and serialized formats of keys, ciphertexts, and shared secrets. In addition, we provide separate reference and AVX2 implementations with the symmetric components replaced by FIPS 202 primitives.

## 1. Polynomial Inversion Optimization

To reduce the cost of key generation, the updated implementations reorganize NTT-domain block inversion using the hierarchical batch-inversion approach described in Sections III–IV of *Accelerating NTRU+ Key Generation via Hierarchical Batch Inversion*. Even/odd decomposition reduces the block degree, while grouped products and product trees allow denominator inversions to be shared across blocks. The approach is adapted to ZEN's modulus and block structure, with AVX2 processing multiple blocks in parallel.

The `qinv` table lookups in the original implementation are replaced by a fixed addition chain to avoid indexing memory with secret values. Masking handles zero denominators without introducing secret-dependent branches in the inversion core.

Affected components: reference `ntt.c`, AVX2 `poly.c`, and the associated headers.

## 2. Polynomial Multiplication and Related Optimizations

The updated implementations introduce fixed-size Karatsuba multiplication in applicable NTT block products and inverse reconstruction routines to reduce modular multiplications. Squaring routines reuse symmetric terms. Arithmetic modulo 2 uses bit packing and word-level operations, with AVX2 combining parallel carryless products and Karatsuba decomposition. In ZEN-128 decryption, two modulo-2 multiplications that share an operand are processed together to avoid repeated packing and scans.

Related optimizations combine the final inverse NTT layer with normalization in the reference implementation, construct sampled coefficients directly from the required bits, and reuse buffers or combine passes in selected serialization and PKE routines. These changes reduce redundant arithmetic, memory traffic, and stack usage while preserving the sampling rules and encoded results.

Affected components: `ntt.c`, `poly.c`, `sample.c`, and `pke.c`, as applicable to each implementation.

## 3. SimpleDecoding Memory-Access Fix

In the original NGCC submission, SimpleDecoding writes to `t2[idx]`, where a secret-dependent comparison selects one of two addresses. The write address can reveal the comparison result even without a conditional branch. Because decoding occurs before the FO re-encryption check, invalid ciphertexts also reach this operation.

The updated implementations write to both fixed output positions on every iteration and use complementary masks to determine their values. The comparison result therefore affects the stored data rather than the write addresses. The reference implementation uses integer masks, while AVX2 processes 16 coefficient groups in parallel with fixed-offset vector stores. The simplified comparison preserves the original tie-breaking rule, and both stores occur even when the correction bit is zero.

Related changes in KEM decapsulation use explicit unsigned masks for ciphertext verification and shared-secret selection while preserving the FO rejection behavior.

Affected components: `pke.c` and `KEM_AlgorithmInstance.c` in the reference and AVX2 implementations.

## 4. Removal of the External 32-Byte Alignment Requirement

The originally submitted AVX2 implementation assumes that certain caller-provided buffers are aligned to 32 bytes. This complicates integration with protocols such as CreTAKE, where fields may begin at arbitrary offsets within concatenated messages.

The updated AVX2 implementation uses unaligned-safe loads and stores at public KEM/PKE serialization boundaries. Callers can provide byte buffers of the documented lengths without additional 32-byte alignment or SIMD tail padding. Misleading alignment annotations on pointer variables are removed, and the interface requirements are clarified. Internal polynomial arrays retain the alignment required by the vector routines.

Affected components: AVX2 `poly.c` and `KEM_AlgorithmInstance.c`, together with the reference and AVX2 interface headers.

## 5. New Build Option for Higher Performance

The updated implementations introduce a `performance` build option for the reference and AVX2 implementations at all supported security levels. It uses Clang with `-O3 -march=native -fomit-frame-pointer` to pursue the highest performance on the build machine.

A separate `ngcc` option uses GCC with `-std=c99 -Wpedantic -Wall -Wextra -O2`. The AVX2 implementation additionally enables `-mavx2` under this option, as required by its vector intrinsics.

Select either option from an implementation directory:

```sh
# Performance build using Clang
make BUILD=performance KAT_KEM SPEED_KEM

# GCC-based NGCC profile
make BUILD=ngcc KAT_KEM SPEED_KEM
```

The Makefiles support automatic rebuilding when the selected option changes, while preserving executable names and run commands. Each implementation's README documents the available options and compiler requirements.

Performance builds may use instructions specific to the build CPU and require compatible hardware. Actual performance depends on the CPU and compiler version and should be measured on the intended target platform.

Affected components: `Makefile` and `README.txt` in the reference and AVX2 implementations.

## 6. FIPS 202-Based Implementations

In addition to the SM3-based implementations, we provide separate reference (plain C) and AVX2 implementations in which the symmetric components are replaced by primitives specified in FIPS 202. These implementations retain the underlying ZEN KEM construction while providing an alternative symmetric backend based on the SHA-3/SHAKE standard.

The FIPS 202-based implementations are provided at all three security levels (128, 256, and 512 bits). Since the symmetric primitives differ from those of the SM3 variant, their deterministic outputs and known-answer tests are evaluated separately.

---

**Reference:** Jonghyun Kim, Haehyun Cho, and Jong Hwan Park, [*Accelerating NTRU+ Key Generation via Hierarchical Batch Inversion*](../../../Accelerating%20NTRU+%20Key%20Generation%20via%20Hierarchical%20Batch%20Inversion.pdf), Sections III–IV.
