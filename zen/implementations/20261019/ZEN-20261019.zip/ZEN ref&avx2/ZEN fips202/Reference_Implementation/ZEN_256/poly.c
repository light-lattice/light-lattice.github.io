/*
Copyright (c) 2026 Yu Zhang.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information Engineering, CAS
              School of Cyber Security, University of Chinese Academy of Sciences  
File Description: Declares the ZEN key-encapsulation mechanism layer for the optimized ZEN-256 instance.
*/
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "params.h"
#include "auxfunc.h"
#include "sample.h"
#include "symmetric.h"

static inline uint32_t load32_le(const uint8_t *src)
{
    return (uint32_t)src[0]
         | ((uint32_t)src[1] << 8)
         | ((uint32_t)src[2] << 16)
         | ((uint32_t)src[3] << 24);
}

static inline void store32_le(uint8_t *dst, uint32_t x)
{
    dst[0] = (uint8_t)x;
    dst[1] = (uint8_t)(x >> 8);
    dst[2] = (uint8_t)(x >> 16);
    dst[3] = (uint8_t)(x >> 24);
}

/* In-place 16x16 bit transpose.  The transform reverses both axes; callers
 * load/store rows in reverse order so coefficient and bit numbering is kept. */
static inline void transpose16(uint16_t x[16])
{
    unsigned int j = 8;
    uint16_t mask = 0x00ffU;

    while(j != 0)
    {
        unsigned int k = 0;

        while(k < 16)
        {
            uint16_t t = (uint16_t)((x[k] ^ (x[k + j] >> j)) & mask);
            x[k] ^= t;
            x[k + j] ^= (uint16_t)(t << j);
            k = (k + j + 1) & ~j;
        }
        j >>= 1;
        if(j != 0)
            mask ^= (uint16_t)(mask << j);
    }
}

static inline uint64_t load_le(const uint8_t *src, unsigned int len)
{
    unsigned int i;
    uint64_t x = 0;

    for(i = 0; i < len; i++)
        x |= (uint64_t)src[i] << (8 * i);
    return x;
}

static inline void store_le(uint8_t *dst, uint64_t x, unsigned int len)
{
    unsigned int i;

    for(i = 0; i < len; i++)
    {
        dst[i] = (uint8_t)x;
        x >>= 8;
    }
}

static inline uint64_t div769(uint64_t x)
{
    return x / 769ULL;
}

static const uint64_t pack_table[] = 
{
    1, 769, 591361, 454756609, 349707832321
};

static inline uint64_t pack5(const int16_t *a)
{
    return (uint64_t)(uint16_t)a[0]
         + (uint64_t)(uint16_t)a[1] * pack_table[1]
         + (uint64_t)(uint16_t)a[2] * pack_table[2]
         + (uint64_t)(uint16_t)a[3] * pack_table[3]
         + (uint64_t)(uint16_t)a[4] * pack_table[4];
}

static inline void unpack_base769(int16_t *a, uint64_t x, unsigned int count)
{
    unsigned int i;

    for(i = 0; i < count; i++)
    {
        uint64_t q = div769(x);
        a[i] = (int16_t)(x - q * 769ULL);
        x = q;
    }
}

int check_poly_inv_Zq(int16_t *a)
{
	unsigned int i;
    int32_t flag;
    uint32_t acc = 0;
    for(i = 0; i < ZEN_N; i += 8)
	{
		flag = a[i] + a[i + 1] + a[i + 2] + a[i + 3] + a[i + 4] + a[i + 5] + a[i + 6] + a[i + 7];
		acc |= (((flag | (0u - flag)) >> 31) ^ 1u);
	}
	return (int)(acc & 1u);
}

int check_poly_inv_Z2(int16_t *a)
{
	unsigned int i;
    uint32_t acc = 0;
    for(i = 0; i < ZEN_N4; i++)
    {
        acc ^= a[i];
    }
	return (int)((((acc | (0u - acc)) >> 31) ^ 1u) & 1u);
}

#define MUL_R2_512_STEP(AOFF)                                             \
    do {                                                                  \
        for (i = 0; i < 64; i++) {                                        \
            mask = 0ULL - ((uint64_t)((uint16_t)a[(AOFF) + i] & 1u));     \
                                                                          \
            r0 ^= b0 & mask;                                              \
            r1 ^= b1 & mask;                                              \
            r2 ^= b2 & mask;                                              \
            r3 ^= b3 & mask;                                              \
            r4 ^= b4 & mask;                                              \
            r5 ^= b5 & mask;                                              \
            r6 ^= b6 & mask;                                              \
            r7 ^= b7 & mask;                                              \
                                                                          \
            wrap = b7 >> 63;                                              \
            u0 = (b0 << 1) | wrap;                                        \
            u1 = (b1 << 1) | (b0 >> 63);                                  \
            u2 = (b2 << 1) | (b1 >> 63);                                  \
            u3 = (b3 << 1) | (b2 >> 63);                                  \
            u4 = (b4 << 1) | (b3 >> 63);                                  \
            u5 = (b5 << 1) | (b4 >> 63);                                  \
            u6 = (b6 << 1) | (b5 >> 63);                                  \
            u7 = (b7 << 1) | (b6 >> 63);                                  \
                                                                          \
            b0 = u0;                                                      \
            b1 = u1;                                                      \
            b2 = u2;                                                      \
            b3 = u3;                                                      \
            b4 = u4;                                                      \
            b5 = u5;                                                      \
            b6 = u6;                                                      \
            b7 = u7;                                                      \
        }                                                                 \
    } while (0)

void mul_in_R2_512(int16_t *a, int16_t *b, int16_t *res)
{
    unsigned int i;
    uint64_t b0, b1, b2, b3, b4, b5, b6, b7;
    uint64_t r0, r1, r2, r3, r4, r5, r6, r7;
    uint64_t u0, u1, u2, u3, u4, u5, u6, u7;
    uint64_t mask, wrap;

    b0 = b1 = b2 = b3 = b4 = b5 = b6 = b7 = 0;
    r0 = r1 = r2 = r3 = r4 = r5 = r6 = r7 = 0;

    for (i = 0; i < 64; i++) {
        b0 |= ((uint64_t)((uint16_t)b[i] & 1u)) << i;
        b1 |= ((uint64_t)((uint16_t)b[i + 64] & 1u)) << i;
        b2 |= ((uint64_t)((uint16_t)b[i + 128] & 1u)) << i;
        b3 |= ((uint64_t)((uint16_t)b[i + 192] & 1u)) << i;
        b4 |= ((uint64_t)((uint16_t)b[i + 256] & 1u)) << i;
        b5 |= ((uint64_t)((uint16_t)b[i + 320] & 1u)) << i;
        b6 |= ((uint64_t)((uint16_t)b[i + 384] & 1u)) << i;
        b7 |= ((uint64_t)((uint16_t)b[i + 448] & 1u)) << i;
    }

    MUL_R2_512_STEP(0);
    MUL_R2_512_STEP(64);
    MUL_R2_512_STEP(128);
    MUL_R2_512_STEP(192);
    MUL_R2_512_STEP(256);
    MUL_R2_512_STEP(320);
    MUL_R2_512_STEP(384);
    MUL_R2_512_STEP(448);

    for (i = 0; i < 64; i++) {
        res[i] = (int16_t)((r0 >> i) & 1ULL);
        res[i + 64] = (int16_t)((r1 >> i) & 1ULL);
        res[i + 128] = (int16_t)((r2 >> i) & 1ULL);
        res[i + 192] = (int16_t)((r3 >> i) & 1ULL);
        res[i + 256] = (int16_t)((r4 >> i) & 1ULL);
        res[i + 320] = (int16_t)((r5 >> i) & 1ULL);
        res[i + 384] = (int16_t)((r6 >> i) & 1ULL);
        res[i + 448] = (int16_t)((r7 >> i) & 1ULL);
    }
}


#define DO_FASTINV_LEVEL_64(N, MASKN)                                  \
    do {                                                               \
        for (i = 0; i < (N); i++) {                                    \
            acc = 0;                                                   \
            for (j = i; j < ZEN_N4; j += (N)) {                  \
                acc ^= k[j];                                           \
            }                                                          \
            tmp[i] = acc;                                              \
        }                                                              \
                                                                       \
        /*                                                            \
         * bp = f_inv[0..N-1] * tmp[0..N-1] in R2_N.                  \
         * The product is kept packed, so no b[] unpacking is needed. \
         */                                                           \
        ap = 0;                                                        \
        tp = 0;                                                        \
        for (i = 0; i < (N); i++) {                                    \
            ap |= ((uint64_t)((uint16_t)f_inv[i] & 1u)) << i;          \
            tp |= ((uint64_t)((uint16_t)tmp[i] & 1u)) << i;            \
        }                                                              \
                                                                       \
        B = tp & (MASKN);                                              \
        bp = 0;                                                        \
        for (i = 0; i < (N); i++) {                                    \
            mask = 0ULL - ((ap >> i) & 1ULL);                          \
            bp ^= B & mask;                                            \
                                                                       \
            wrap = (B >> ((N) - 1)) & 1ULL;                            \
            B = ((B << 1) | wrap) & (MASKN);                           \
        }                                                              \
        bp &= (MASKN);                                                 \
                                                                       \
        /*                                                            \
         * tmp = bp * f in R2_256.                                    \
         * Since bp has only N valid bits, only N rotations are needed.\
         */                                                           \
        g0 = f0;                                                       \
        g1 = f1;                                                       \
        g2 = f2;                                                       \
        g3 = f3;                                                       \
        r0 = r1 = r2 = r3 = 0;                                         \
                                                                       \
        for (i = 0; i < (N); i++) {                                    \
            mask = 0ULL - ((bp >> i) & 1ULL);                          \
            r0 ^= g0 & mask;                                           \
            r1 ^= g1 & mask;                                           \
            r2 ^= g2 & mask;                                           \
            r3 ^= g3 & mask;                                           \
                                                                       \
            wrap = g3 >> 63;                                           \
            u0 = (g0 << 1) | wrap;                                     \
            u1 = (g1 << 1) | (g0 >> 63);                               \
            u2 = (g2 << 1) | (g1 >> 63);                               \
            u3 = (g3 << 1) | (g2 >> 63);                               \
                                                                       \
            g0 = u0;                                                   \
            g1 = u1;                                                   \
            g2 = u2;                                                   \
            g3 = u3;                                                   \
        }                                                              \
                                                                       \
        for (i = 0; i < 64; i++) {                                     \
            k[i]       ^= (int16_t)((r0 >> i) & 1ULL);                 \
            k[i + 64]  ^= (int16_t)((r1 >> i) & 1ULL);                 \
            k[i + 128] ^= (int16_t)((r2 >> i) & 1ULL);                 \
            k[i + 192] ^= (int16_t)((r3 >> i) & 1ULL);                 \
        }                                                              \
                                                                       \
        for (i = (N); i < ZEN_N4; i += (N)) {                    \
            for (j = i; j < i + (N); j++) {                            \
                k[j] ^= k[j - (N)];                                    \
            }                                                          \
        }                                                              \
                                                                       \
        for (i = 0; i < (N); i++) {                                    \
            bit = (int16_t)((bp >> i) & 1ULL);                         \
            f_inv[i]       ^= bit;                                     \
            f_inv[i + (N)] ^= bit;                                     \
        }                                                              \
    } while (0)

void FastInversion(int16_t *f_inv, int16_t *f)
{
    unsigned int i, j;
    int16_t k[ZEN_N4];
    int16_t tmp[ZEN_N4];
    int16_t acc;
    int16_t bit;

    uint64_t f0, f1, f2, f3;
    uint64_t ap, tp, bp;
    uint64_t ap0, ap1, tp0, tp1, bp0, bp1;
    uint64_t B, B0, B1;
    uint64_t mask;
    uint64_t wrap;
    uint64_t g0, g1, g2, g3;
    uint64_t r0, r1, r2, r3;
    uint64_t u0, u1, u2, u3;

    /*
     * Pack f[0..255] once.
     * The original code copied f into tmp_f and then mul_in_R2_256
     * repacked tmp_f at every level.
     */
    f0 = f1 = f2 = f3 = 0;
    for (i = 0; i < 64; i++) {
        f0 |= ((uint64_t)((uint16_t)f[i] & 1u)) << i;
        f1 |= ((uint64_t)((uint16_t)f[i + 64] & 1u)) << i;
        f2 |= ((uint64_t)((uint16_t)f[i + 128] & 1u)) << i;
        f3 |= ((uint64_t)((uint16_t)f[i + 192] & 1u)) << i;
    }

    k[0] = f[0];
    for (i = 1; i < ZEN_N4; i++) {
        k[i] = f[i] ^ k[i - 1];
    }

    memset(f_inv, 0, ZEN_N4 * sizeof(int16_t));
    f_inv[0] = 1;

    acc = 0;
    for (i = 0; i < ZEN_N4; i++) {
        acc ^= k[i];
    }

    for (i = 0; i < ZEN_N4; i++) {
        k[i] ^= (acc * f[i]);
    }

    for (i = 1; i < ZEN_N4; i++) {
        k[i] ^= k[i - 1];
    }

    f_inv[0] = !acc;
    f_inv[1] = acc;

    DO_FASTINV_LEVEL_64(2,  0x0000000000000003ULL);
    DO_FASTINV_LEVEL_64(4,  0x000000000000000FULL);
    DO_FASTINV_LEVEL_64(8,  0x00000000000000FFULL);
    DO_FASTINV_LEVEL_64(16, 0x000000000000FFFFULL);
    DO_FASTINV_LEVEL_64(32, 0x00000000FFFFFFFFULL);
    DO_FASTINV_LEVEL_64(64, UINT64_MAX);

    /*
     * Level n = 128.
     * This level needs two 64-bit words for the packed product.
     */
    for (i = 0; i < 128; i++) {
        acc = 0;
        for (j = i; j < ZEN_N4; j += 128) {
            acc ^= k[j];
        }
        tmp[i] = acc;
    }

    ap0 = ap1 = tp0 = tp1 = 0;
    for (i = 0; i < 64; i++) {
        ap0 |= ((uint64_t)((uint16_t)f_inv[i] & 1u)) << i;
        ap1 |= ((uint64_t)((uint16_t)f_inv[i + 64] & 1u)) << i;
        tp0 |= ((uint64_t)((uint16_t)tmp[i] & 1u)) << i;
        tp1 |= ((uint64_t)((uint16_t)tmp[i + 64] & 1u)) << i;
    }

    /*
     * bp = f_inv[0..127] * tmp[0..127] in R2_128.
     */
    B0 = tp0;
    B1 = tp1;
    bp0 = bp1 = 0;

    for (i = 0; i < 64; i++) {
        mask = 0ULL - ((ap0 >> i) & 1ULL);
        bp0 ^= B0 & mask;
        bp1 ^= B1 & mask;

        wrap = B1 >> 63;
        u0 = (B0 << 1) | wrap;
        u1 = (B1 << 1) | (B0 >> 63);
        B0 = u0;
        B1 = u1;
    }

    for (i = 0; i < 64; i++) {
        mask = 0ULL - ((ap1 >> i) & 1ULL);
        bp0 ^= B0 & mask;
        bp1 ^= B1 & mask;

        wrap = B1 >> 63;
        u0 = (B0 << 1) | wrap;
        u1 = (B1 << 1) | (B0 >> 63);
        B0 = u0;
        B1 = u1;
    }

    /*
     * tmp = bp * f in R2_256.
     * bp has 128 valid bits, so only 128 rotations are needed.
     */
    g0 = f0;
    g1 = f1;
    g2 = f2;
    g3 = f3;
    r0 = r1 = r2 = r3 = 0;

    for (i = 0; i < 64; i++) {
        mask = 0ULL - ((bp0 >> i) & 1ULL);
        r0 ^= g0 & mask;
        r1 ^= g1 & mask;
        r2 ^= g2 & mask;
        r3 ^= g3 & mask;

        wrap = g3 >> 63;
        u0 = (g0 << 1) | wrap;
        u1 = (g1 << 1) | (g0 >> 63);
        u2 = (g2 << 1) | (g1 >> 63);
        u3 = (g3 << 1) | (g2 >> 63);
        g0 = u0;
        g1 = u1;
        g2 = u2;
        g3 = u3;
    }

    for (i = 0; i < 64; i++) {
        mask = 0ULL - ((bp1 >> i) & 1ULL);
        r0 ^= g0 & mask;
        r1 ^= g1 & mask;
        r2 ^= g2 & mask;
        r3 ^= g3 & mask;

        wrap = g3 >> 63;
        u0 = (g0 << 1) | wrap;
        u1 = (g1 << 1) | (g0 >> 63);
        u2 = (g2 << 1) | (g1 >> 63);
        u3 = (g3 << 1) | (g2 >> 63);
        g0 = u0;
        g1 = u1;
        g2 = u2;
        g3 = u3;
    }

    for (i = 0; i < 64; i++) {
        k[i]       ^= (int16_t)((r0 >> i) & 1ULL);
        k[i + 64]  ^= (int16_t)((r1 >> i) & 1ULL);
        k[i + 128] ^= (int16_t)((r2 >> i) & 1ULL);
        k[i + 192] ^= (int16_t)((r3 >> i) & 1ULL);
    }

    for (j = 128; j < 256; j++) {
        k[j] ^= k[j - 128];
    }

    for (i = 0; i < 64; i++) {
        bit = (int16_t)((bp0 >> i) & 1ULL);
        f_inv[i]       ^= bit;
        f_inv[i + 128] ^= bit;

        bit = (int16_t)((bp1 >> i) & 1ULL);
        f_inv[i + 64]  ^= bit;
        f_inv[i + 192] ^= bit;
    }
}

void poly_generate_g(int16_t *a, const uint8_t *seed, uint8_t nonce)
{
    uint8_t buf[ZEN_N_LEN_BYTES*4];

    zen_prf_x4(buf, ZEN_N_LEN_BYTES*4, seed, nonce);
    tenary3_16(a, buf);
}

void poly_generate_f(int16_t *a, const uint8_t *seed, uint8_t nonce)
{
    uint8_t buf[ZEN_N_LEN_BYTES*3];

    zen_prf_x4(buf, ZEN_N_LEN_BYTES*3, seed, nonce);
    tenary1_8(a, buf);
}

void poly_generate_se(int16_t *a, const uint8_t *seed, uint8_t nonce)
{
    uint8_t buf[ZEN_N_LEN_BYTES*2];

    zen_prf_x4(buf, ZEN_N_LEN_BYTES*2, seed, nonce);
    cbd1(a, buf);
}

void poly_bit2byte_pack(uint8_t *pa, const int16_t *a, const unsigned int n)
{
    unsigned int i;
    const int16_t *src = a;

    for(i = 0; i < n / 8; i++)
    {
        pa[i] = (uint8_t)(
              ((uint16_t)src[0] & 1u)
            | (((uint16_t)src[1] & 1u) << 1)
            | (((uint16_t)src[2] & 1u) << 2)
            | (((uint16_t)src[3] & 1u) << 3)
            | (((uint16_t)src[4] & 1u) << 4)
            | (((uint16_t)src[5] & 1u) << 5)
            | (((uint16_t)src[6] & 1u) << 6)
            | (((uint16_t)src[7] & 1u) << 7));

        src += 8;
    }
}

void poly_byte2bit_unpack(int16_t *a, const uint8_t *pa, const unsigned int n)
{
    unsigned int i;
    int16_t *dst = a;

    for(i = 0; i < n / 8; i++)
    {
        uint8_t byte = pa[i];

        dst[0] = (int16_t)((byte >> 0) & 1u);
        dst[1] = (int16_t)((byte >> 1) & 1u);
        dst[2] = (int16_t)((byte >> 2) & 1u);
        dst[3] = (int16_t)((byte >> 3) & 1u);
        dst[4] = (int16_t)((byte >> 4) & 1u);
        dst[5] = (int16_t)((byte >> 5) & 1u);
        dst[6] = (int16_t)((byte >> 6) & 1u);
        dst[7] = (int16_t)((byte >> 7) & 1u);

        dst += 8;
    }
}

void poly_secretkey_pack(uint8_t *ss, const int16_t *a)
{
    unsigned int i, j, k;

    for(i = 0; i < ZEN_N; i += 32)
    {
        const int16_t *src = a + i;
        uint8_t *dst = ss + (i / 32) * 40;
        uint16_t lo[16], hi[16];

        for(j = 0; j < 16; j++)
        {
            lo[15 - j] = (uint16_t)src[j];
            hi[15 - j] = (uint16_t)src[j + 16];
        }
        transpose16(lo);
        transpose16(hi);

        for(k = 0; k < 10; k++)
        {
            uint32_t w = (uint32_t)lo[15 - k]
                       | ((uint32_t)hi[15 - k] << 16);
            store32_le(dst + 4*k, w);
        }
    }
}

void poly_secretkey_unpack(int16_t *a, const uint8_t *ss)
{
    unsigned int i, j, k;

    for(i = 0; i < ZEN_N; i += 32)
    {
        int16_t *dst = a + i;
        const uint8_t *src = ss + (i / 32) * 40;
        uint16_t lo[16] = {0};
        uint16_t hi[16] = {0};

        for(k = 0; k < 10; k++)
        {
            uint32_t w = load32_le(src + 4*k);
            lo[15 - k] = (uint16_t)w;
            hi[15 - k] = (uint16_t)(w >> 16);
        }
        transpose16(lo);
        transpose16(hi);

        for(j = 0; j < 16; j++)
        {
            dst[j] = (int16_t)(lo[15 - j] & 0x03ffU);
            dst[j + 16] = (int16_t)(hi[15 - j] & 0x03ffU);
        }
    }
}

void poly_publickey_pack(uint8_t *pa, const int16_t *a)
{
    unsigned int i = 0;
    unsigned int out = 0;

    for(; i < ZEN_N - 4; i += 20, out += 24)
    {
        uint64_t x0 = pack5(a + i);
        uint64_t x1 = pack5(a + i + 5);
        uint64_t x2 = pack5(a + i + 10);
        uint64_t x3 = pack5(a + i + 15);

        store_le(pa + out,      x0,       6);
        store_le(pa + out + 6,  x3,       2);
        store_le(pa + out + 8,  x1,       6);
        store_le(pa + out + 14, x3 >> 16, 2);
        store_le(pa + out + 16, x2,       6);
        store_le(pa + out + 22, x3 >> 32, 2);
    }

    {
        uint64_t tail = (uint64_t)(uint16_t)a[i]
                      + (uint64_t)(uint16_t)a[i + 1] * pack_table[1]
                      + (uint64_t)(uint16_t)a[i + 2] * pack_table[2]
                      + (uint64_t)(uint16_t)a[i + 3] * pack_table[3];
        store_le(pa + out, tail, 5);
    }
}

void poly_publickey_unpack(int16_t *a, const uint8_t *pa)
{
    unsigned int i = 0;
    unsigned int in = 0;

    for(; i < ZEN_N - 4; i += 20, in += 24)
    {
        uint64_t x3 = load_le(pa + in + 6, 2)
                    | (load_le(pa + in + 14, 2) << 16)
                    | (load_le(pa + in + 22, 2) << 32);

        unpack_base769(a + i,      load_le(pa + in,      6), 5);
        unpack_base769(a + i + 5,  load_le(pa + in + 8,  6), 5);
        unpack_base769(a + i + 10, load_le(pa + in + 16, 6), 5);
        unpack_base769(a + i + 15, x3, 5);
    }

    unpack_base769(a + i, load_le(pa + in, 5), 4);
}

void poly_ciphertext_pack(uint8_t *pa, const int16_t *a)
{
    unsigned int i;

    for(i = 0; i < ZEN_N; i++)
    {
        pa[i] = (uint8_t)(a[i] & 0xFF);
    }
}

void poly_ciphertext_unpack(int16_t *a, const uint8_t *pa)
{
    unsigned int i;

    for(i = 0; i < ZEN_N; i++)
    {
        a[i] = (int16_t)pa[i];
    }
}

void poly_compress(int16_t *a)
{
    unsigned int i;
    uint32_t d;
    for(i = 0; i < ZEN_N; i++)
    {
        // a[i] = ((((uint32_t)a[i] << 8) + ZEN_Q/2) / ZEN_Q) & 255;
        d = a[i] << 8;
        d += 384;
        d *= 2727;
        d >>= 21;
        a[i] = d & 255;
    }

}

void poly_decompress(int16_t *a)
{
    unsigned int i;
    for(i = 0; i < ZEN_N; i++)
    {
        a[i] = ((((uint32_t)a[i] * ZEN_Q) + 128) >> 8);
    }
}
