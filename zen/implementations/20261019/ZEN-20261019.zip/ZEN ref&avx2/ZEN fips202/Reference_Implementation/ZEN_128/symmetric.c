/*
Copyright (c) 2026 Yu Zhang.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information Engineering, CAS
              School of Cyber Security, University of Chinese Academy of Sciences  
File Description: Declares the ZEN key-encapsulation mechanism layer for the optimized ZEN-128 instance.
*/
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "params.h"
#include "symmetric.h"
#include "fips202.h"

void zen_pseudoXOF(unsigned long long output_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *output, uint8_t nonce)
{
    const size_t msg_len_bytes = (size_t)(msg_len_bits / 8);
    uint8_t extseed[msg_len_bytes + 1];

    memcpy(extseed, msg, msg_len_bytes);
    extseed[msg_len_bytes] = nonce;
    
    shake256(output, (size_t)(output_len_bits / 8), extseed, msg_len_bytes + 1);
}


/* H(pk): ZEN_SYM_LEN_BYTES bytes. */
void zen_hash_h(uint8_t *out, const uint8_t *in, size_t inlen)
{
    uint8_t digest[32];

    sha3_256(digest, in, inlen);
    memcpy(out, digest, ZEN_SYM_LEN_BYTES);
}

/* G(m || H(pk)): shared key followed by the complete encryption seed. */
void zen_hash_g(uint8_t *out, const uint8_t *in, size_t inlen)
{
    /* The unchanged 64-byte seed requires more output than SHA3-512. */
    shake256(out, ZEN_SYM_LEN_BYTES + SEED_LEN_BYTES, in, inlen);
}

/* J(z || ct): ZEN_SHAREDKEY_LEN_BYTES bytes for implicit rejection. */
void zen_hash_j(uint8_t *out, const uint8_t *in, size_t inlen)
{
    zen_hash_h(out, in, inlen);
}


/* Scalar evaluation of the same four lane-separated SHAKE streams as AVX2.
 * outlen is a multiple of four for every polynomial sampler.
 */
void zen_prf_x4(uint8_t *out, size_t outlen, const uint8_t *seed, uint8_t nonce)
{
    uint8_t extseed[SEED_LEN_BYTES + 2];
    size_t lane;

    memcpy(extseed, seed, SEED_LEN_BYTES);
    extseed[SEED_LEN_BYTES] = nonce;
    for(lane = 0; lane < 4; lane++)
    {
        extseed[SEED_LEN_BYTES + 1] = (uint8_t)lane;
        shake256(out + lane*(outlen/4), outlen/4, extseed, sizeof(extseed));
    }
}
