/* Deterministic randomness for KAT builds only. Do not link into applications. */
#include <stdlib.h>
#include "drng.h"
#include "randombytes.h"

extern DRNG_ctx drng_algorithm;

void randombytes(uint8_t *out, size_t outlen)
{
    if(get_random_number(&drng_algorithm, out, (unsigned long long)outlen * 8))
        abort();
}
