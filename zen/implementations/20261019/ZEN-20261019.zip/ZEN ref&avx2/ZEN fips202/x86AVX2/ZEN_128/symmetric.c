/*
Copyright (c) 2026 Yu Zhang.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information Engineering, CAS
              School of Cyber Security, University of Chinese Academy of Sciences  
File Description: Declares the ZEN key-encapsulation mechanism layer for the optimized ZEN-128 instance.
*/
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "params.h"
#include "symmetric.h"
#include "fips202.h"
#include "fips202x4.h"

void zen_pseudoXOF(unsigned long long output_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *output, uint8_t nonce)
{
    const size_t msg_len_bytes = (size_t)(msg_len_bits / 8);
    uint8_t extseed[msg_len_bytes + 1];

    memcpy(extseed, msg, msg_len_bytes);
    extseed[msg_len_bytes] = nonce;
    
    shake256(output, (size_t)(output_len_bits / 8), extseed, msg_len_bytes + 1);
}

/* H(pk): ZEN_SYM_LEN_BYTES bytes. */
void zen_hash_h(uint8_t *out, const uint8_t *in, size_t inlen)
{
    uint8_t digest[32];

    sha3_256(digest, in, inlen);
    memcpy(out, digest, ZEN_SYM_LEN_BYTES);
}

/* G(m || H(pk)): shared key followed by the complete encryption seed. */
void zen_hash_g(uint8_t *out, const uint8_t *in, size_t inlen)
{
    /* The unchanged 64-byte seed requires more output than SHA3-512. */
    shake256(out, ZEN_SYM_LEN_BYTES + SEED_LEN_BYTES, in, inlen);
}

/* J(z || ct): ZEN_SHAREDKEY_LEN_BYTES bytes for implicit rejection. */
void zen_hash_j(uint8_t *out, const uint8_t *in, size_t inlen)
{
    zen_hash_h(out, in, inlen);
}

static const uint64_t zen_keccak_round_constants[24] = {
  (uint64_t)0x0000000000000001ULL,
  (uint64_t)0x0000000000008082ULL,
  (uint64_t)0x800000000000808aULL,
  (uint64_t)0x8000000080008000ULL,
  (uint64_t)0x000000000000808bULL,
  (uint64_t)0x0000000080000001ULL,
  (uint64_t)0x8000000080008081ULL,
  (uint64_t)0x8000000000008009ULL,
  (uint64_t)0x000000000000008aULL,
  (uint64_t)0x0000000000000088ULL,
  (uint64_t)0x0000000080008009ULL,
  (uint64_t)0x000000008000000aULL,
  (uint64_t)0x000000008000808bULL,
  (uint64_t)0x800000000000008bULL,
  (uint64_t)0x8000000000008089ULL,
  (uint64_t)0x8000000000008003ULL,
  (uint64_t)0x8000000000008002ULL,
  (uint64_t)0x8000000000000080ULL,
  (uint64_t)0x000000000000800aULL,
  (uint64_t)0x800000008000000aULL,
  (uint64_t)0x8000000080008081ULL,
  (uint64_t)0x8000000000008080ULL,
  (uint64_t)0x0000000080000001ULL,
  (uint64_t)0x8000000080008008ULL
};

/* Four independent streams, as in original: seed || nonce || lane.
 * All instances retain their 64-byte seed. Only the internal state needs
 * SIMD alignment; seed and output may be arbitrary byte-aligned slices.
 * The 66-byte inputs fit in one rate block, including SHAKE512's 72 bytes.
 */
void zen_prf_x4(uint8_t *out, size_t outlen, const uint8_t *seed, uint8_t nonce)
{
    ALIGN32 __m256i state[25];
    const size_t rate = 136;
    const size_t lane_len = outlen / 4;
    size_t i, j, pos, count;
    uint64_t word;

    for(i = 0; i < 25; i++)
        state[i] = _mm256_setzero_si256();
    for(i = 0; i < SEED_LEN_BYTES / 8; i++)
    {
        memcpy(&word, seed + 8*i, sizeof(word));
        state[i] = _mm256_set1_epi64x((long long)word);
    }
    state[8] = _mm256_set_epi64x(0x1f0300 | nonce, 0x1f0200 | nonce,
                                0x1f0100 | nonce, 0x1f0000 | nonce);
    state[rate/8 - 1] = _mm256_xor_si256(state[rate/8 - 1],
                                         _mm256_set1_epi64x((long long)UINT64_C(0x8000000000000000)));
    for(pos = 0; pos < lane_len; pos += count)
    {
        count = lane_len - pos;
        if(count > rate) count = rate;
        f1600x4(state, zen_keccak_round_constants);
        for(i = 0; i < count/8; i++)
        {
            word = (uint64_t)_mm256_extract_epi64(state[i], 0);
            memcpy(out + pos + 8*i, &word, 8);
            word = (uint64_t)_mm256_extract_epi64(state[i], 1);
            memcpy(out + lane_len + pos + 8*i, &word, 8);
            word = (uint64_t)_mm256_extract_epi64(state[i], 2);
            memcpy(out + 2*lane_len + pos + 8*i, &word, 8);
            word = (uint64_t)_mm256_extract_epi64(state[i], 3);
            memcpy(out + 3*lane_len + pos + 8*i, &word, 8);
        }
        if(count & 7)
        {
            uint64_t tail[4];
            _mm256_storeu_si256((__m256i *)tail, state[i]);
            for(j = 0; j < 4; j++)
                memcpy(out + j*lane_len + pos + 8*i, &tail[j], count & 7);
        }
    }
}
