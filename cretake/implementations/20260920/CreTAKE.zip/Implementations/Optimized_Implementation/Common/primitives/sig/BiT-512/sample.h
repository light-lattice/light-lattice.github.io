/*
Copyright (c) 2026 Hang Zhang.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information Engineering, CAS
              School of Cyber Security, University of Chinese Academy of Sciences
*/
#ifndef SAMPLE_H
#define SAMPLE_H
#include "polyvec.h"

#define BIT_TRIANGULAR_BITS 14
#define BYTELEN (4 * BIT_N)
void poly_sample_triangular(int32_t *out, const uint8_t *seed, uint16_t *nonce);
void poly_sample_triangular_eta0(int32_t *out, const uint8_t *seed, uint16_t *nonce);

/* batched y sampling (x4 / x2 XOF) */
void polyvecy_sample_y0y1_avx(polyvecy *y, const uint8_t *seed_y, uint16_t *nonce);
void polyvecy_sample_y2_avx(polyvecy *y, const uint8_t *seed_y, uint16_t *nonce);

int check_reject_sample_z0(const poly *z0, const unsigned char *seed, uint16_t *nonce);
int check_reject_sample_z0z1(const polyvecy *z, const polyvecl *c_s, const poly *c_poly, const sparse_challenge *c_sparse, const unsigned char *seed, uint16_t *nonce);
int check_reject_sample_z2  (const polyvecy *z, const polyveck *c_e, const unsigned char *seed, uint16_t *nonce);

int check_reject_highbits_w1_sparse(const poly *w1, const poly *w0,
                                    const sparse_challenge *c);
int check_reject_norm(const polyvecm1 *z1, const polyveck *h);
int check_reject_hint_range(const polyveck *h);

#endif
